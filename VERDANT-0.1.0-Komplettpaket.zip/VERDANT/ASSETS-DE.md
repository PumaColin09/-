# Assets und Abhängigkeiten

Die ausgelieferten Java-, JavaScript-, CSS-, HTML- und GLSL-Quellen wurden für
VERDANT erstellt. Blocktexturen, Normal-/Rauheitsdaten, Würfel-Icons, Terrain,
Pflanzen, Himmel, Wasser und Klänge entstehen prozedural. Das Bergsymbol ist ein
eigenes einfaches SVG. Es sind keine Minecraft-Assets, Shaderpacks, fremden
3D-Modelle oder kopierten Audiodateien Bestandteil des Pakets.

Die Oberfläche verwendet lokal vorhandene Systemschriften über CSS. Es werden
keine Fontdateien mitgeliefert oder nachgeladen.

Java-Laufzeit, Browser und Grafiktreiber sind externe Voraussetzungen und werden
nicht mitgeliefert. Das Spiel nutzt standardmäßig Java `jdk.httpserver`, Java
Desktop sowie Browser-APIs für WebGL 2, WebAudio, Worker und Pointer Lock. Es gibt
keine zusätzlichen Java-/JavaScript-Laufzeitbibliotheken im Spielpaket.

Die Werkzeuge unter `tools/` dienen ausschließlich den Entwicklungstests. Ihr
Browserharness benötigt Playwright und Requests; diese sind weder für den
Spielstart notwendig noch im Paket mitgeliefert. Die ohne Grafik ausführbaren
Tests unter `tests/` verwenden jeweils nur die Standardbibliotheken von Java,
Node.js bzw. Python.

Die Screenshots sind Aufnahmen des echten VERDANT-Renderers. Einige Testaufnahmen
enthalten die für Funktionsprüfungen gesetzten Blöcke. Diese veränderten
Testspielstände werden nicht als Standardwelt ausgeliefert.

Minecraft ist nicht der Name dieses Produkts. VERDANT ist ein unabhängiges Projekt
und nicht mit Mojang oder Microsoft verbunden.
