# VERDANT
## Eine Voxel-Sandbox mit eingebauten Shadern · Early Build 0.1.0

Eine selbst entwickelte Einzelspieler-Sandbox für den Desktop: ein Alpensee, Wälder,
Berge, ein veränderbares Blockterrain und eine zurückhaltende, moderne Oberfläche.
Baue eigene Räume, erkunde Höhlen, sammle Materialien oder fliege mit einer freien
Fotokamera durch die Landschaft. Sämtliche Spielgrafiken entstehen aus dem Code.

**Wichtig zur Technik:** VERDANT ist ein Hybrid. Java erzeugt und speichert die Welt
und startet einen ausschließlich lokalen Server. JavaScript steuert die Spielfigur
und den WebGL-2-Renderer im Browser. GLSL-Shader übernehmen die Grafikeffekte auf der
GPU. Es ist keine reine Java-Desktopgrafikanwendung und kein Minecraft-Mod.

Es werden keine Minecraft-Dateien, Shaderpacks, Bibliotheken oder Texturen
heruntergeladen. Die vollständigen eigenen Quelltexte liegen diesem Paket bei.

---

## 1. Starten unter Windows

1. Das **gesamte ZIP entpacken**, zum Beispiel in `Dokumente\VERDANT`.
2. `START-WINDOWS.cmd` im entpackten Ordner doppelt anklicken.
3. Den automatisch geöffneten Browser abwarten und **Welt betreten** anklicken.

Das Java-Fenster muss beim Spielen geöffnet bleiben. Der Weltaufbau erfolgt
schrittweise. Der Startknopf wird freigegeben, sobald die direkte Umgebung bereit
ist; weiter entfernte Landschaftsabschnitte laden danach weiter.

**Voraussetzung:** Java 17 oder neuer und ein Desktop-Browser mit WebGL 2,
Hardwarebeschleunigung, Maus und Tastatur. Ein vollständiges JDK ist sowohl zum
Starten als auch zum eigenen Kompilieren geeignet. Für das reine Spielen sind
weder Node.js noch Maven, Gradle, npm oder Python erforderlich.

Falls kein Browser automatisch geöffnet wird, kopiere die im Java-Fenster angezeigte
Adresse `http://127.0.0.1:PORT` in deinen Browser. Die Portnummer wird beim Start
gewählt. Verwende genau diese Adresse, nicht `localhost`, nicht deine LAN-IP und
keine feste Portnummer aus einem Screenshot.

Alternativ im Terminal, im Ordner mit der JAR-Datei:

```text
java -Dfile.encoding=UTF-8 -jar VERDANT.jar
```

Die Datei `resources/web/index.html` darf nicht direkt per Doppelklick geöffnet
werden. Der Java-Server ist ein notwendiger Bestandteil des Spiels.

### macOS und Linux

Im entpackten Ordner:

```sh
sh start.sh
```

Die JAR kann auch mit dem oben genannten `java`-Befehl gestartet werden. Die
Entwicklungstests wurden unter Linux durchgeführt. Ein nativer Windows- oder
macOS-Installer ist nicht enthalten; diese beiden Plattformen wurden hier nicht
praktisch geprüft. Das Paket benötigt keine Administratorrechte als Bestandteil
des Spielstarts. Die Installation von Java kann abhängig vom Rechner eigene
Berechtigungen erfordern. Betriebliche Sicherheitsrichtlinien nicht umgehen.

---

## 2. Die erste Runde

Du startest auf einer kleinen Aussichtsterrasse am See. Der Kreativmodus ist
standardmäßig aktiv. Das Inventar enthält frei wählbare Materialien, die beim
Bauen unbegrenzt verfügbar sind.

Drücke **F**, um zu fliegen, und halte die Leertaste, um aufzusteigen. Mit **E**
öffnest du die Materialauswahl. Klicke ein Material an, um es dem ausgewählten
Hotbar-Platz zuzuweisen. Schließe das Fenster mit Escape oder dem Schließen-Knopf
und klicke auf **Zurück in die Welt**, um die Maus wieder an das Spiel zu binden.

Platziere zum Beispiel ein Fundament aus Marmor, einen Rahmen aus dunklem Holz,
eine Glasfront und Laternen. Beim Blick aus verschiedenen Winkeln ändern sich
Oberflächenglanz, Wasserspiegelung und Beleuchtung. Über die Einstellungen kannst
du die Tageszeit sofort verändern und deinen Bau bei Nacht ansehen.

Für die Expedition: Escape drücken, Einstellungen öffnen und den Spielmodus auf
**Expedition** umstellen. Die Materialien werden dann gezählt und beim Bauen
verbraucht. Eichen- oder Fichtenstämme abbauen; an der Werkbank entstehen daraus
Bretter. Kupfer und Kristalle ermöglichen weitere Spielrezepte und Werkzeugstufen.

Diese Version konzentriert sich auf Bauen, Erkunden, Licht und Landschaft. Es gibt
kein vorgegebenes Endziel und keine Geschichte mit einem abschließenden Level.

---

## 3. Steuerung

| Eingabe | Funktion |
|---|---|
| W, A, S, D | Bewegen |
| Maus | Umschauen, nach Klick auf Welt betreten |
| Leertaste | Springen; beim Fliegen oder Schwimmen aufsteigen |
| Linke Umschalttaste | Sprinten; beim Fliegen sinken |
| Linke Strg-Taste | Schneller fliegen; unter Wasser abtauchen |
| F | Kreativflug ein-/ausschalten |
| Linke Maustaste halten | Anvisierten Block abbauen |
| Rechte Maustaste | Block an einer anvisierten Fläche platzieren |
| Mittlere Maustaste | Anvisiertes Material in den aktiven Slot übernehmen |
| 1 bis 9 / Mausrad | Hotbar-Platz auswählen |
| E | Materialinventar |
| C | Werkbank |
| J | Reisebuch und Entdeckungen |
| P | Freie Fotokamera an-/ausschalten |
| T / G im Fotomodus | Tageszeit vor-/zurückstellen |
| R im Fotomodus | Wetteroption wechseln |
| F1 | Oberfläche ein-/ausblenden |
| F2 | Gerendertes PNG-Foto ohne HTML-Oberfläche speichern |
| F3 | Grafik-/Chunk-Diagnoseanzeige |
| F11 | Browser-Vollbild, sofern der Browser diese Taste so belegt |
| Strg + S | Welt speichern |
| Strg + Z | Letzte Blockänderung rückgängig, nur im Kreativmodus |
| Escape | Maus freigeben, pausieren bzw. Fenster schließen |

Browser können nach Escape eine kurze Pause verlangen, bevor die Maus erneut
gebunden werden darf. Dann kurz warten und den Startknopf erneut anklicken.
Nach Fensterwechsel oder Fokusverlust pausiert das Spiel.

---

## 4. Was eingebaut ist

### Welt und Materialsystem

- Seed-basierte, reproduzierbare Grundwelt mit See, Wiesen, Eichen, Fichten,
  schneebedeckten Bergen, Farnen, Blumen, Höhlen und Erzen.
- 27 auswählbare Materialien: Naturblöcke, Holz, verschiedene Bausteine, Glas,
  Gletschereis, Erze, Lichtsteine und Laternen.
- Abbau, Platzierung, Materialaufnahme, neun Hotbar-Slots und bis zu 128
  rückgängig machbare Blockänderungen im Kreativmodus.
- Kreativmodus mit freiem Materialzugriff und Flug; Expedition mit gezähltem
  Inventar, Herstellung, vier Werkzeugstufen, Sturzschaden und Sauerstoff.
- Zehn Werkbankrezepte. Shift-Klick produziert bis zu fünf mögliche Chargen.
  Zutaten werden nur verbraucht, wenn das Rezept ausgeführt werden kann.
- Zwölf kleine Reisebuch-Erfolge. Fortschritt bleibt im Weltspielstand erhalten.

### Eingebaute Grafik

Die Effekte sind Bestandteil des Renderers, keine separat zu installierende Mod:

- Dynamische Sonnen-Schattenkarte mit 3×3-PCF-Filterung und transparent
  ausgeschnittenen Blättern im Schattenwurf.
- Prozedurale 64×64-Materialtexturen, Normalmaps, Oberflächenrauheit, Mipmaps
  und optionale anisotrope Filterung, wenn der Browser sie anbietet.
- Lokale Vertex-Umgebungsverdeckung plus Screen-Space Ambient Occlusion
  in den höheren Grafikprofilen.
- Tatsächlicher zweiter Kameradurchlauf für die planare Wasserspiegelung,
  Wellen, Fresnel-Effekt, Brechung, Tiefenabsorption und ein Ufersaummodell.
- Bewegte Vegetation, prozedurale Wolken, Tageszeit, Mond, Sterne, Regen,
  atmosphärischer Entfernungsnebel und nasser wirkende Oberflächen.
- Bis zu acht nahe Punktlichter durch platzierte Laternen/Lichtsteine.
- HDR-Renderziele bei unterstützter Erweiterung, sonst Standard-Farbtiefe.
  Bloom, filmische Tonwertabbildung, Unterwassereffekt und räumlicher Kantenfilter.
- Separate Glas-/Eisgeometrie und Partikel beim Abbau sowie Regenpartikel.

Das ist eine Echtzeit-Rastergrafik mit angenäherten Lichtmodellen. Es ist kein
Raytracing, Pathtracing, vollständiges PBR-Materialsystem, echtes volumetrisches
Wolkensystem oder physikalisch exakte Lichtsimulation. Punktlichter werfen in
Build 0.1 keine eigenen Schatten.

### Bedienung und Atmosphäre

Halbtransparente Menüs, Materialfilter, eigene Würfel-Icons, einstellbares Sichtfeld,
Mausempfindlichkeit und Belichtung; optional ruhige Kamera ohne Mitschwingen.
Wind, Regen, Schritte, Abbaugeräusche und kurze Vogel-/Hinweistöne werden über
WebAudio erzeugt. Es sind keine fremden Sounddateien enthalten. Audio beginnt
wegen der Browser-Freigabe erst nach deiner Interaktion mit dem Spiel.

---

## 5. Grafikprofile und Leistung

| Profil | Detaillierter Chunk-Radius | Schattenkarte | Spiegelung | SSAO |
|---|---:|---:|---:|---|
| Leicht | 80 Blöcke | 1024×1024 | 256 Pixel breit | Aus |
| Ausgewogen | 144 Blöcke | 2048×2048 | 512 Pixel breit | An |
| Cinematic | 160 Blöcke | 4096×4096, sofern unterstützt | 768 Pixel breit | Höhere Abtastung |

Dahinter wird eine gröbere Höhenlandschaft dargestellt. Die Fernsicht ist keine
voll detaillierte Blockwelt; entfernte Bäume und Spieleränderungen erscheinen
erst im hochaufgelösten Bereich. Die Chunks laden und entladen abhängig von der
Kameraposition. Geometrie entsteht in bis zu drei WebWorkern. Benachbarte gleiche
Flächen werden zusammengefasst, nicht sichtbare Chunks aussortiert.

**Mit Ausgewogen beginnen.** Bei Ruckeln zuerst auf Leicht umstellen, andere
GPU-intensive Programme schließen und prüfen, ob der Browser wirklich die
Grafikkarte verwendet. Cinematic erhöht Auflösung, Sichtweite und Schattenkosten;
4K-Monitorauflösung bedeutet nicht automatisch einen 4K-Renderer. Die interne
Auflösung ist aus Speicher-/Lastgründen auf 2560×1600 begrenzt.

Es gibt keine zugesicherte Bildrate und keinen aus dieser Entwicklung ableitbaren
Hardware-Benchmark. Die Grafiktests liefen hier auf einem Software-GPU-Renderer,
nicht auf deiner Grafikkarte. Stark unterschiedliche Browser-/Treiberleistung ist
möglich. Vollständige GPU-Kompatibilität ist nicht geprüft.

---

## 6. Speichern, Laden und Sichern

Standardverzeichnis:

```text
Windows: %USERPROFILE%\.verdant\welten\
macOS/Linux: ~/.verdant/welten/
```

Für jeden Seed gibt es eine Datei `welt-SEED.vdt`. Der vorherige Speicherstand
liegt zusätzlich als `welt-SEED.vdt.bak` vor. Es werden nur veränderte Blöcke und
Spielerdaten gespeichert; die unveränderte Landschaft wird aus dem Seed erzeugt.

Gespeichert werden Standort, Blickrichtung, Flugzustand, Gesundheit/Sauerstoff,
Inventar, Hotbar, Werkzeuge, Tageszeit, Erfolge, Laufstrecke und Blockänderungen.
Grafik-, Ton-, Wetter- und Modusoptionen werden im lokalen Browserprofil und bei
einem Welt-Speichervorgang zusätzlich im Weltspielstand abgelegt. Beim Laden einer
bereits gespielten Welt werden ihre gespeicherten Optionen wiederhergestellt,
auch wenn der Java-Server diesmal einen anderen Port verwendet. Neue Welten
übernehmen die momentan aktiven Optionen.

Der Browser überträgt den Spielerstand ungefähr alle 20 aktiven Simulationssekunden,
beim Pausieren, bei ausgeblendeter Seite und bei Strg+S. Java sichert seine Welt
zusätzlich alle 60 realen Sekunden und beim regulären Herunterfahren. Ein harter
Prozessabbruch oder Stromausfall kann seit dem letzten Schreiben entstandenen
Fortschritt verlieren. Verwende **Einstellungen → Speichern & beenden**, wenn du
fertig bist. Nur den Browser zu schließen beendet den Java-Prozess nicht.

Dateien werden zunächst temporär geschrieben und dann nach Möglichkeit atomar
ersetzt. GZIP-Prüfsummen, Format- und Bereichsprüfungen erkennen viele beschädigte
Spielstände. Ist beim Programmstart die Hauptdatei unlesbar, versucht Java die
letzte Sicherung. Erst wenn diese gelesen wurde, wird die beschädigte Hauptdatei
mit `.corrupt-...` archiviert. Ohne lesbare Sicherung wird nicht einfach darüber
hinweggespeichert. Beim Wechsel zu einer anderen beschädigten Welt im laufenden
Spiel erfolgt kein automatischer Recovery-Versuch; dann die Fehlermeldung prüfen
und das Spiel mit diesem Seed neu starten.

Für eigene Backups den gesamten Ordner `welten` bei beendetem Spiel kopieren.
Mehrere gleichzeitig laufende VERDANT-Instanzen sollten nicht denselben
Spielstandordner bearbeiten. Es gibt in Build 0.1 keine dateiübergreifende
Mehrprozess-Sperre und keinen zusammenführenden Mehrbenutzer-Spielstand.

### Startoptionen

```text
java -jar VERDANT.jar --seed 12345
java -jar VERDANT.jar --port 8765
java -jar VERDANT.jar --no-browser
java -jar VERDANT.jar --save-dir "D:\Meine Spiele\Verdant-Welten"
```

Optionen können kombiniert werden. Ein fester Port ist nützlich, um
denselben lokalen Browser-Lesezeichen-Eintrag wiederzuverwenden.
Der Port darf nicht bereits belegt sein.

---

## 7. Bewusste Grenzen dieser Version

Build 0.1 ist eine spielbare technische Erstversion, keine vollständige Kopie
eines kommerziellen Sandbox-Spiels. Insbesondere nicht enthalten:

- Mehrspieler, öffentliche Server, Accounts oder Cloud-Synchronisierung.
- Tiere, Gegner, NPCs, Kampf, Hunger, Landwirtschaft oder eine komplexe Ökonomie.
- Schaltkreise, Redstone-Äquivalent, Automatisierung und Maschinen.
- Fließende Flüssigkeiten, Flut-/Drainagesimulation oder platzierbare Wasserquellen.
- Minecraft-Weltformate, Mod-Kompatibilität, fremde Shader-/Ressourcenpacks.
- Eine native EXE-/App-Verpackung oder für Touch ausgelegte Smartphone-Steuerung.

Wasser ist eine animierte Oberfläche der generierten Gewässer. Das Entfernen von
Uferblöcken erzeugt keinen physikalisch nachfließenden See. Materialien wie Sand
fallen nicht herunter. Glas wird auf Chunk-, nicht auf jeder einzelnen
Dreiecksfläche sortiert; komplexe überlappende Glasbauten können deshalb sichtbare
Transparenzfehler zeigen. Die Fernsicht hat vereinfachte Oberflächen und die
Schattenkarte kann bei Bewegung leicht springen. Regen wird um die Kamera erzeugt
und besitzt noch keine vollständige Dach-/Innenraumabschirmung. Der Spieler hat
keine sichtbare Hand-/Werkzeuganimation. Rezepte sind Spielregeln, keine echten
Herstellungsverfahren.

Technische Weltgrenzen: 128 Blöcke Höhe, Koordinatenbereich bis ±50.000 Blöcke,
Bewegungsgrenze etwas innerhalb davon und maximal 250.000 geänderte Blockpositionen
pro Welt. Wiederholte Änderungen an derselben Position verbrauchen keinen neuen
Eintrag. Eine Rückkehr zum ursprünglich generierten Material entfernt den
Änderungseintrag in dieser Version nicht automatisch.

---

## 8. Quellcode ändern und selbst kompilieren

Die Struktur ist in `ARCHITEKTUR.md` erklärt. Der Java-Einstiegspunkt ist
`src/verdant/Main.java`. Die Landschaft steht in `src/verdant/World.java`.
Bedienung und Rezepte stehen in `resources/web/app.js`, Oberflächengrafik in
`resources/web/shaders/terrain.frag.glsl`, Wasser in `water.frag.glsl`.

**Windows:** `BUILD-WINDOWS.cmd` ausführen.

**macOS/Linux:** `sh build.sh` ausführen.

Dafür muss ein JDK ab Version 17 im Suchpfad liegen. Die Skripte verwenden nur
`javac` und `jar`. Sie installieren nichts und laden nichts herunter.
Änderungen an JavaScript, CSS oder Shadern werden erst nach dem Neuverpacken der
JAR und dem Neustart des Spiels verwendet, da der Server die Dateien aus der JAR
liest, nicht direkt aus dem Projektordner.

Tests: `TEST-WINDOWS.cmd` oder `sh test-java.sh`. Die zusätzlichen HTTP-Tests
benötigen Python 3, die Client-Kerntests Node.js. Sie sind Entwicklerwerkzeuge und
keine Spielabhängigkeiten. Das genaue Prüfergebnis und die Einschränkungen stehen
in `TEST-RESULTS.md`.

---

## 9. Fehlerhilfe

**„java wurde nicht gefunden“:** Java fehlt im Suchpfad. Nach Installation bzw.
Änderung des Suchpfads ein neues Terminal öffnen. `java -version` prüfen.

**„UnsupportedClassVersionError“:** Die verwendete Java-Laufzeit ist älter als 17.

**„WebGL 2 ist nicht verfügbar“ oder schwarzes Bild:** Hardwarebeschleunigung und
Grafiktreiber prüfen, einen anderen WebGL-2-fähigen Desktop-Browser testen. Die
Fehlerkarte enthält den Shader-/Framebufferfehler, falls einer auftritt. Es gibt
keinen softwarebasierten Ersatzrenderer innerhalb des Spiels.

**„Weltserver nicht erreichbar“:** Das Java-Fenster wurde geschlossen, der Port ist
nicht mehr verfügbar oder eine lokale Sicherheitsrichtlinie blockiert die
Verbindung. Nicht den Browser-Link einer alten Sitzung verwenden.

**„Falscher Host“:** Genau die gedruckte `127.0.0.1`-Adresse mit aktueller Portnummer
verwenden. Die Beschränkung ist beabsichtigt.

**Tastatur reagiert nicht:** Erst auf Welt betreten klicken und Menüs schließen.
Ein Textfeld in einem geöffneten Menü nimmt Tastatureingaben anstelle des Spiels an.

**Noch keine Geräusche:** Welt betreten anklicken und die Lautstärke in den
Einstellungen prüfen. Der Browser startet Audio nicht ohne Nutzerinteraktion.

**Strg+S statt Spielstand ein Browserdialog:** Das Spielfenster muss den Fokus
haben. Der eigene Shortcut ist im Dokument gebunden; Browser-/Betriebssystem-
Sonderfälle können ihn abfangen.

**Speichern fehlgeschlagen:** Schreibrechte und freien Platz im Spielstandordner
prüfen. Bei Bedarf mit `--save-dir` einen geeigneten eigenen Ordner wählen.

VERDANT enthält keine Telemetrie und keinen externen Netzwerkdienst. Der lokale
Server ist kein öffentlich zu betreibender Webdienst und sollte nicht durch
Portweiterleitung oder einen Proxy ins Netz gestellt werden.
