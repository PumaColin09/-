# VERDANT · 0.1.0

Erste eigenständige spielbare Version. Java 17 als Build-Ziel, keine nachzuladenden
Spielbibliotheken oder Assets.

**Spielkern:** deterministische Weltgenerierung, gepolsterte Chunks, Höhlen/Erze,
Vegetation, 27 auswählbare Materialien, Bauen/Abbauen, Kreativflug, Expedition,
Inventar, zehn Rezepte, vier Werkzeugstufen, zwölf Reisebuch-Erfolge und Fotomodus.

**Grafik:** eigener WebGL-2-Renderer mit 13 GLSL-Dateien, Sonnen-Schattenkarte,
planarer Wasserspiegelung, Tiefenbrechung, Normalmaps, Rauheit, Nebel, Wolken,
Tageszeit/Nacht, Regen, lokaler Beleuchtung, Glas, AO, Bloom und filmischen Tonwerten.
Drei Grafikprofile, Worker-Meshing und vereinfachte Fernlandschaft.

**Lokale Daten:** Java-Server nur auf Loopback, Sitzungsschlüssel, Origin-/Host-
Prüfung, validierte Eingaben, binäre Spielstände, Sicherung und Recovery mit
Archivierung beschädigter Hauptdateien. Spieler-, Welt- und Grafikeinstellungen
können zusammen gesichert werden.

**Vor Auslieferung korrigiert:** Chunkrand-Behandlung für moosige Felsbrocken,
Erkennung doppelter JSON-Schlüssel nach null, Sicherungserhalt bei Wiederherstellung,
Gesundheitsregeneration bei null Lebenspunkten, Bruchzahl-Seed-Prüfung,
Startkamera/Fernsicht sowie Wiederherstellung von Optionen bei wechselndem Port.

Bekannte Grenzen und nicht vorhandene Systeme sind in `README-DE.md` beschrieben.
