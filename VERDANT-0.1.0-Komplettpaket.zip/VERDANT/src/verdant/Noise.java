package verdant;

/** Reproduzierbares, von der Aufrufreihenfolge unabhängiges Value-Noise. */
public final class Noise {
    private final long seed;
    public Noise(long seed) { this.seed=seed; }
    public double hash(int x,int y,int z) {
        long h=seed ^ x*0x632BE59BD9B4E019L ^ y*0x9E3779B97F4A7C15L ^ z*0x85157AF5L;
        h=(h^(h>>>30))*0xBF58476D1CE4E5B9L; h=(h^(h>>>27))*0x94D049BB133111EBL;
        h^=h>>>31; return (h>>>11)*0x1.0p-53;
    }
    private static double smooth(double t) { return t*t*t*(t*(t*6-15)+10); }
    private static double mix(double a,double b,double t) { return a+(b-a)*t; }
    public double n2(double x,double z) {
        int ix=(int)Math.floor(x),iz=(int)Math.floor(z); double u=smooth(x-ix),v=smooth(z-iz);
        return mix(mix(hash(ix,0,iz),hash(ix+1,0,iz),u),mix(hash(ix,0,iz+1),hash(ix+1,0,iz+1),u),v);
    }
    public double n3(double x,double y,double z) {
        int ix=(int)Math.floor(x),iy=(int)Math.floor(y),iz=(int)Math.floor(z);
        double u=smooth(x-ix),v=smooth(y-iy),w=smooth(z-iz);
        return mix(mix(mix(hash(ix,iy,iz),hash(ix+1,iy,iz),u),mix(hash(ix,iy+1,iz),hash(ix+1,iy+1,iz),u),v),
                   mix(mix(hash(ix,iy,iz+1),hash(ix+1,iy,iz+1),u),mix(hash(ix,iy+1,iz+1),hash(ix+1,iy+1,iz+1),u),v),w);
    }
    public double fbm(double x,double z,int octaves) {
        double a=.5,sum=0,weight=0;
        for(int i=0;i<octaves;i++){sum+=n2(x,z)*a;weight+=a;x=x*2.03+31.7;z=z*2.03-19.2;a*=.5;}
        return sum/weight;
    }
    public static double smoothstep(double a,double b,double v) { double t=Math.max(0,Math.min(1,(v-a)/(b-a)));return t*t*(3-2*t); }
}
