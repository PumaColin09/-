package verdant;

/** Die Block-IDs sind Teil des versionierten Speicherformats. Nicht umsortieren. */
public final class Blocks {
    private Blocks() {}
    public static final int AIR=0, GRASS=1, DIRT=2, STONE=3, SAND=4, WATER=5,
        OAK=6, LEAVES=7, PINE=8, NEEDLES=9, SNOW=10, BASALT=11,
        PLANKS=12, BRICKS=13, GLASS=14, GLOW=15, COPPER=16, CRYSTAL=17,
        MOSS=18, MARBLE=19, CLAY=20, COBBLE=21, DARK_WOOD=22, LIMESTONE=23,
        FLOWER=24, FERN=25, BEDROCK=26, LANTERN=27, GOLD=28, ICE=29;
    public static final int COUNT=30;
    public static boolean valid(int id) { return id>=0 && id<COUNT; }
    public static boolean solid(int id) { return id!=AIR && id!=WATER && id!=FLOWER && id!=FERN; }
}
