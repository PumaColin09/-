package verdant;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Java-Weltkern. Chunks werden mit einem Block Rand für nahtlose Meshes erzeugt.
 * Ausschließlich Spieleränderungen werden gespeichert; die Grundwelt folgt dem Seed.
 */
public final class World {
    public static final int SIZE=16, HEIGHT=128, PAD=18, SEA=28, LIMIT=50000;
    public static final int MAX_EDITS=250000;
    public final long seed;
    public final Noise noise;
    private final Map<Long,byte[]> cache=Collections.synchronizedMap(new LinkedHashMap<>(256,.75f,true) {
        protected boolean removeEldestEntry(Map.Entry<Long,byte[]> e){return size()>320;}
    });
    private final ConcurrentHashMap<Long,ConcurrentHashMap<Integer,Byte>> edits=new ConcurrentHashMap<>();
    private int editCount;
    public volatile String metadata="{}";
    public World(long seed) {this.seed=seed;noise=new Noise(seed);}
    public static long chunkKey(int x,int z){return ((long)x<<32)^(z&0xffffffffL);}
    public static int index(int x,int y,int z){return (y*PAD+z)*PAD+x;}
    public static int localKey(int x,int y,int z){return (y<<8)|((z&15)<<4)|(x&15);}
    public static boolean inside(int x,int y,int z){return Math.abs((long)x)<=LIMIT&&Math.abs((long)z)<=LIMIT&&y>=0&&y<HEIGHT;}

    public int height(int x,int z) {
        double base=32+(noise.fbm(x*.007,z*.007,4)-.5)*18+(noise.n2(x*.071,z*.071)-.5)*3;
        double lake=Math.sqrt(Math.pow((x+3)/43.0,2)+Math.pow((z+5)/53.0,2));
        double basin=17+Noise.smoothstep(.22,1.15,lake)*17;
        base=base*(Noise.smoothstep(.92,1.45,lake))+basin*(1-Noise.smoothstep(.92,1.45,lake));
        double a=Math.exp(-((x+53.0)*(x+53.0)/1700+(z+89.0)*(z+89.0)/1250));
        double b=Math.exp(-((x-55.0)*(x-55.0)/1800+(z+109.0)*(z+109.0)/1600));
        double mountains=Noise.smoothstep(.51,.81,noise.fbm(x*.006+82,z*.006-61,4))*50*Noise.smoothstep(90,210,Math.hypot(x,z));
        base+=(a*63+b*74)*( .73+.38*noise.fbm(x*.048,z*.048,3)) + mountains;
        return (int)Math.max(7,Math.min(112,Math.floor(base)));
    }
    public int biome(int x,int z) {
        int h=height(x,z);
        if(h>76)return 3;
        if(h<=SEA+2)return 0;
        return noise.fbm(x*.014+109,z*.014-48,3)>.51||z< -40?2:1;
    }
    private int surface(int x,int z,int h) {
        if(h>80)return Blocks.SNOW;
        if(h>62)return noise.hash(x,55,z)>.23?Blocks.STONE:Blocks.GRASS;
        if(h<=SEA+1)return Blocks.SAND;
        return Blocks.GRASS;
    }
    private void put(byte[] data,int minx,int minz,int x,int y,int z,int id,boolean replace){
        int lx=x-minx,lz=z-minz;
        if(lx<0||lx>=PAD||lz<0||lz>=PAD||y<1||y>=HEIGHT)return;
        int idx=index(lx,y+1,lz);
        if(replace||data[idx]==Blocks.AIR||data[idx]==Blocks.LEAVES||data[idx]==Blocks.NEEDLES||data[idx]==Blocks.FERN||data[idx]==Blocks.FLOWER)data[idx]=(byte)id;
    }
    private byte[] generate(int cx,int cz) {
        byte[] a=new byte[PAD*(HEIGHT+2)*PAD]; int minx=cx*16-1,minz=cz*16-1;
        for(int lx=0;lx<PAD;lx++)for(int lz=0;lz<PAD;lz++) {
            int x=minx+lx,z=minz+lz,h=height(x,z),top=surface(x,z,h);
            a[index(lx,0,lz)]=Blocks.BEDROCK;
            for(int y=0;y<=Math.max(SEA-1,h);y++) {
                int id;
                if(y==0)id=Blocks.BEDROCK;
                else if(y>h)id=Blocks.WATER;
                else if(y==h)id=top;
                else if(y>h-4)id=top==Blocks.SAND?Blocks.SAND:top==Blocks.SNOW?Blocks.STONE:Blocks.DIRT;
                else {
                    id=Blocks.STONE;
                    if(y<h-5&&y>4&&noise.n3(x*.065,y*.08,z*.065)>.705&&noise.n3(x*.028+71,y*.04,z*.028+19)>.40)id=Blocks.AIR;
                    else {
                        double ore=noise.hash(x,y,z);
                        if(y<37&&ore>.980)id=Blocks.COPPER;
                        if(y<21&&ore<.011)id=Blocks.CRYSTAL;
                        if(y<14&&ore>.972&&ore<.980)id=Blocks.GOLD;
                        if(y<7&&id==Blocks.STONE)id=Blocks.BASALT;
                    }
                }
                a[index(lx,y+1,lz)]=(byte)id;
            }
        }
        // Jeder Baum wird anhand seiner Wurzel berechnet, auch über Chunkgrenzen.
        for(int gx=Math.floorDiv(minx-5,5);gx<=Math.floorDiv(minx+PAD+5,5);gx++)for(int gz=Math.floorDiv(minz-5,5);gz<=Math.floorDiv(minz+PAD+5,5);gz++){
            int x=gx*5+(int)(noise.hash(gx,97,gz)*4),z=gz*5+(int)(noise.hash(gx,98,gz)*4);
            int h=height(x,z),bio=biome(x,z);
            double chance=bio==2?.68:.28;
            // Der Spawn bleibt frei, die südliche Uferkante bietet einen Aussichtspunkt.
            if(noise.hash(gx,99,gz)>chance||h<=SEA+2||h>75||Math.hypot(x-7,z-52)<7)continue;
            boolean pine=bio==2;int trunk=pine?Blocks.PINE:Blocks.OAK,leaf=pine?Blocks.NEEDLES:Blocks.LEAVES;
            int len=pine?8+(int)(noise.hash(x,100,z)*5):5+(int)(noise.hash(x,100,z)*3);
            for(int y=1;y<=len;y++)put(a,minx,minz,x,h+y,z,trunk,true);
            if(pine){
                for(int yy=3;yy<=len+2;yy++){
                    int r=Math.max(0,(len+2-yy)/3);if(yy%3==0)r=Math.max(0,r-1);
                    for(int dx=-r;dx<=r;dx++)for(int dz=-r;dz<=r;dz++){
                        if(Math.abs(dx)+Math.abs(dz)>r*1.6||dx==0&&dz==0&&yy<=len)continue;
                        put(a,minx,minz,x+dx,h+yy,z+dz,leaf,false);
                    }
                }
            }else{
                for(int yy=len-2;yy<=len+2;yy++)for(int dx=-3;dx<=3;dx++)for(int dz=-3;dz<=3;dz++){
                    double d=dx*dx+dz*dz+(yy-len)*(yy-len)*1.8;
                    if(d>10.5+noise.hash(x+dx,yy,z+dz)*2||dx==0&&dz==0&&yy<=len)continue;
                    put(a,minx,minz,x+dx,h+yy,z+dz,leaf,false);
                }
            }
        }
        // Felsbrocken können einen Block über ihre Wurzel hinausragen.
        // Deshalb die Wurzeln auch jenseits des gepolsterten Chunkrandes prüfen.
        for(int lx=-1;lx<=PAD;lx++)for(int lz=-1;lz<=PAD;lz++){
            int x=minx+lx,z=minz+lz,h=height(x,z); if(h<=SEA+1||h>65)continue;
            double r=noise.hash(x,340,z);
            if(r<.14)put(a,minx,minz,x,h+1,z,r<.022?Blocks.FLOWER:Blocks.FERN,false);
            // Seltene moosige Felsbrocken als natürliche Landmarken.
            if(r>.998&&h>SEA+3)for(int dx=-1;dx<=1;dx++)for(int dz=-1;dz<=1;dz++)
                put(a,minx,minz,x+dx,h+1,z+dz,Blocks.MOSS,false);
        }
        // Kleine, verlassene Aussichtsterrasse nahe dem Start; keine Fremd-Assets.
        for(int x=9;x<=17;x++)for(int z=39;z<=45;z++){
            int ground=height(x,z),floor=34;
            for(int y=ground+1;y<floor;y++)if((x==9||x==17)&&(z==39||z==45))put(a,minx,minz,x,y,z,Blocks.DARK_WOOD,true);
            put(a,minx,minz,x,floor,z,Blocks.PLANKS,true);
            for(int y=floor+1;y<floor+4;y++)put(a,minx,minz,x,y,z,Blocks.AIR,true);
        }
        for(int x:new int[]{9,17}){put(a,minx,minz,x,35,39,Blocks.DARK_WOOD,true);put(a,minx,minz,x,36,39,Blocks.LANTERN,true);}
        return a;
    }
    public byte[] chunk(int cx,int cz){
        long key=chunkKey(cx,cz);byte[] base=cache.get(key);
        if(base==null){base=generate(cx,cz);cache.put(key,base);}
        byte[] a=base.clone();int minx=cx*16-1,minz=cz*16-1;
        for(int nx=cx-1;nx<=cx+1;nx++)for(int nz=cz-1;nz<=cz+1;nz++){
            Map<Integer,Byte> bucket=edits.get(chunkKey(nx,nz));if(bucket==null)continue;
            for(var e:bucket.entrySet()){
                int k=e.getKey(),x=nx*16+(k&15),z=nz*16+((k>>4)&15),y=k>>>8;
                int lx=x-minx,lz=z-minz;
                if(lx>=0&&lx<PAD&&lz>=0&&lz<PAD)a[index(lx,y+1,lz)]=e.getValue();
            }
        }
        return a;
    }
    public int get(int x,int y,int z){
        if(y<0)return Blocks.BEDROCK;if(y>=HEIGHT)return Blocks.AIR;
        int cx=Math.floorDiv(x,16),cz=Math.floorDiv(z,16);
        Map<Integer,Byte> bucket=edits.get(chunkKey(cx,cz));
        if(bucket!=null){Byte b=bucket.get(localKey(x,y,z));if(b!=null)return Byte.toUnsignedInt(b);}
        long key=chunkKey(cx,cz);byte[] a=cache.get(key);if(a==null){a=generate(cx,cz);cache.put(key,a);}
        return Byte.toUnsignedInt(a[index(Math.floorMod(x,16)+1,y+1,Math.floorMod(z,16)+1)]);
    }
    public synchronized void set(int x,int y,int z,int id){
        if(!inside(x,y,z)||!Blocks.valid(id)||y==0)throw new IllegalArgumentException("Ungültiger Block oder Weltgrenze.");
        var bucket=edits.computeIfAbsent(chunkKey(Math.floorDiv(x,16),Math.floorDiv(z,16)),k->new ConcurrentHashMap<>());
        int key=localKey(x,y,z);
        if(!bucket.containsKey(key)){if(editCount>=MAX_EDITS)throw new IllegalStateException("Änderungslimit dieser Welt erreicht.");editCount++;}
        bucket.put(key,(byte)id);
    }
    public synchronized int editCount(){return editCount;}
    public synchronized List<int[]> snapshot(){
        List<int[]> list=new ArrayList<>(editCount);
        for(var b:edits.entrySet()){
            int cx=(int)(b.getKey()>>32),cz=(int)(long)b.getKey();
            for(var e:b.getValue().entrySet()){int k=e.getKey();list.add(new int[]{cx*16+(k&15),k>>>8,cz*16+((k>>4)&15),Byte.toUnsignedInt(e.getValue())});}
        }
        list.sort(Comparator.<int[]>comparingInt(a->a[0]).thenComparingInt(a->a[2]).thenComparingInt(a->a[1]));
        return list;
    }
    public int[] spawn(){return new int[]{13,35,43};}
    public int cacheSize(){return cache.size();}
}
