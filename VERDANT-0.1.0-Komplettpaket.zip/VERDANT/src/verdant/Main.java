package verdant;

import com.sun.net.httpserver.*;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.*;

/**
 * VERDANT: lokaler Java-Weltserver plus hardwarebeschleunigter WebGL2-Renderer.
 * Keine Cloud, keine Downloads beim Start, keine Drittbibliotheken.
 * Der Listener ist absichtlich ausschließlich an 127.0.0.1 gebunden.
 */
public final class Main {
    private volatile World world;
    private final SaveStore store;
    private final String key;
    private final HttpServer server;
    private final ExecutorService workers=Executors.newFixedThreadPool(6);
    private final ScheduledExecutorService timer=Executors.newSingleThreadScheduledExecutor();
    private final String origin;
    private volatile boolean shuttingDown;
    private String warning="";
    private Main(int port,long seed,Path saves)throws IOException{
        store=new SaveStore(saves);
        try{world=store.load(seed);}catch(IOException e){
            try{world=store.recoverAndQuarantine(seed);warning="Die letzte Sicherung wurde geladen. Die Hauptdatei war beschädigt.";}
            catch(IOException noBackup){throw new IOException("Die Weltdatei ist beschädigt. Sie wurde nicht überschrieben. Verschiebe sie zur Sicherung oder starte mit --seed 12345 eine andere Welt.",e);}
        }
        byte[] bytes=new byte[24];new SecureRandom().nextBytes(bytes);key=HexFormat.of().formatHex(bytes);
        server=HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),port),32);
        origin="http://127.0.0.1:"+server.getAddress().getPort();server.setExecutor(workers);
        server.createContext("/",this::handle);
        timer.scheduleAtFixedRate(()->{try{if(!shuttingDown)store.save(world);}catch(IOException e){System.err.println("Autosave fehlgeschlagen: "+e.getMessage());}},60,60,TimeUnit.SECONDS);
    }
    private void send(HttpExchange e,int code,String type,byte[] body)throws IOException{
        e.getResponseHeaders().set("Content-Type",type);e.getResponseHeaders().set("X-Content-Type-Options","nosniff");
        e.getResponseHeaders().set("Cache-Control","no-store");e.getResponseHeaders().set("Cross-Origin-Resource-Policy","same-origin");
        e.getResponseHeaders().set("Content-Security-Policy","default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; worker-src 'self' blob:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'");
        e.sendResponseHeaders(code,body.length);try(OutputStream out=e.getResponseBody()){out.write(body);}
    }
    private void json(HttpExchange e,int code,Object o)throws IOException{send(e,code,"application/json; charset=utf-8",Json.write(o).getBytes(StandardCharsets.UTF_8));}
    private Map<String,Object> body(HttpExchange e)throws IOException{
        byte[] b=e.getRequestBody().readNBytes(32769);if(b.length>32768)throw new IllegalArgumentException("Anfrage zu groß");return Json.object(new String(b,StandardCharsets.UTF_8));
    }
    private static int integer(Map<String,Object> m,String key,int min,int max){double v=Json.number(m,key,Double.NaN);if(!Double.isFinite(v)||v!=Math.rint(v)||v<min||v>max)throw new IllegalArgumentException("Ungültiges Feld: "+key);return (int)v;}
    private Map<String,Object> config(){
        int[] s=world.spawn();Map<String,Object> m=new LinkedHashMap<>();m.put("version","0.1.0");m.put("seed",world.seed);m.put("height",World.HEIGHT);m.put("sea",World.SEA);m.put("spawn",List.of(s[0]+.5,s[1]+.02,s[2]+.5));m.put("player",Json.parse(world.metadata));m.put("edits",world.editCount());m.put("warning",warning);return m;
    }
    private void handle(HttpExchange e)throws IOException{
        try{
            String host=e.getRequestHeaders().getFirst("Host");String expected="127.0.0.1:"+server.getAddress().getPort();
            if(!expected.equals(host)){json(e,403,Map.of("error","Falscher Host"));return;}
            String o=e.getRequestHeaders().getFirst("Origin");if(o!=null&&!origin.equals(o)){json(e,403,Map.of("error","Fremder Ursprung"));return;}
            String path=e.getRequestURI().getPath();
            if(path.startsWith("/api/")){
                if(!key.equals(e.getRequestHeaders().getFirst("X-Verdant-Key"))){json(e,403,Map.of("error","Lokaler Sitzungsschlüssel fehlt"));return;}
                String method=e.getRequestMethod();World w=world;
                switch(path){
                    case "/api/config"->{if(!method.equals("GET"))throw new IllegalArgumentException("GET erwartet");json(e,200,config());}
                    case "/api/chunk"->{
                        if(!method.equals("GET"))throw new IllegalArgumentException("GET erwartet");Map<String,String> q=new HashMap<>();String raw=e.getRequestURI().getRawQuery();if(raw==null)throw new IllegalArgumentException("Chunkkoordinaten fehlen");
                        for(String p:raw.split("&")){String[] a=p.split("=",2);if(a.length==2)q.put(a[0],a[1]);}
                        int x=Integer.parseInt(q.getOrDefault("x","")),z=Integer.parseInt(q.getOrDefault("z",""));if(Math.abs((long)x)>3125||Math.abs((long)z)>3125)throw new IllegalArgumentException("Weltgrenze");
                        String seedText=q.get("seed");if(seedText==null||Long.parseLong(seedText)!=w.seed){json(e,409,Map.of("error","Welt wurde gewechselt"));return;}
                        send(e,200,"application/octet-stream",w.chunk(x,z));
                    }
                    case "/api/lod"->{
                        if(!method.equals("GET"))throw new IllegalArgumentException("GET erwartet");Map<String,String> q=new HashMap<>();String raw=e.getRequestURI().getRawQuery();if(raw==null)throw new IllegalArgumentException("Koordinaten fehlen");
                        for(String p:raw.split("&")){String[] a=p.split("=",2);if(a.length==2)q.put(a[0],a[1]);}
                        int x=Integer.parseInt(q.getOrDefault("x","")),z=Integer.parseInt(q.getOrDefault("z",""));if(Math.abs((long)x)>World.LIMIT||Math.abs((long)z)>World.LIMIT)throw new IllegalArgumentException("Weltgrenze");
                        if(Long.parseLong(q.getOrDefault("seed","-9999999999"))!=w.seed){json(e,409,Map.of("error","Welt wurde gewechselt"));return;}
                        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
                        for(int j=0;j<65;j++)for(int i=0;i<65;i++)out.writeShort(w.height(x+(i-32)*8,z+(j-32)*8));
                        send(e,200,"application/octet-stream",bytes.toByteArray());
                    }
                    case "/api/edit"->{
                        if(!method.equals("POST"))throw new IllegalArgumentException("POST erwartet");Map<String,Object> m=body(e);
                        if(Json.number(m,"seed",Double.NaN)!=w.seed){json(e,409,Map.of("error","Welt wurde gewechselt"));return;}
                        int x=integer(m,"x",-World.LIMIT,World.LIMIT),y=integer(m,"y",1,World.HEIGHT-1),z=integer(m,"z",-World.LIMIT,World.LIMIT),id=integer(m,"id",0,Blocks.COUNT-1);
                        w.set(x,y,z,id);json(e,200,Map.of("ok",true,"edits",w.editCount()));
                    }
                    case "/api/save"->{
                        if(!method.equals("POST"))throw new IllegalArgumentException("POST erwartet");Map<String,Object> m=body(e);
                        if(Json.number(m,"seed",Double.NaN)!=w.seed){json(e,409,Map.of("error","Welt wurde gewechselt"));return;}
                        Object p=m.get("player");if(!(p instanceof Map))throw new IllegalArgumentException("Spielerdaten fehlen");
                        String meta=Json.write(p);if(meta.length()>28000)throw new IllegalArgumentException("Spielerdaten zu groß");w.metadata=meta;store.save(w);json(e,200,Map.of("ok",true));
                    }
                    case "/api/world"->{
                        if(!method.equals("POST"))throw new IllegalArgumentException("POST erwartet");Map<String,Object> m=body(e);double n=Json.number(m,"seed",Double.NaN);if(!Double.isFinite(n)||Math.abs(n)>1_000_000_000||n!=Math.rint(n))throw new IllegalArgumentException("Seed muss eine ganze Zahl zwischen -1 Milliarde und 1 Milliarde sein");
                        synchronized(this){store.save(world);world=store.load((long)n);warning="";}json(e,200,config());
                    }
                    case "/api/status"->json(e,200,Map.of("ok",true,"seed",w.seed,"edits",w.editCount(),"cached",w.cacheSize()));
                    case "/api/quit"->{if(!method.equals("POST"))throw new IllegalArgumentException("POST erwartet");store.save(w);json(e,200,Map.of("ok",true));new Thread(()->{try{Thread.sleep(200);}catch(InterruptedException ignored){}close();System.exit(0);},"verdant-exit").start();}
                    default->json(e,404,Map.of("error","Endpunkt nicht gefunden"));
                }
                return;
            }
            if(!e.getRequestMethod().equals("GET")){json(e,405,Map.of("error","GET erwartet"));return;}
            if(path.equals("/"))path="/index.html";
            if(path.contains("..")||path.contains("\\")||path.length()>160){json(e,400,Map.of("error","Ungültiger Pfad"));return;}
            try(InputStream in=Main.class.getResourceAsStream("/web"+path)){
                if(in==null){json(e,404,Map.of("error","Datei nicht gefunden"));return;}
                byte[] data=in.readAllBytes();if(path.equals("/index.html"))data=new String(data,StandardCharsets.UTF_8).replace("__SESSION_KEY__",key).getBytes(StandardCharsets.UTF_8);
                String mime=path.endsWith(".html")?"text/html; charset=utf-8":path.endsWith(".js")?"text/javascript; charset=utf-8":path.endsWith(".css")?"text/css; charset=utf-8":path.endsWith(".svg")?"image/svg+xml":path.endsWith(".glsl")?"text/plain; charset=utf-8":"application/octet-stream";
                send(e,200,mime,data);
            }
        }catch(IllegalArgumentException|IllegalStateException ex){json(e,400,Map.of("error",ex.getMessage()==null?"Ungültige Anfrage":ex.getMessage()));}
        catch(Exception ex){System.err.println("Anfrage fehlgeschlagen: "+ex);try{json(e,500,Map.of("error","Interner Fehler. Details im Java-Fenster."));}catch(IOException ignored){}}
        finally{e.close();}
    }
    private synchronized void close(){
        if(shuttingDown)return;shuttingDown=true;try{store.save(world);}catch(IOException e){System.err.println("Speichern beim Beenden fehlgeschlagen: "+e.getMessage());}server.stop(0);workers.shutdownNow();timer.shutdownNow();
    }
    public static void main(String[] args){
        int port=0;long seed=734812;boolean browse=true;Path saves=Path.of(System.getProperty("user.home"),".verdant","welten");
        try{
            for(int i=0;i<args.length;i++)switch(args[i]){case "--port"->port=Integer.parseInt(args[++i]);case "--seed"->seed=Long.parseLong(args[++i]);case "--no-browser"->browse=false;case "--save-dir"->saves=Path.of(args[++i]);default->throw new IllegalArgumentException("Unbekannte Option: "+args[i]);}
            if(seed < -1_000_000_000L || seed > 1_000_000_000L)throw new IllegalArgumentException("Seed außerhalb des Bereichs");
            Main app=new Main(port,seed,saves);Runtime.getRuntime().addShutdownHook(new Thread(app::close,"verdant-save"));app.server.start();
            System.out.println("\n  V E R D A N T  /  Voxel-Sandbox 0.1\n");System.out.println("  Spiel öffnen: "+app.origin);System.out.println("  Spielstände: "+saves.toAbsolutePath());System.out.println("  Offline. Nur 127.0.0.1. Kein Konto.\n  Dieses Fenster geöffnet lassen. Zum Beenden: Strg+C oder Spielmenü.\n");
            if(!app.warning.isEmpty())System.out.println(app.warning);
            if(browse)try{if(Desktop.isDesktopSupported()&&Desktop.getDesktop().isSupported(Desktop.Action.BROWSE))Desktop.getDesktop().browse(URI.create(app.origin));else System.out.println("  Bitte die obige Adresse im Browser öffnen.");}catch(Exception e){System.out.println("  Bitte die obige Adresse im Browser öffnen.");}
        }catch(Exception e){System.err.println("VERDANT konnte nicht starten: "+e.getMessage());e.printStackTrace();System.exit(1);}
    }
}
