package verdant;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Atomare lokale Spielstände mit GZIP-Prüfsumme und letzter Sicherung. */
public final class SaveStore {
    private static final int MAGIC=0x56455244,VERSION=1;
    private final Path dir;
    public SaveStore(Path dir)throws IOException{this.dir=dir;Files.createDirectories(dir);}
    public Path path(long seed){return dir.resolve("welt-"+seed+".vdt");}
    public synchronized void save(World world)throws IOException{
        byte[] meta=world.metadata.getBytes(StandardCharsets.UTF_8);
        if(meta.length>32768)throw new IOException("Spielerdaten zu groß");
        Json.object(world.metadata);List<int[]> changes=world.snapshot();
        Path destination=path(world.seed),temp=destination.resolveSibling(destination.getFileName()+".tmp");
        try(OutputStream file=Files.newOutputStream(temp);GZIPOutputStream gz=new GZIPOutputStream(file);DataOutputStream out=new DataOutputStream(gz)){
            out.writeInt(MAGIC);out.writeInt(VERSION);out.writeLong(world.seed);out.writeInt(meta.length);out.write(meta);out.writeInt(changes.size());
            for(int[] b:changes){out.writeInt(b[0]);out.writeByte(b[1]);out.writeInt(b[2]);out.writeByte(b[3]);}
        }
        if(Files.exists(destination))Files.copy(destination,destination.resolveSibling(destination.getFileName()+".bak"),StandardCopyOption.REPLACE_EXISTING);
        try{Files.move(temp,destination,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
        catch(AtomicMoveNotSupportedException e){Files.move(temp,destination,StandardCopyOption.REPLACE_EXISTING);}
    }
    public synchronized World load(long seed)throws IOException{
        Path file=path(seed);if(!Files.exists(file))return new World(seed);
        return read(file,seed);
    }
    public World read(Path file,long expectedSeed)throws IOException{
        if(Files.size(file)>16*1024*1024)throw new IOException("Spielstand zu groß");
        try(DataInputStream in=new DataInputStream(new GZIPInputStream(Files.newInputStream(file)))){
            if(in.readInt()!=MAGIC||in.readInt()!=VERSION)throw new IOException("Unbekanntes Speicherformat");
            long seed=in.readLong();if(seed!=expectedSeed)throw new IOException("Seed passt nicht zur Weltdatei");
            int len=in.readInt();if(len<2||len>32768)throw new IOException("Ungültige Spielerdaten");
            byte[] mb=in.readNBytes(len);if(mb.length!=len)throw new EOFException();String meta=new String(mb,StandardCharsets.UTF_8);Json.object(meta);
            int count=in.readInt();if(count<0||count>World.MAX_EDITS)throw new IOException("Ungültige Anzahl Änderungen");
            World w=new World(seed);w.metadata=meta;
            for(int i=0;i<count;i++)w.set(in.readInt(),in.readUnsignedByte(),in.readInt(),in.readUnsignedByte());
            if(w.editCount()!=count)throw new IOException("Doppelte Blockänderungen im Spielstand");
            if(in.read()!=-1)throw new IOException("Unerwartete Daten am Dateiende");return w;
        }catch(IllegalArgumentException|IllegalStateException e){throw new IOException("Beschädigter Spielstand: "+e.getMessage(),e);}
    }
    public synchronized World recover(long seed)throws IOException{return read(path(seed).resolveSibling(path(seed).getFileName()+".bak"),seed);}
    /** Erst nach erfolgreichem Lesen der Sicherung die defekte Hauptdatei archivieren. */
    public synchronized World recoverAndQuarantine(long seed)throws IOException{
        World recovered=recover(seed);Path main=path(seed);
        if(Files.exists(main))Files.move(main,main.resolveSibling(main.getFileName()+".corrupt-"+System.currentTimeMillis()));
        return recovered;
    }
    public Path directory(){return dir;}
}
