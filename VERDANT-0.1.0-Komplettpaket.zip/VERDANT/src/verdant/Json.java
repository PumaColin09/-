package verdant;

import java.util.*;

/** Kleiner JSON-Parser ohne zusätzliche Bibliotheken. Tiefe und Zahlen sind begrenzt. */
public final class Json {
    private Json(){}
    public static Object parse(String text){Parser p=new Parser(text);Object o=p.value(0);p.ws();if(p.i!=text.length())throw new IllegalArgumentException("Daten nach JSON-Ende");return o;}
    @SuppressWarnings("unchecked") public static Map<String,Object> object(String text){Object o=parse(text);if(!(o instanceof Map))throw new IllegalArgumentException("JSON-Objekt erwartet");return (Map<String,Object>)o;}
    public static String write(Object o){
        if(o==null)return "null";
        if(o instanceof String s){StringBuilder b=new StringBuilder("\"");for(char c:s.toCharArray())switch(c){case '"'->b.append("\\\"");case '\\'->b.append("\\\\");case '\n'->b.append("\\n");case '\r'->b.append("\\r");case '\t'->b.append("\\t");default->{if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}}return b.append('"').toString();}
        if(o instanceof Number n){if(!Double.isFinite(n.doubleValue()))throw new IllegalArgumentException("Keine endliche Zahl");return o.toString();}
        if(o instanceof Boolean)return o.toString();
        if(o instanceof Map<?,?> m){StringJoiner j=new StringJoiner(",","{","}");m.forEach((k,v)->j.add(write(k.toString())+":"+write(v)));return j.toString();}
        if(o instanceof Iterable<?> a){StringJoiner j=new StringJoiner(",","[","]");a.forEach(v->j.add(write(v)));return j.toString();}
        throw new IllegalArgumentException("Nicht unterstützter JSON-Typ");
    }
    public static double number(Map<String,Object> map,String key,double fallback){Object v=map.get(key);return v instanceof Number n?n.doubleValue():fallback;}
    private static final class Parser {
        final String s;int i;
        Parser(String s){this.s=s;}
        void ws(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;}
        boolean take(char c){ws();if(i<s.length()&&s.charAt(i)==c){i++;return true;}return false;}
        void require(char c){if(!take(c))throw new IllegalArgumentException("JSON: '"+c+"' bei "+i+" erwartet");}
        Object value(int depth){
            if(depth>20)throw new IllegalArgumentException("JSON zu tief");ws();if(i>=s.length())throw new IllegalArgumentException("JSON unvollständig");char c=s.charAt(i);
            if(c=='"')return string();
            if(c=='{'){i++;Map<String,Object> m=new LinkedHashMap<>();if(take('}'))return m;do{ws();String k=string();require(':');if(m.containsKey(k))throw new IllegalArgumentException("Doppelter Schlüssel");m.put(k,value(depth+1));}while(take(','));require('}');return m;}
            if(c=='['){i++;List<Object>a=new ArrayList<>();if(take(']'))return a;do{a.add(value(depth+1));if(a.size()>4096)throw new IllegalArgumentException("Array zu groß");}while(take(','));require(']');return a;}
            for(String k:new String[]{"true","false","null"})if(s.startsWith(k,i)){i+=k.length();return k.equals("null")?null:k.equals("true");}
            int start=i;if(s.charAt(i)=='-')i++;
            if(i>=s.length()||!Character.isDigit(s.charAt(i)))throw new IllegalArgumentException("JSON-Zahl erwartet");
            if(s.charAt(i)=='0')i++;else while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;
            if(i<s.length()&&s.charAt(i)=='.'){i++;int a=i;while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;if(i==a)throw new IllegalArgumentException("Dezimalstellen fehlen");}
            if(i<s.length()&&(s.charAt(i)=='e'||s.charAt(i)=='E')){i++;if(i<s.length()&&(s.charAt(i)=='+'||s.charAt(i)=='-'))i++;int a=i;while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;if(i==a)throw new IllegalArgumentException("Exponent fehlt");}
            double n=Double.parseDouble(s.substring(start,i));if(!Double.isFinite(n))throw new IllegalArgumentException("Zahl außerhalb des Bereichs");return n;
        }
        String string(){
            ws();if(i>=s.length()||s.charAt(i++)!='"')throw new IllegalArgumentException("JSON-Text erwartet");StringBuilder b=new StringBuilder();
            while(i<s.length()){char c=s.charAt(i++);if(c=='"')return b.toString();if(c<32)throw new IllegalArgumentException("Steuerzeichen in JSON");
                if(c=='\\'){if(i>=s.length())throw new IllegalArgumentException("Escape unvollständig");char e=s.charAt(i++);switch(e){case '"','\\','/'->b.append(e);case 'n'->b.append('\n');case 'r'->b.append('\r');case 't'->b.append('\t');case 'b'->b.append('\b');case 'f'->b.append('\f');case 'u'->{if(i+4>s.length())throw new IllegalArgumentException("Unicode unvollständig");b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;}default->throw new IllegalArgumentException("Ungültiges Escape");}}
                else b.append(c);
            }
            throw new IllegalArgumentException("JSON-Text unvollständig");
        }
    }
}
