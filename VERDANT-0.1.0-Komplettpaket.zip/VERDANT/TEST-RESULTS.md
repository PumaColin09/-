# VERDANT 0.1.0 · Prüfergebnisse

Stand: 17.09.2026. Die Ergebnisse stammen aus ausgeführten Tests dieser Version.
Sie sind keine Garantie für Fehlerfreiheit, vollständige Testabdeckung oder eine
bestimmte Bildrate auf anderer Hardware.

## Ergebnis

| Bereich | Bestanden | Umfang |
|---|---:|---|
| Java-Kerntests | 63 / 63 | Noise, Welt, Chunknähte, Blockänderungen, JSON, Speicherformat, Sicherung und Recovery. |
| Client-Kerntests | 50 / 50 | Mathematik, Meshing, Materialien, Blockauswahl, Kollision, Bewegung, Flug und Sauerstoff. |
| HTTP-/Prozessintegration | 42 / 42 | Echter Java-Prozess, Ressourcen aus JAR, API-Prüfungen, parallele Änderungen, Datei-/Weltwechsel und Beenden. |
| UI-/Renderintegration | 41 / 41 | Echter WebGL-2-Renderer, Maussteuerung, Oberfläche, Herstellung, Spielaktionen, Speichern, Weltwechsel und PNG-Export. |
| **Gesamt** | **196 / 196** | Einzelne Assertions enthalten zusätzlich mehrere Daten-/Geometrieprüfungen. |

Die Rohprotokolle stehen in `reports/`. Die Testquellen sind mitgeliefert. Die
Screenshots unter `screenshots/` wurden mit dem echten Renderer erzeugt, nicht
mit einem Bildgenerator. In der Startansicht waren 293 detaillierte Chunks und
die Fernsichtgeometrie geladen. Alle acht Shaderprogramme wurden erfolgreich
kompiliert und gelinkt. Beim Rendern der drei Grafikprofile sowie der Tag-,
Abend-, Nacht- und Regenansichten lieferte `gl.getError()` keinen Fehler.

## Testumgebung

- Linux 6.18.44, Containerumgebung.
- OpenJDK 21.0.11; kompiliert mit `javac --release 17 -encoding UTF-8`.
- Node.js 22.16.0 für die Client-Kerntests.
- Python 3.13.5 für HTTP-Tests und den Browserharness.
- Chromium 144.0.7559.96 unter Xvfb mit Playwright.
- WebGL 2 über ANGLE und **SwiftShader**, also einen Software-GPU-Renderer.
- Rendergerätekennung: `ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) (0x0000C0DE)), SwiftShader driver)`.
- Vorschauauflösung 1440×900; HDR-Erweiterung im Test verfügbar.

### Besonderheit der Browserprüfung

Die verwaltete Browserumgebung dieser Entwicklung sperrt gewöhnliche
URL-Navigation. Diese Richtlinie wurde nicht verändert. Daher wurden unsere
eigenen HTML-/CSS-/JS-/Shaderquellen in eine leere Offline-Testseite eingebracht.
Die gleichen eigenen ES-Module wurden dazu in ihrer Abhängigkeitsreihenfolge
gebündelt; eigene Workerquellen wurden als Blob-Worker geladen. Ein lokaler
Python-Testadapter leitete API-Aufrufe an den **wirklich laufenden Java-Server**
weiter. Es wurden keine Kurs-/Welt-/Inventardaten durch Attrappen ersetzt.

Die normalen statischen Ressourcen samt MIME-Typen wurden zusätzlich direkt
gegen die ausgelieferte JAR über HTTP geprüft. Normale Navigation vom Browser
zur lokalen URL und der automatische Aufruf des Standardbrowsers wurden in
dieser Umgebung jedoch nicht als kompletter Endnutzer-Startweg ausgeführt.
Die Tests belegen deshalb nicht, dass beliebige Browserrichtlinien, Windows-
Installationen oder GPU-Treiber damit funktionieren.

Für reine Geometrie-Ladephasen setzte der Harness überflüssige Software-GPU-Frames
aus. Anschließend wurden vollständige Renderdurchgänge derselben Pipeline
kontrolliert ausgeführt. Das ist eine Funktionsprüfung, **kein Echtzeit-FPS-
Benchmark**. Die Startvorschau wurde außerdem zuvor mit laufender Spielschleife
geprüft. Die Bildrate dieser Software-GPU ist nicht auf eine Consumer-Grafikkarte
übertragbar.

## Geprüfte kritische Abläufe

### Java und Speichern

Reproduzierbarkeit bei gleichen Seeds; Variation bei anderen Seeds; gültige
Material- und Höhenbereiche; Schutz des Grundgesteins; freie Startposition;
positive und negative Chunkübergänge einschließlich Änderungen; keine Mutation
des Grundcaches durch Kopien. JSON-Größen-/Tiefen-/Zahlengrenzen und doppelte
Schlüssel werden geprüft. Speicher-Rundläufe erhalten Metadaten und alle
veränderten Blockpositionen. Abgeschnittene Dateien und falsche Seeds werden
abgewiesen. Nach Recovery bleibt die Sicherung gültig und eine beschädigte
Hauptdatei wird erst nach erfolgreichem Lesen der Sicherung archiviert.

### Mesh und Spieler

Leere Chunks erzeugen keine Geometrie. Einzelwürfel, zusammengefasste Nachbarn,
verdeckte Chunkrand-Flächen, separate Glasgeometrie, Wasseroberflächen und
gekreuzte Pflanzenquads werden geprüft. Vertexwerte sind endlich, Dreiecke
haben die erwartete Orientierung. DDA trifft den ersten Block, liefert die
richtige Platziernormale und überspringt Wasser. Kollisionen blockieren auch
ungeladene Chunks. Sprung, stabile Landung, Laufdistanz, Flug, Fotokamera,
Ladevalidierung, Sauerstoffverbrauch, Schaden und Respawn wurden ausgeführt.

### API und Prozess

Getrennte temporäre Testspielstände statt Benutzerdateien. Fehlende/falsche
Sitzungsschlüssel, fremde Origins, falsche Hosts, Pfad-Traversal, ungültige
Koordinaten, IDs, Methoden, Bruchzahl-Seeds, fehlerhafte und übergroße Anfragen
werden abgewiesen. 40 parallele Änderungen zusätzlich zu einem Ausgangsblock
bleiben als 41 Einträge erhalten. Alle Spielmodule und 13 GLSL-Dateien kommen aus
der JAR. Ein kontrollierter Quit-Aufruf speichert und beendet den Java-Prozess.

Das ist keine vollständige Sicherheitsanalyse oder ein Penetrationstest. Der
Server ist ausschließlich für lokalen Einzelspielerbetrieb vorgesehen.

### Oberfläche und Grafik

Der echte Startknopf aktiviert Pointer Lock. Hotbar, Zifferntaste, Flugtaste und
Inventartaste reagieren. Die UI zeigt 27 Materialien, filtert Lichtmaterialien
und weist angeklickte Materialien einem Slot zu. Die Werkbank verbraucht bei
Mehrfachherstellung nur vorhandene Zutaten und stoppt Werkzeug-Upgrades bei
Stufe vier. Modus- und Grafikprofilwechsel wurden über die tatsächlichen
Einstellungscontrols ausgelöst.

Platzierung und Abbau gingen durch die normalen Spielmethoden zum Java-Server;
eine erneute Java-Chunkabfrage bestätigte den Block. Inventarverbrauch,
Materialrückgabe, Kreativ-Rückgängig und Platzierungsverbot innerhalb des
Spielerkörpers wurden geprüft. Speichern und Weltwechsel erhalten Fortschritt,
Werkzeug und Inventar; Grafik-/Modusoptionen liegen im Java-Spielstand.
Fotokamera und Spielerposition bleiben getrennt. F2 erzeugte eine tatsächliche
herunterladbare PNG-Datei. Während dieses Durchlaufs trat kein ungefangener
JavaScript-Fehler auf.

## Nicht praktisch verifiziert

- Start auf einem realen Windows- oder macOS-Rechner und im Nutzer-Standardbrowser.
- NVIDIA-, AMD- oder Intel-GPU-Leistung, Treiberkompatibilität und VRAM-Verbrauch.
- Firefox/Safari-Verhalten, weitere Bildschirmgrößen, HiDPI- und Mehrmonitorfälle.
- Der Standardfarbtiefen-Fallback auf einem Gerät ohne HDR-Erweiterung.
- Längere Spielsessions, sehr große Spielerbauten oder Annäherung an das
  Änderungslimit von 250.000 Positionen.
- Stromausfall-Szenarien, defekte Datenträger und gleichzeitige Mehrprozesszugriffe.
- Eine vollständige manuelle Runde durch jede mögliche Eingabe- und Menüfolge.

## Tests selbst ausführen

Im Projektverzeichnis, nach `build.sh` bzw. `BUILD-WINDOWS.cmd`:

```sh
sh test-java.sh
node --experimental-default-type=module tests/client-tests.mjs
python tests/http-tests.py
```

Unter Windows stehen die Java-Tests auch über `TEST-WINDOWS.cmd` bereit. Node und
Python werden nur für die zusätzlichen Tests benötigt. Der Browserharness unter
`tools/` ist speziell für die beschriebene Entwicklungsumgebung gedacht und
benötigt Playwright, Requests, Chromium und Xvfb. Die Spielanwendung selbst
benötigt diese Werkzeuge nicht.
