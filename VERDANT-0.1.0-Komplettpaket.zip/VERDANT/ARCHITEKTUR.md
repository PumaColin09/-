# VERDANT · Architektur und Code-Wegweiser

## Der Weg vom Startknopf zum sichtbaren Block

```text
START-WINDOWS.cmd / start.sh
            │
            ▼
VERDANT.jar → Java Main → HTTP ausschließlich auf 127.0.0.1
            │                    │
            │                    └─ HTML, CSS, JS und GLSL aus der JAR
            ▼                                   │
Java World / Noise / SaveStore                   ▼
            │                      Browser: app.js / Player / UI
            │                                   │
            └─ gepolsterte Chunkdaten → VoxelWorld → Mesh-WebWorker
                                                    │
                                                    ▼
                                            Renderer → WebGL 2
                                                    │
                                                    ▼
                                         Schatten, Spiegelung,
                                         Oberflächen und Wasser
                                                    │
                                                    ▼
                                              Postprocessing
```

Ein Pixel auf dem See entsteht aus mehreren Zeichendurchgängen. Eine Blockänderung
wird zuerst vom Java-Server bestätigt, anschließend lokal in den Chunkdaten
aktualisiert und in einem Worker neu vermesht. Eine fehlgeschlagene Serveroperation
zieht kein Baumaterial ab. Es werden nicht einfach über einem unveränderlichen
Hintergrund dekorative Würfel dargestellt.

## Java: `src/verdant/`

| Datei | Aufgabe |
|---|---|
| `Main.java` | Einstiegspunkt, Startoptionen, lokaler HTTP-Server, Sitzungsschlüssel, statische Ressourcen und API. |
| `World.java` | Terrain, Gewässer, Höhlen, Erze, Pflanzen, Bäume, Spawnterrasse, Chunkcache, Blockänderungen. |
| `Noise.java` | Seed-basierte Hash- und Noise-Funktionen ohne externen Zufallsdienst. |
| `Blocks.java` | Stabile Material-IDs und grundlegende Kollisionsklassifizierung. |
| `SaveStore.java` | Binäre GZIP-Spielstände, Validierung, Sicherung und Quarantäne beschädigter Hauptdateien. |
| `Json.java` | Kleiner begrenzter Parser/Serializer für lokale Metadaten und Anfragen. |

Die Welt besteht aus 16×128×16-Blöcken je Chunk. Zur Berechnung von Nachbarflächen,
Beleuchtung und Pflanzenrändern enthält der übertragene Chunk auf allen Seiten
einen zusätzlichen Block: 18×130×18 Bytes. Der lokale Index im Java-Array lautet
`(y * 18 + z) * 18 + x`; die Nutzdaten sind um einen Block versetzt.

Grundwelt und Änderungen sind getrennt. Der LRU-Cache hält bis zu 320 unveränderte
Chunkgrundlagen, Spieleränderungen liegen in separaten Maps. Jede Chunkabfrage
liefert eine Kopie mit darübergelegten Änderungen, auch aus angrenzenden Chunks.
Eine Koordinate wird mit ganzzahliger Division nach unten einem Chunk zugeordnet;
das ist insbesondere bei negativen Koordinaten wichtig.

Wurzeln von Bäumen und Felsbrocken werden über den eigenen Chunkrand hinaus geprüft.
So hängt ihre Form nicht davon ab, in welcher Reihenfolge die Chunks geladen werden.
Das Terrain ist in dieser Version absichtlich um ein gestaltetes Tal angeordnet;
ein anderer Seed erzeugt eine Variante davon, nicht ein beliebiges, völlig anderes
Biome-System.

## Browser: `resources/web/`

| Datei | Aufgabe |
|---|---|
| `index.html` / `style.css` | Startbildschirm, HUD, transparente Menüs, Inventar, Einstellungen, Meldungen. |
| `app.js` | Spielschleife, Tastatur/Maus, Regeln, Rezepte, Inventar, Erfolge, Fotomodus und Speichersynchronisierung. |
| `player.js` | Bewegung, Beschleunigung, Gravitation, Sprung, Achsenkollision, Flug, Schwimmen, Sauerstoff und Sturzschaden. |
| `world.js` | Chunk-Ladewarteschlange, Änderungen, Worker-Verwaltung, DDA-Blockauswahl, Kollision, Fernsicht. |
| `mesher.js` | Greedy-Meshing, transparente und opake Oberflächen, Vertex-AO, vereinfachtes Himmelslicht, Pflanzen. |
| `worker.js` | Worker-Einstieg: Binärdaten empfangen und fertige Vertexarrays zurückgeben. |
| `renderer.js` | WebGL-Objekte, Renderziele, Shaderprogramme, Grafikprofile, Renderdurchgänge und Screenshots. |
| `materials.js` | Materialnamen, Farben, Härte, prozedurale Albedo-/Normal-/Rauheitstexturen und Würfel-Icons. |
| `math.js` | Vektoren, Kameras, Projektion, Matrixinversion und Frustum-Prüfung. |
| `audio.js` | Prozeduraler Wind/Regen, kurze Töne, Schritte und Effektklänge. |
| `shaders/` | 13 originale GLSL-Quelldateien für acht gelinkte Shaderprogramme. |

JavaScript ist hier nicht ein anderer Name für Java. Es sind zwei getrennte
Sprachen mit unterschiedlichen Aufgaben. Der Renderer nutzt WebGL 2 direkt,
keine Three.js-, Babylon.js- oder andere externe Grafikbibliothek.

## Renderdurchgänge

1. **Schatten:** opake Geometrie einschließlich Alpha-Ausschnitten der Vegetation
   aus Sicht der Sonne in eine Tiefentextur zeichnen.
2. **Spiegelung:** Kamera an der Wasserhöhe spiegeln; Himmel und Geometrie oberhalb
   des Wassers in ein kleineres Renderziel zeichnen.
3. **Opake Szene:** Himmel, entfernte Höhenlandschaft und sichtbare detaillierte
   Chunks zeichnen. Texturen und Normalmaps kommen aus 2D-Texturarrays.
4. **Wasser:** vorherige Szenenfarbe/-tiefe und planare Spiegelung auswerten.
   Wellennormalen beeinflussen Spiegelung, Brechung, Fresnel und Glanz.
5. **Transparenz und Effekte:** Glas/Eis auf Chunkebene von hinten nach vorne,
   Zielumrandung und Partikel ergänzen.
6. **Nachbearbeitung:** helle Bildanteile weichzeichnen und addieren; SSAO aus
   Szenentiefe, Belichtung, filmische Tonwerte, Kantenfilter, Vignette und
   Unterwasserdarstellung im abschließenden Durchgang auswerten.

Ein Vertex besitzt elf 32-Bit-Floats: Position (3), Normale (3), UV (2),
Materiallage (1), Umgebungsverdeckung (1), Himmelslichtfaktor (1).

Der Horizon-LOD erhält 65×65 Höhenwerte mit acht Blöcken Abstand. Daraus entstehen
zwei Dreiecke pro Gitterzelle. Ein Distanzübergang blendet ihn im Nahbereich aus.
Diese Vereinfachung reduziert Ferngelände-Kosten; sie ist keine echte
Multi-Resolution-Version aller Bäume, Höhlen und Spielergebäude.

## HTTP-Schnittstelle

Alle `/api/`-Routen verlangen den beim Start neu erzeugten `X-Verdant-Key`.
Ein fremder `Origin` sowie ein anderer `Host` werden abgewiesen. Der Listener
bindet nur an `127.0.0.1`, nicht an alle Netzwerkschnittstellen.

| Route | Methode | Aufgabe |
|---|---|---|
| `/api/config` | GET | Seed, Startposition und gespeicherten Spielerzustand lesen. |
| `/api/chunk?x=...&z=...&seed=...` | GET | Gepolsterte binäre Blockdaten lesen. |
| `/api/lod?x=...&z=...&seed=...` | GET | Fernsicht-Höhenwerte als Big-Endian-Unsigned-Shorts lesen. |
| `/api/edit` | POST | Eine validierte Blockposition ändern. |
| `/api/save` | POST | Spielermetadaten übernehmen und Welt schreiben. |
| `/api/world` | POST | Aktuelle Welt sichern und einen anderen Seed öffnen. |
| `/api/status` | GET | Aktive Welt, Änderungs- und Cachezahl lesen. |
| `/api/quit` | POST | Speichern und den lokalen Java-Prozess beenden. |

Dies ist eine Einzelspieler-Schnittstelle, keine Multiuser-Authentifizierung oder
geprüfte öffentliche Serverplattform. Die Java-Seite validiert Datenformate,
Koordinaten und IDs; viele Spielregeln, beispielsweise Herstellung und Inventar,
liegen bewusst im Client. Ein lokaler Nutzer mit Zugriff auf Quellcode oder
Entwicklertools kann seinen eigenen Spielstand verändern.

## Kleine Änderungen zum Einstieg

**Ein anderes Baumaterial im Startinventar:** In `app.js` die IDs in
`DEFAULT_BAR` ändern. Ihre Namen stehen in `materials.js`; dieselben stabilen IDs
müssen zu `Blocks.java` passen. Nicht einfach bestehende IDs neu sortieren, sonst
bedeutet ein gespeicherter Block plötzlich ein anderes Material.

**Mehr Startmaterial in der Expedition:** Die Inventarwerte im Konstruktor und
im Fallback von `loadConfig` gemeinsam anpassen. Bestehende gespeicherte Inventare
werden absichtlich nicht überschrieben.

**Andere Wolken oder Wasserfarben:** `sky.frag.glsl` bzw. `water.frag.glsl` ändern.
Nach dem Kompilieren/Verpacken die JAR neu starten. Ein GLSL-Syntaxfehler erscheint
auf der Fehlerkarte; der Shadername ist in der Meldung enthalten.

**Ein neues Rezept:** In `app.js` `RECIPES` erweitern. `needs` enthält Material-ID
und benötigte Anzahl, `out` das Zielmaterial und `qty` die Produktionsmenge.
Die bestehende `craft`-Methode übernimmt Verbrauch und Mengenprüfung.

**Andere Berge:** In `World.height()` werden Grundniveau, Seemulde und alpine
Höhen addiert. Änderungen am Generator verändern die unveränderte Landschaft
bestehender Seeds. Zum Experimentieren einen neuen Seed verwenden und vorher
Spielstände sichern.

## Weiterentwicklung und technische Schulden

Die nächste sinnvolle Arbeit wäre nicht das Hinzufügen möglichst vieler zufälliger
Features, sondern echte Hardware-Benchmarks, Render-Batching, bessere transparente
Sortierung, Dachabschirmung von Regen, Dateisperren für Mehrfachstarts und weitere
Regressionstests. Danach lassen sich Flüssigkeiten, neue Biome oder Kreaturen als
separate Systeme ergänzen. Diese Punkte sind nicht als bereits vorhandene
Funktionen zu verstehen.
