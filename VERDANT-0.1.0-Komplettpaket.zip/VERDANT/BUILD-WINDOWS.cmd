@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where javac >nul 2>nul
if errorlevel 1 (
    echo Zum Kompilieren wird ein JDK ab Version 17 benoetigt.
    pause
    exit /b 1
)
if not exist "build\classes" mkdir "build\classes"
javac --release 17 -encoding UTF-8 -d "build\classes" src\verdant\*.java
if errorlevel 1 goto failed
jar --create --file "VERDANT.jar" --main-class verdant.Main -C "build\classes" verdant -C resources web
if errorlevel 1 goto failed
echo VERDANT.jar ist fertig. Jetzt START-WINDOWS.cmd oeffnen.
pause
exit /b 0
:failed
echo Erstellung fehlgeschlagen. Fehlermeldung oben pruefen.
pause
exit /b 1
