package verdant;

import java.nio.file.*;
import java.util.*;

/** Ausführbare Tests ohne JUnit oder andere Downloads. */
public final class VerdantTest {
    static int checks,failed;
    static void check(String name,boolean ok){checks++;System.out.println((ok?"PASS ":"FAIL ")+name);if(!ok)failed++;}
    interface Action {void run()throws Exception;}
    static void rejects(String name,Action action){try{action.run();check(name,false);}catch(Exception e){check(name,true);}}
    static void seam(World w,int ax,int az,int bx,int bz){
        byte[] a=w.chunk(ax,az),b=w.chunk(bx,bz);boolean okay=true;int mismatch=0;
        for(int x=Math.max(ax*16-1,bx*16-1);x<=Math.min(ax*16+16,bx*16+16);x++)for(int z=Math.max(az*16-1,bz*16-1);z<=Math.min(az*16+16,bz*16+16);z++)for(int y=0;y<World.HEIGHT;y++){
            if(a[World.index(x-ax*16+1,y+1,z-az*16+1)]!=b[World.index(x-bx*16+1,y+1,z-bz*16+1)]){okay=false;mismatch++;}
        }
        check("Chunknaht "+ax+","+az+" / "+bx+","+bz+" (Abweichungen: "+mismatch+")",okay);
    }
    public static void main(String[] args)throws Exception{
        long start=System.nanoTime();Noise n=new Noise(734812),n2=new Noise(734812),other=new Noise(934812);boolean bounded=true,repeat=true,distinct=false;
        for(int i=-50;i<50;i++){double v=n.n3(i*.173,i*.051,i*.09);bounded&=v>=0&&v<=1;repeat&=v==n2.n3(i*.173,i*.051,i*.09);distinct|=v!=other.n3(i*.173,i*.051,i*.09);}
        check("3D-Noise im Wertebereich",bounded);check("Noise reproduzierbar",repeat);check("Andere Seeds verändern Noise",distinct);
        check("2D-Noise an Gitterpunkt",n.n2(4,7)==n.hash(4,0,7));check("Noise stetig an Gittergrenze",Math.abs(n.n2(4-.00001,7.2)-n.n2(4+.00001,7.2))<.0001);
        World w=new World(734812);boolean heights=true,valid=true;int snow=0;
        for(int x=-200;x<=200;x+=7)for(int z=-200;z<=200;z+=7){int h=w.height(x,z);heights&=h>=7&&h<=112;if(h>80)snow++;}
        check("Terrainhöhen im Baubereich",heights);check("Alpine Höhen im Startgebiet",snow>0);
        byte[] chunk=w.chunk(0,0);check("Binäres Chunkformat mit Rand",chunk.length==18*130*18);for(byte id:chunk)valid&=Blocks.valid(Byte.toUnsignedInt(id));check("Nur registrierte Materialien",valid);
        check("Chunk reproduzierbar",Arrays.equals(chunk,new World(734812).chunk(0,0)));check("Chunkaufruf verändert Welt nicht",w.editCount()==0);
        check("Grundgestein schützt Weltunterseite",w.get(0,0,0)==Blocks.BEDROCK&&w.get(0,-1,0)==Blocks.BEDROCK);
        check("Über der Welt ist Luft",w.get(0,128,0)==0);check("See am Ursprung",w.get(0,27,0)==Blocks.WATER);check("Seeoberfläche bei 28",w.get(0,28,0)==0);
        int[] spawn=w.spawn();check("Spawn über fester Terrasse",Blocks.solid(w.get(spawn[0],spawn[1]-1,spawn[2])));check("Spawnkörper frei",w.get(spawn[0],spawn[1],spawn[2])==0&&w.get(spawn[0],spawn[1]+1,spawn[2])==0);
        seam(w,0,0,1,0);seam(w,0,0,0,1);seam(w,-1,-1,0,-1);seam(w,2,-4,3,-4);seam(w,1,2,1,3);seam(w,-5,3,-4,3);
        w.set(15,40,0,Blocks.GLASS);w.set(16,40,0,Blocks.LANTERN);w.set(-1,20,-17,Blocks.CRYSTAL);
        check("Blockänderung sichtbar",w.get(15,40,0)==Blocks.GLASS);check("Negative Koordinaten korrekt",w.get(-1,20,-17)==Blocks.CRYSTAL);check("Änderungszähler",w.editCount()==3);
        w.set(15,40,0,Blocks.MARBLE);check("Überschreiben erhöht Zähler nicht",w.editCount()==3);seam(w,0,0,1,0);
        byte[] detached=w.chunk(0,0);detached[World.index(1,30,1)]=99;check("Chunkkopie schützt Cache",w.chunk(0,0)[World.index(1,30,1)]!=99);
        rejects("Grundgestein nicht editierbar",()->w.set(0,0,0,0));rejects("Negative Bauhöhe abgewiesen",()->w.set(0,-1,0,1));rejects("Zu hohe Bauhöhe abgewiesen",()->w.set(0,128,0,1));rejects("Ungültige Material-ID abgewiesen",()->w.set(0,10,0,31));rejects("Entfernte Weltkoordinate abgewiesen",()->w.set(50001,10,0,1));
        check("Luft nicht kollidierend",!Blocks.solid(Blocks.AIR));check("Wasser nicht kollidierend",!Blocks.solid(Blocks.WATER));check("Farn nicht kollidierend",!Blocks.solid(Blocks.FERN));check("Glas kollidierend",Blocks.solid(Blocks.GLASS));
        Map<String,Object> meta=Json.object("{\"pos\":[13.5,35,43.5],\"name\":\"Grün & weiß\",\"flight\":true,\"clock\":0.35,\"empty\":null}");
        check("JSON Rundlauf",Json.write(Json.parse(Json.write(meta))).equals(Json.write(meta)));check("Unicode in JSON",meta.get("name").equals("Grün & weiß"));check("JSON Zahlen",Json.number(meta,"clock",0)==.35);
        rejects("Doppelte JSON-Schlüssel nach null",()->Json.parse("{\"a\":null,\"a\":1}"));
        rejects("Unvollständiges JSON",()->Json.parse("{\"a\":"));rejects("Nicht-endliche JSON-Zahl",()->Json.parse("1e999"));rejects("JSON Zusatzdaten",()->Json.parse("{}x"));rejects("Ungültiges Escape",()->Json.parse("\"\\q\""));rejects("Nicht-endliche Serialisierung",()->Json.write(Double.NaN));rejects("JSON Tiefenlimit",()->Json.parse("[".repeat(25)+"0"+"]".repeat(25)));
        Path dir=Files.createTempDirectory("verdant-selftest-");SaveStore store=new SaveStore(dir);w.metadata=Json.write(meta);store.save(w);World loaded=store.load(w.seed);
        check("Seed gespeichert",loaded.seed==w.seed);check("Spielerdaten gespeichert",loaded.metadata.equals(w.metadata));check("Änderungen gespeichert",loaded.editCount()==3&&loaded.get(15,40,0)==Blocks.MARBLE&&loaded.get(-1,20,-17)==Blocks.CRYSTAL);
        check("Generierte Welt nach Laden identisch",Arrays.equals(w.chunk(-1,1),loaded.chunk(-1,1)));check("Unbekannter Seed erzeugt neue Welt",store.load(4421).editCount()==0);
        w.set(9,50,9,Blocks.BRICKS);store.save(w);check("Sicherungsdatei erstellt",Files.exists(dir.resolve("welt-734812.vdt.bak")));check("Sicherung enthält vorherigen Stand",store.recover(w.seed).editCount()==3);
        Path file=store.path(w.seed);byte[] bytes=Files.readAllBytes(file);Files.write(file,Arrays.copyOf(bytes,bytes.length/2));rejects("Abgeschnittener Spielstand abgewiesen",()->store.load(w.seed));check("Sicherung nach beschädigter Hauptdatei lesbar",store.recover(w.seed).editCount()==3);Files.write(file,bytes);rejects("Falscher Seed in Datei abgewiesen",()->store.read(file,7));
        Files.write(file,Arrays.copyOf(bytes,bytes.length/2));World recovered=store.recoverAndQuarantine(w.seed);
        check("Defekte Hauptdatei nach Wiederherstellung archiviert",!Files.exists(file));store.save(recovered);
        check("Sicherung nach Reparatur bleibt gültig",store.recover(w.seed).editCount()==3);
        check("Reparierter Hauptspielstand lesbar",store.load(w.seed).editCount()==3);
        for(int i=0;i<70;i++){int x=(i*73)%310-155,z=(i*97)%300-150;w.set(x,40+i%30,z,(i%28)+1);}store.save(w);World many=store.load(w.seed);check("Gemischter Speicher-Rundlauf",many.snapshot().size()==w.snapshot().size());
        boolean same=true;for(int[] a:w.snapshot())same&=many.get(a[0],a[1],a[2])==a[3];check("Alle gespeicherten Positionen korrekt",same);
        try(var paths=Files.walk(dir)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(Exception ignored){}});}
        System.out.printf(Locale.ROOT,"\nRESULT: %d/%d bestanden, %.2f s\n",checks-failed,checks,(System.nanoTime()-start)/1e9);if(failed>0)System.exit(1);
    }
}
