"""HTTP-/Integrationsprüfungen gegen einen isolierten echten Java-Prozess.
Benötigt nur Python-Standardbibliothek und eine bereits erstellte VERDANT.jar.
Die Tests verwenden einen temporären Spielstandordner, niemals die echte Welt.
"""
from pathlib import Path
import json,re,subprocess,tempfile,urllib.request,urllib.error,time,struct,concurrent.futures
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def check(name,ok):
    checks.append((name,bool(ok)));print(('PASS ' if ok else 'FAIL ')+name,flush=True)
with tempfile.TemporaryDirectory(prefix='verdant-http-test-') as tmp:
    process=subprocess.Popen(['java','-Dfile.encoding=UTF-8','-Dstdout.encoding=UTF-8','-jar',str(ROOT/'VERDANT.jar'),'--port','0','--no-browser','--save-dir',tmp],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
    try:
        base=None
        for i in range(20):
            line=process.stdout.readline()
            m=re.search(r'http://127\.0\.0\.1:\d+',line)
            if m:base=m.group(0);break
            if process.poll() is not None:raise RuntimeError('Java-Server konnte nicht gestartet werden: '+line)
        if not base:raise RuntimeError('Serveradresse fehlt')
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}));key=None
        def req(path,body=None,headers=None,method=None,auth=True,raw=None):
            h={'X-Verdant-Key':key} if auth and key else {}
            if body is not None:h['Content-Type']='application/json'
            if headers:h.update(headers)
            data=raw if raw is not None else json.dumps(body).encode() if body is not None else None
            request=urllib.request.Request(base+path,data=data,headers=h,method=method)
            try:r=opener.open(request,timeout=30)
            except urllib.error.HTTPError as e:r=e
            with r:return r.status,dict(r.headers),r.read()
        code,headers,data=req('/',auth=False)
        check('Java startet auf zufälligem Loopback-Port',code==200 and base.startswith('http://127.0.0.1:'))
        m=re.search(r"window.__VERDANT_KEY__='([^']+)'",data.decode());key=m.group(1)
        check('Zufälliger Sitzungsschlüssel im lokalen HTML',len(key)==48 and '__SESSION_KEY__' not in data.decode())
        check('Keine externen Skriptabhängigkeiten im HTML',not re.search(r'<script[^>]+src=["\']https?://',data.decode()))
        check('Content-Security-Policy blockiert Einbettung',"frame-ancestors 'none'" in headers.get('Content-security-policy',headers.get('Content-Security-Policy','')))
        check('API lehnt fehlenden Schlüssel ab',req('/api/config',auth=False)[0]==403)
        check('API lehnt falschen Schlüssel ab',req('/api/config',headers={'X-Verdant-Key':'wrong'})[0]==403)
        check('API lehnt fremden Origin ab',req('/api/config',headers={'Origin':'https://example.invalid'})[0]==403)
        check('DNS-Rebinding-Host abgewiesen',req('/api/config',headers={'Host':'attacker.invalid'})[0]==403)
        check('Eigener Origin erlaubt',req('/api/config',headers={'Origin':base})[0]==200)
        check('Pfad-Traversal abgewiesen',req('/%2e%2e/src/verdant/Main.java',auth=False)[0]==400)
        check('Unbekannte Ressource liefert 404',req('/not-found.js',auth=False)[0]==404)
        check('JavaScript wird mit Modul-MIME ausgeliefert','javascript' in req('/app.js',auth=False)[1].get('Content-type',''))
        assets=['style.css','math.js','world.js','worker.js','mesher.js','player.js','audio.js','renderer.js','materials.js','icon.svg']
        check('Alle Spielmodule und UI-Ressourcen aus JAR verfügbar',all(req('/'+p,auth=False)[0]==200 for p in assets))
        shaders=list((ROOT/'resources/web/shaders').glob('*.glsl'))
        check('Alle 13 eigenen Shaderquellen aus JAR verfügbar',len(shaders)==13 and all(req('/shaders/'+p.name,auth=False)[2].startswith(b'#version 300 es') for p in shaders))
        config=json.loads(req('/api/config')[2]);seed=config['seed']
        check('Defaultwelt startet ohne gespeicherte Änderungen',seed==734812 and config['edits']==0 and config['player']=={})
        path=f'/api/chunk?x=0&z=0&seed={seed}'
        chunk=req(path)[2]
        check('Chunk-Payload exakt gepolstertes Format',len(chunk)==18*130*18)
        check('Wiederholte Chunkabfrage deterministisch',chunk==req(path)[2])
        check('Chunk mit falschem Seed verweigert',req(f'/api/chunk?x=0&z=0&seed={seed+1}')[0]==409)
        check('Chunk jenseits Weltgrenze abgewiesen',req(f'/api/chunk?x=9000&z=0&seed={seed}')[0]==400)
        lod=req(f'/api/lod?x=0&z=0&seed={seed}')[2]
        check('Fernsicht hat 65 mal 65 Höhenwerte',len(lod)==65*65*2)
        check('Fernsichthöhen innerhalb Baubereich',all(7<=v<=112 for v in struct.unpack('>'+('H'*65*65),lod)))
        check('Ungültige Bauhöhe abgewiesen',req('/api/edit',{'seed':seed,'x':0,'y':0,'z':0,'id':1})[0]==400)
        check('Ungültiges Material abgewiesen',req('/api/edit',{'seed':seed,'x':0,'y':40,'z':0,'id':99})[0]==400)
        check('Bruchzahl als Blockposition abgewiesen',req('/api/edit',{'seed':seed,'x':.5,'y':40,'z':0,'id':1})[0]==400)
        check('Bruchzahl als Seed nicht gleichgesetzt',req('/api/edit',{'seed':seed+.25,'x':0,'y':40,'z':0,'id':1})[0]==409)
        check('Falscher Methodenaufruf kann nicht editieren',req('/api/edit',method='GET')[0]==400)
        check('Übergroße Anfragen abgewiesen',req('/api/save',raw=b'{'+b' '*33000+b'}',method='POST')[0]==400)
        check('Fehlerhaftes JSON abgewiesen',req('/api/edit',raw=b'{"seed":',method='POST')[0]==400)
        check('Doppelte JSON-Schlüssel abgewiesen',req('/api/edit',raw=b'{"a":null,"a":1}',method='POST')[0]==400)
        edit={'seed':seed,'x':15,'y':40,'z':0,'id':14}
        check('Gültige Blockänderung bestätigt',req('/api/edit',edit)[0]==200)
        chunk=req(path)[2];check('Änderung im Chunk sichtbar',chunk[((40+1)*18+1)*18+16]==14)
        adjacent=req(f'/api/chunk?x=1&z=0&seed={seed}')[2]
        check('Änderung auch im Nachbarrand sichtbar',adjacent[((40+1)*18+1)*18+0]==14)
        edits=[{'seed':seed,'x':i-20,'y':45+i%4,'z':21,'id':(i%28)+1} for i in range(40)]
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:codes=list(pool.map(lambda e:req('/api/edit',e)[0],edits))
        check('Parallele Blockänderungen ohne verlorene Einträge',all(c==200 for c in codes) and json.loads(req('/api/status')[2])['edits']==41)
        player={'pos':[13.5,35.02,43.5],'inventory':[0]*30,'toolLevel':3,'clock':.72,'found':['first-mine']}
        check('Spielzustand wird gespeichert',req('/api/save',{'seed':seed,'player':player})[0]==200)
        check('Binärer Spielstand auf Datenträger vorhanden',(Path(tmp)/f'welt-{seed}.vdt').is_file())
        check('Gespeicherter Zustand über Konfiguration lesbar',json.loads(req('/api/config')[2])['player']==player)
        req('/api/save',{'seed':seed,'player':player})
        check('Vorheriger Speicherstand als Sicherung vorhanden',(Path(tmp)/f'welt-{seed}.vdt.bak').is_file())
        check('Weltwechsel speichert alte Welt und öffnet neuen Seed',json.loads(req('/api/world',{'seed':21345})[2])['edits']==0)
        restored=json.loads(req('/api/world',{'seed':seed})[2]);check('Rückkehr lädt Änderungen und Spielerfortschritt',restored['edits']==41 and restored['player']==player)
        check('Ungültiger neuer Seed abgewiesen',req('/api/world',{'seed':1.7})[0]==400)
        check('Kontrolliertes Speichern und Beenden bestätigt',req('/api/quit',{})[0]==200)
        process.wait(timeout=10);check('Java-Prozess nach Beenden sauber geschlossen',process.returncode==0)
    finally:
        if process.poll() is None:process.terminate();process.wait(timeout=10)
print(f'\nRESULT: {sum(ok for _,ok in checks)}/{len(checks)} bestanden')
if not all(ok for _,ok in checks):raise SystemExit(1)
