/** Ausführbare Client-Kerntests. Node.js wird nur für diese Tests benötigt. */
import {clamp,lerp,norm,cross,dot,identity,multiply,perspective,lookAt,invert,transform,frustum,visible} from '../resources/web/math.js';
import {meshChunk,blockIndex,H,P} from '../resources/web/mesher.js';
import {Player} from '../resources/web/player.js';
import {VoxelWorld} from '../resources/web/world.js';
import {BLOCKS,PALETTE,solid,opaque} from '../resources/web/materials.js';
let passed=0,failed=0;
function test(name,condition){if(condition){passed++;console.log('PASS '+name);}else{failed++;console.log('FAIL '+name);}}
function near(a,b,eps=1e-5){return Math.abs(a-b)<eps;}
function buffer(){return new Uint8Array(P*(H+2)*P);}
function block(a,x,y,z,id){a[blockIndex(x,y,z)]=id;return a;}
function winding(mesh){let ok=true;for(let i=0;i<mesh.length;i+=33){const a=Array.from(mesh.slice(i,i+3)),b=Array.from(mesh.slice(i+11,i+14)),c=Array.from(mesh.slice(i+22,i+25)),n=Array.from(mesh.slice(i+3,i+6));const cr=cross(b.map((v,j)=>v-a[j]),c.map((v,j)=>v-a[j]));ok&&=dot(cr,n)>0;}return ok;}
test('Clamping',clamp(-3,0,1)===0&&clamp(3,0,1)===1);
test('Interpolation',lerp(10,20,.25)===12.5);
test('Vektornorm',near(Math.hypot(...norm([3,4,5])),1));
test('Nullvektor ohne NaN',norm([0,0,0]).every(v=>v===0));
test('Kreuzprodukt rechtsgängig',cross([1,0,0],[0,1,0]).join() === '0,0,1');
let view=lookAt([2,4,8],[0,1,0]);test('Kamera wird zum Ursprung transformiert',transform(view,[2,4,8]).slice(0,3).every(v=>Math.abs(v)<1e-5));
let projection=perspective(1.1,1.6,.12,420),vp=multiply(projection,view),prod=multiply(vp,invert(vp));test('Projektionsmatrix invertierbar',Array.from(prod).every((v,i)=>near(v,identity()[i],.0001)));
let planes=frustum(multiply(projection,lookAt([0,0,0],[0,0,-1])));test('Frustum erkennt sichtbare Geometrie',visible([-1,-1,-6,1,1,-3],planes));test('Frustum verwirft Geometrie hinter Kamera',!visible([-1,-1,3,1,1,6],planes));
test('27 auswählbare Materialien',PALETTE.length===27);test('Material-IDs eindeutig',new Set(BLOCKS.map(b=>b.id)).size===BLOCKS.length);test('Glas kollidiert, Farn und Wasser nicht',solid(14)&&!solid(25)&&!solid(5));
let mesh=meshChunk(buffer(),0,0);test('Leerer Chunk hat keine Geometrie',mesh.solid.length===0&&mesh.water.length===0&&mesh.glass.length===0);
mesh=meshChunk(block(buffer(),3,40,4,3),0,0);test('Ein Würfel hat sechs Flächen',mesh.quads===6&&mesh.solid.length===36*11);test('Dreieckorientierung passt zu Normalen',winding(mesh.solid));test('Nur endliche Vertexattribute',mesh.solid.every(Number.isFinite));test('Ambient Occlusion begrenzt',mesh.solid.filter((_,i)=>i%11===9).every(v=>v>=.42&&v<=1));
let b=block(block(buffer(),3,40,4,3),4,40,4,3);mesh=meshChunk(b,0,0);test('Benachbarte Vollblöcke werden greedy zusammengefasst',mesh.quads===6&&mesh.solid.length===36*11);
b=block(block(buffer(),15,40,4,3),16,40,4,3);mesh=meshChunk(b,0,0);test('Verdeckte Fläche am gepolsterten Chunkrand entfernt',mesh.quads===5);
mesh=meshChunk(block(buffer(),3,40,4,14),0,0);test('Glas getrennt von opaker Geometrie',mesh.glass.length===36*11&&mesh.solid.length===0);
mesh=meshChunk(block(block(buffer(),3,26,4,5),3,27,4,5),0,0);test('Wassersäule erzeugt nur obere Oberfläche',mesh.water.length===6*11&&mesh.solid.length===0);test('Wasser auf definierter Höhe',near(mesh.water[1],27.9));
mesh=meshChunk(block(buffer(),3,40,4,25),0,0);test('Farn besteht aus zwei gekreuzten Quads',mesh.solid.length===12*11);
mesh=meshChunk(block(buffer(),3,40,4,1),-2,-3);test('Negative Chunkkoordinaten korrekt verschoben',Math.min(...mesh.solid.filter((_,i)=>i%11===0))===-29);test('Grasoberseite hat eigene Texturlage',mesh.solid.some((v,i)=>i%11===8&&v===31));
let fake={get:(x,y,z)=>x===3&&y===2&&z===0?3:0};let hit=VoxelWorld.prototype.raycast.call(fake,[.5,2.5,.5],[1,0,0],7);test('DDA trifft ersten Block',hit?.x===3&&near(hit.distance,2.5));test('DDA liefert korrekte Platziernormale',hit?.normal.join()==='-1,0,0');test('DDA respektiert maximale Reichweite',VoxelWorld.prototype.raycast.call(fake,[.5,2.5,.5],[1,0,0],2)===null);
fake={get:(x,y,z)=>x===-3&&y===2&&z===0?3:0};hit=VoxelWorld.prototype.raycast.call(fake,[.5,2.5,.5],[-1,0,0],7);test('DDA mit negativer Richtung',hit?.x===-3&&hit.normal[0]===1);
fake={get:(x,y,z)=>x===1?5:x===3?3:0};hit=VoxelWorld.prototype.raycast.call(fake,[.5,2.5,.5],[1,0,0],7);test('DDA überspringt Wasser',hit?.x===3);
let flat={get:(x,y,z)=>y<0?3:0};flat.collides=VoxelWorld.prototype.collides.bind(flat);
test('Spieler-AABB auf Boden kollisionsfrei',!flat.collides([.5,0,.5]));test('Spieler-AABB unter Boden kollidiert',flat.collides([.5,-.1,.5]));test('Ungeladene Chunks nicht begehbar',VoxelWorld.prototype.collides.call({get:()=>null},[0,20,0]));
let player=new Player([.5,4,.5]),keys=new Set();for(let i=0;i<360;i++)player.update(1/120,keys,flat);test('Schwerkraft landet auf Boden',near(player.pos[1],0,.006)&&player.grounded);test('Kamera besitzt korrekte Augenhöhe',near(player.eye(false)[1]-player.pos[1],1.62));
keys.add('Space');for(let i=0;i<30;i++)player.update(1/120,keys,flat);test('Sprung hebt vom Boden ab',player.pos[1]>1);keys.clear();for(let i=0;i<400;i++)player.update(1/120,keys,flat);test('Landung nach Sprung stabil',Math.abs(player.pos[1])<.006&&player.health===100);
player=new Player([.5,0,.5]);player.yaw=0;keys=new Set(['KeyW']);for(let i=0;i<120;i++)player.update(1/120,keys,flat);test('W bewegt bei Yaw null nach Norden',player.pos[2]<-3&&near(player.pos[0],.5));test('Gehdistanz wird erfasst',player.distance>3);
player=new Player([.5,0,.5]);player.flying=true;keys=new Set(['Space']);for(let i=0;i<120;i++)player.update(1/120,keys,flat);test('Kreativflug steigt auf',player.pos[1]>8);
player=new Player([.5,0,.5]);player.flying=true;const photoDistance=player.distance;for(let i=0;i<120;i++)player.update(1/120,keys,{get:()=>3,collides:()=>true},{creative:true,photo:true});test('Fotokamera kann Geometrie passieren',player.pos[1]>8);test('Fotoflug zählt nicht als Laufdistanz',player.distance===photoDistance);
player=new Player([.5,1,.5]);player.load({pos:[Infinity,5,0],yaw:Infinity,pitch:8,health:-9,distance:-4});test('Ungültige Spielposition nicht übernommen',player.pos[0]===.5);test('Geladene Blick- und Lebenswerte begrenzt',player.pitch===1.54&&player.health===1&&player.distance===0);
player=new Player([.5,4,.5]);test('Platzieren im Spieler erkannt',player.intersects(0,4,0));test('Entferntes Platzieren zulässig',!player.intersects(3,4,0));
let submerged={get:()=>5,collides:()=>false};player=new Player([.5,25,.5]);player.flying=true;for(let i=0;i<2400;i++)player.update(1/120,new Set(),submerged,{creative:false});test('Sauerstoff unter Wasser verbraucht',player.oxygen<.01);for(let i=0;i<120;i++)player.update(1/120,new Set(),submerged,{creative:false});test('Sauerstoffmangel schadet in Expedition',player.health<100);
player=new Player([.5,25,.5]);player.flying=true;for(let i=0;i<3000;i++)player.update(1/120,new Set(),submerged,{creative:true});test('Kreativmodus schützt beim Tauchen',player.health===100&&player.oxygen===100);
player=new Player([.5,0,.5]);player.health=0;player.update(1/120,new Set(),flat,{creative:false});test('Tod setzt zum Spawn zurück',player.health===100&&player.pos[0]===.5);
console.log(`\nRESULT: ${passed}/${passed+failed} bestanden`);if(failed)process.exit(1);
