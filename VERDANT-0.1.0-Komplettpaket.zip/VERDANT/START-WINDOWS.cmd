@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
    echo Java wurde nicht gefunden. Bitte Java 17 oder neuer installieren.
    echo Danach dieses Fenster neu oeffnen und erneut starten.
    pause
    exit /b 1
)
if not exist "VERDANT.jar" (
    echo VERDANT.jar fehlt. Zuerst das gesamte ZIP entpacken.
    pause
    exit /b 1
)
echo VERDANT wird gestartet. Dieses Fenster waehrend des Spielens offen lassen.
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -jar "VERDANT.jar" %*
if errorlevel 1 (
    echo.
    echo Start fehlgeschlagen. Fehlermeldung oben und README-DE.md pruefen.
    echo Eine Java-Version ab 17 und ein WebGL-2-faehiger Desktop-Browser werden benoetigt.
    pause
)
endlocal
