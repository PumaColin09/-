# Aufnahmen aus dem gestarteten Renderer

Diese PNGs stammen aus VERDANT selbst. Kein Bildgenerator, kein nachträglich
hinzugefügtes Gebäude, keine externen Textur- oder Shaderpacks.

- `01-menu.png`: vollständig geladene Startansicht am Alpensee.
- `02-gameplay.png`: Ansicht mit tatsächlich aktiviertem Spiel-HUD.
- `03-inventory.png`: Materialauswahl und Hotbar-Zuweisung.
- `04-settings.png`: Einstellungsoberfläche während des Tests.
- `05-evening.png`: veränderte Sonnenposition am Nachmittag/Abend.
- `06-night.png`: Nacht und lokale Beleuchtung durch Laternen.
- `07-rain.png`: Regen, atmosphärische Dämpfung und nasse Oberflächen.
- `08-photo-export.png`: über den tatsächlichen F2-PNG-Export erzeugte Datei.

Die Tageszeiten und Wetterzustände wurden für die Aufnahmen über die auch im
Spiel vorhandenen Zustände gesetzt. Detaillierte Testbedingungen stehen in
`../TEST-RESULTS.md`. Aufnahmen sind keine Bildraten-Benchmarks.
