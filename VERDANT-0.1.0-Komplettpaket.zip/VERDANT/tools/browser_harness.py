"""Runs our own resources in an offline blank page without browser navigation.
The container's managed browser does not permit URL navigation. Its policy is
left untouched. Local Java API calls are made by the test bridge, not the page.
"""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json,re,requests,base64,time,os
ROOT=Path(__file__).resolve().parents[1]; WEB=ROOT/'resources/web'; BASE=os.environ.get('VERDANT_TEST_URL','http://127.0.0.1:8765')
session=requests.Session(); html=session.get(BASE).text
key=re.search(r"window.__VERDANT_KEY__='([^']+)'",html).group(1)
def code(name):
    s=(WEB/name).read_text();s=re.sub(r'^import .*?;\s*$', '', s, flags=re.M);s=re.sub(r'^export \{[^}]+\};?\s*$', '', s, flags=re.M);s=re.sub(r'\bexport (?=(?:const|function|class))','',s);return s
bundle='\n'.join(code(n) for n in ['math.js','materials.js','mesher.js','world.js','player.js','audio.js','renderer.js','app.js'])
worker='\n'.join(code(n) for n in ['materials.js','mesher.js','worker.js'])
shaders={f'/shaders/{p.name}':p.read_text() for p in (WEB/'shaders').glob('*.glsl')}
html=re.sub(r'<link[^>]+>', '', html)
html=re.sub(r'<script.*?</script>','',html,flags=re.S)
html=html.replace('</head>','<style>'+(WEB/'style.css').read_text()+'</style></head>')
def bridge(path,options):
    r=session.request(options.get('method','GET'),BASE+path,headers=options.get('headers',{}),data=options.get('body'),timeout=60)
    return {'status':r.status_code,'type':r.headers.get('content-type','application/octet-stream'),'data':base64.b64encode(r.content).decode()}
def setup(page):
    page.expose_function('__localJava',bridge)
    page.set_content(html,wait_until='domcontentloaded')
    page.evaluate('''({key,shaders,worker})=>{
      window.__VERDANT_KEY__=key;
      const NativeWorker=window.Worker;
      window.Worker=function(){return new NativeWorker(URL.createObjectURL(new Blob([worker],{type:'text/javascript'})))};
      window.fetch=async (path,options={})=>{
        if(shaders[path]!==undefined)return new Response(shaders[path],{status:200});
        const r=await window.__localJava(path,options);
        return new Response(Uint8Array.from(atob(r.data),c=>c.charCodeAt(0)),{status:r.status,headers:{'Content-Type':r.type}});
      };
    }''',{'key':key,'shaders':shaders,'worker':worker})
    page.add_script_tag(content=bundle)
if __name__=='__main__':
  with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    page=browser.new_page(viewport={'width':1280,'height':800},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e: (errors.append(str(e)),print('PAGE ERROR',e,flush=True)))
    page.on('console',lambda e: print('CONSOLE',e.type,e.text[:600],flush=True) if e.type in ['error','warning'] else None)
    setup(page)
    try: page.wait_for_function('window.verdant && window.verdant.ready',timeout=90000)
    except Exception as e: print('WAIT',str(e)[:300],flush=True)
    page.wait_for_timeout(15000)
    print('STATS',page.evaluate('window.verdant ? ({...verdant.renderer.stats(),fps:verdant.fps,ready:verdant.ready,loading:verdant.world.loading,queue:verdant.world.queue.length,jobs:verdant.world.jobs.size,error:document.getElementById("fatal-message").textContent}) : document.body.innerText'),flush=True)
    page.screenshot(path=str(ROOT/'screenshots'/'01-first-render.png'),timeout=60000)
    (ROOT/'build'/'browser-errors.json').write_text(json.dumps(errors))
    browser.close()
