"""Reale UI-/Render-Integration mit dem lokalen Java-Kern, in Offline-Testseite.
Normale Browsernavigation ist in dieser Testumgebung per Richtlinie gesperrt.
Die Richtlinie bleibt unverändert; Ressourcen werden ausschließlich aus dem
Projekt geladen. Simulations-/Grafikquellcode wird dabei nicht verändert.
"""
from browser_harness import *
checks=[]
def check(name,condition):
    checks.append((name,bool(condition)));print(('PASS ' if condition else 'FAIL ')+name,flush=True)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1,accept_downloads=True)
    errors=[]
    page.on('pageerror',lambda e:(errors.append(str(e)),print('JS ERROR',e,flush=True)))
    page.on('console',lambda e:print('CONSOLE',e.type,e.text[:400],flush=True) if e.type in ['warning','error'] else None)
    setup(page)
    page.wait_for_function('window.verdant && verdant.ready',timeout=120000)
    # Keine unnötigen Software-GPU-Frames während reiner Hintergrund-Geometriearbeit.
    page.evaluate('window.__draw=verdant.renderer.render.bind(verdant.renderer);verdant.renderer.render=()=>{}')
    page.wait_for_function('verdant.world.loading===0&&verdant.world.queue.length===0&&verdant.world.jobs.size===0&&verdant.world.lod',timeout=120000)
    # Kontrolliert einzelne echte Frames rendern; kein anderer Shader-/Geometriepfad.
    page.evaluate('window.requestAnimationFrame=()=>0;verdant.renderer.render=window.__draw;window.__frame=()=>{verdant.renderer.render(verdant.world,verdant.camera(),verdant.renderState(0));verdant.updateHUD()}')
    page.wait_for_timeout(1000)
    page.evaluate('__frame()')
    check('Java-Welt liefert 293 Start-Chunks',page.evaluate('verdant.world.chunks.size>=293'))
    check('Fernsicht-LOD vorhanden',page.evaluate('!!verdant.world.lod?.gpu?.solid'))
    check('Acht Shaderprogramme erfolgreich gelinkt',page.evaluate('verdant.renderer.stats().shaders===8'))
    check('Kein WebGL-Fehler nach voller Startansicht',page.evaluate('verdant.renderer.gl.getError()===0'))
    check('Startknopf nach Weltaufbau bedienbar',page.locator('#enter').is_enabled())
    page.screenshot(path=str(ROOT/'screenshots/01-menu.png'))
    page.click('#enter')
    page.wait_for_timeout(400)
    check('Startknopf aktiviert echte Pointer-Lock-Maussteuerung',page.evaluate('verdant.playing&&document.pointerLockElement===verdant.canvas'))
    page.evaluate('__frame()')
    check('HUD statt Startmenü sichtbar',page.locator('#hud').is_visible() and not page.locator('#menu').is_visible())
    check('Neun echte Hotbar-Slots vorhanden',page.locator('#hotbar .slot').count()==9)
    page.screenshot(path=str(ROOT/'screenshots/02-gameplay.png'))
    page.keyboard.press('3')
    check('Zifferntaste wechselt Hotbar-Slot',page.evaluate('verdant.selected===2'))
    page.keyboard.press('f')
    check('F schaltet Kreativflug ein',page.evaluate('verdant.player.flying'))
    page.keyboard.press('e')
    check('E öffnet Inventar',page.evaluate('verdant.panel==="inventory"') and page.locator('#panel-backdrop').is_visible())
    check('Inventar zeigt 27 Baumaterialien',page.locator('#blocks-grid .block-card').count()==27)
    page.screenshot(path=str(ROOT/'screenshots/03-inventory.png'))
    page.locator('[data-category="Licht"]').click()
    check('Materialfilter Licht arbeitet',page.locator('#blocks-grid .block-card').count()==2)
    page.locator('.block-card',has_text='Laterne').click()
    check('Materialklick weist Laterne dem aktiven Slot zu',page.evaluate('verdant.bar[2]===27'))
    page.locator('[data-tab="craft"]').click()
    check('Werkbank zeigt zehn Rezepte',page.locator('#recipes .recipe').count()==10)
    page.evaluate('verdant.settings.mode="expedition";verdant.inventory.fill(0);verdant.inventory[6]=4;verdant.drawInventory()')
    page.locator('.recipe',has=page.locator('h3',has_text='Eichenbretter')).locator('button').click(modifiers=['Shift'])
    check('Mehrfach-Crafting verbraucht verfügbare Zutaten exakt',page.evaluate('verdant.inventory[6]===0&&verdant.inventory[12]===16&&verdant.stats.crafted>=2'))
    check('Rezept ohne Zutaten deaktiviert',not page.locator('.recipe',has=page.locator('h3',has_text='Eichenbretter')).locator('button').is_enabled())
    page.evaluate('verdant.inventory[16]=40;verdant.inventory[12]=40;verdant.inventory[17]=10;verdant.toolLevel=1;verdant.drawInventory()')
    page.locator('.recipe',has=page.locator('h3',has_text='Werkzeug verbessern')).locator('button').click(modifiers=['Shift'])
    check('Werkzeug-Upgrades stoppen bei Stufe vier',page.evaluate('verdant.toolLevel===4&&verdant.inventory[16]===22&&verdant.inventory[17]===7'))
    page.evaluate('verdant.openPanel("settings")')
    page.locator('#mode-select').select_option('creative')
    check('Moduswechsel über echte Einstellungs-UI',page.evaluate('verdant.settings.mode==="creative"'))
    page.screenshot(path=str(ROOT/'screenshots/04-settings.png'))
    # Grafikpresets rendern jeweils einen vollständigen Frame.
    for quality in [0,2,1]:
        page.locator(f'[data-quality="{quality}"]').click()
        page.evaluate('__frame()')
        check('Grafikprofil '+str(quality)+' rendert fehlerfrei',page.evaluate(f'verdant.renderer.quality==={quality}&&verdant.renderer.gl.getError()===0'))
    # Blockoperationen rufen dieselben Spielmethoden und Java-Endpunkte wie die Maus auf.
    outcome=page.evaluate('''async()=>{
      const g=verdant;g.closePanel();g.playing=true;g.time=100;g.settings.mode='expedition';g.bar[0]=14;g.selected=0;g.inventory[14]=3;
      const x=12,y=35,z=39;g.target={x,y:34,z,id:g.world.get(x,34,z),normal:[0,1,0],distance:4};
      window.__before=g.world.get(x,y,z);await g.place();
      return {id:g.world.get(x,y,z),count:g.inventory[14],busy:g.busy};
    }''')
    check('Platzieren schreibt Glas durch Java-API in die Welt',outcome['id']==14 and not outcome['busy'])
    check('Expeditionsbau verbraucht genau ein Material',outcome['count']==2)
    check('Java-Chunk enthält platzierte Änderung',page.evaluate('''async()=>{const a=new Uint8Array(await verdant.world.api('/api/chunk?x=0&z=2&seed='+verdant.seed,null,true));return a[((35+1)*18+(7+1))*18+12+1]===14}'''))
    outcome=page.evaluate('''async()=>{const g=verdant;await g.mine({x:12,y:35,z:39,id:14});return {id:g.world.get(12,35,39),count:g.inventory[14]};}''')
    check('Abbauen entfernt Block und gibt Ressource zurück',outcome['id']==0 and outcome['count']==3)
    outcome=page.evaluate('''async()=>{verdant.settings.mode='creative';await verdant.undoEdit();return verdant.world.get(12,35,39);}''')
    check('Kreativ-Rückgängig stellt letzten Block wieder her',outcome==14)
    before=page.evaluate('verdant.stats.placed')
    page.evaluate('''async()=>{verdant.time+=1;verdant.target={x:13,y:34,z:43,id:12,normal:[0,1,0],distance:2};await verdant.place()}''')
    check('Bauen innerhalb des eigenen Körpers wird verhindert',page.evaluate(f'verdant.stats.placed==={before}'))
    result=page.evaluate('''async()=>{const g=verdant;g.clock=.48;await g.save(true);const c=await g.world.api('/api/config');return {clock:c.player.clock,bar:c.player.bar,tool:c.player.toolLevel,inv:c.player.inventory,pos:c.player.pos};}''')
    check('Speichern überträgt Inventar, Werkzeug und Zeit',result['clock']==.48 and result['tool']==4 and result['inv'][14]==3)
    page.evaluate('window.__pose=verdant.player.snapshot();verdant.togglePhoto();verdant.player.pos=[-12,60,-20]')
    check('Speichern im Fotomodus bewahrt ursprünglichen Standort',page.evaluate('JSON.stringify(verdant.snapshot().pos)===JSON.stringify(window.__pose.pos)'))
    page.evaluate('verdant.togglePhoto()')
    check('Fotomodus kehrt zum Spieler zurück',page.evaluate('JSON.stringify(verdant.player.pos)===JSON.stringify(window.__pose.pos)'))
    page.evaluate('async()=>{await verdant.world.edit(12,35,39,window.__before);verdant.renderer.particles=[]}')
    page.wait_for_function('verdant.world.jobs.size===0',timeout=30000)
    page.evaluate('verdant.pause();verdant.closePanel();verdant.started=true;verdant.playing=true;verdant.hideUI=true;verdant.syncUI();verdant.clock=.72;verdant.rain=0;__frame()')
    check('Abendlicht rendert ohne GL-Fehler',page.evaluate('verdant.renderer.gl.getError()===0'))
    page.screenshot(path=str(ROOT/'screenshots/05-evening.png'))
    page.evaluate('verdant.clock=.89;verdant.rain=0;__frame()')
    check('Nacht mit Punktlichtern rendert ohne GL-Fehler',page.evaluate('verdant.renderer.gl.getError()===0'))
    page.screenshot(path=str(ROOT/'screenshots/06-night.png'))
    page.evaluate('verdant.clock=.45;verdant.rain=1;__frame()')
    check('Regen mit Partikeln rendert ohne GL-Fehler',page.evaluate('verdant.renderer.gl.getError()===0'))
    page.screenshot(path=str(ROOT/'screenshots/07-rain.png'))
    # Tatsächlichen PNG-Download prüfen, nicht bloß einen UI-Toast.
    page.evaluate('verdant.rain=0;verdant.clock=.35;verdant.hideUI=false;verdant.syncUI()')
    with page.expect_download(timeout=30000) as dl:
        page.keyboard.press('F2')
    download=dl.value;download.save_as(str(ROOT/'screenshots/08-photo-export.png'))
    check('F2 erzeugt eine echte PNG-Datei', (ROOT/'screenshots/08-photo-export.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n'))
    page.evaluate('verdant.openPanel("journal")')
    check('Reisebuch hat zwölf Erfolge',page.locator('.journey-row').count()==12)
    check('Erste Bau- und Crafting-Erfolge freigeschaltet',page.evaluate('verdant.found.has("first-build")&&verdant.found.has("craft")&&verdant.found.has("photo")'))
    # Tatsächlicher Weltwechsel und Rückwechsel via Java, isolierte Test-Spielstände.
    result=page.evaluate('''async()=>{const g=verdant;await g.save(true);const seed=g.seed;const n=await g.world.api('/api/world',{seed:881919});g.loadConfig(n);const fresh=g.seed===881919;const old=await g.world.api('/api/world',{seed});g.loadConfig(old);return {fresh,seed:g.seed,tool:g.toolLevel,inv:g.inventory[14],saved:old.edits};}''')
    check('Weltwechsel und Rückkehr funktionieren',result['fresh'] and result['seed']==734812)
    check('Weltwechsel bewahrt alten Fortschritt',result['tool']==4 and result['inv']==3 and result['saved']>0)
    check('Grafik-/Modusoptionen im Java-Spielstand hinterlegt',page.evaluate('async()=>{const c=await verdant.world.api("/api/config");return c.player.preferences.mode==="creative"&&c.player.preferences.quality===1;}'))
    check('Keine ungefangenen JavaScript-Fehler',len(errors)==0)
    result={'checks':checks,'passed':sum(v for _,v in checks),'total':len(checks),'errors':errors,'renderer':page.evaluate('verdant.renderer.stats()'),'environment':'Chromium WebGL 2 über ANGLE SwiftShader in Xvfb; Offline-Seitenharness mit unveränderter URL-Sperrrichtlinie; Java-API über lokale Testbrücke.'}
    (ROOT/'build/integration-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('RESULT',result['passed'],'/',result['total'],flush=True)
    browser.close()
    if result['passed']!=result['total']:raise SystemExit(1)
