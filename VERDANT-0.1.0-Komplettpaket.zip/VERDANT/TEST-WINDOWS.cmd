@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not exist "build\test-classes" mkdir "build\test-classes"
javac --release 17 -encoding UTF-8 -d "build\test-classes" src\verdant\*.java tests\VerdantTest.java
if errorlevel 1 goto failed
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp "build\test-classes" verdant.VerdantTest
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Tests fehlgeschlagen oder JDK fehlt.
pause
exit /b 1
