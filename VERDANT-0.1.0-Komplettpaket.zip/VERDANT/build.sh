#!/usr/bin/env sh
# Erstellt das Spiel ausschließlich mit den Werkzeugen eines Java-JDK.
set -eu
cd "$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)"
command -v javac >/dev/null 2>&1 || { printf '%s\n' 'JDK 17 oder neuer erforderlich: javac wurde nicht gefunden.' >&2; exit 1; }
command -v jar >/dev/null 2>&1 || { printf '%s\n' 'Das Werkzeug jar wurde nicht gefunden.' >&2; exit 1; }
mkdir -p build/classes
javac --release 17 -encoding UTF-8 -d build/classes src/verdant/*.java
jar --create --file VERDANT.jar --main-class verdant.Main -C build/classes verdant -C resources web
printf '%s\n' 'VERDANT.jar wurde erstellt. Start: java -jar VERDANT.jar'
