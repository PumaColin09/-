import {clamp,lerp,norm} from './math.js';
export class Player {
    constructor(spawn){this.pos=spawn.slice();this.spawn=spawn.slice();this.vel=[0,0,0];this.yaw=-.20;this.pitch=-.08;this.flying=false;this.grounded=false;this.health=100;this.oxygen=100;this.distance=0;this.bob=0;this.stepTime=0;this.jumpHeld=false;}
    direction(){const c=Math.cos(this.pitch);return [Math.sin(this.yaw)*c,Math.sin(this.pitch),-Math.cos(this.yaw)*c]}
    eye(bobbing=true){const bob=bobbing&&this.grounded&&!this.flying?Math.sin(this.bob*1.8)*Math.min(.035,Math.hypot(this.vel[0],this.vel[2])*.006):0;return [this.pos[0],this.pos[1]+1.62+bob,this.pos[2]]}
    load(meta){
        if(Array.isArray(meta.pos)&&meta.pos.length===3&&meta.pos.every(Number.isFinite)&&Math.abs(meta.pos[0])<49980&&Math.abs(meta.pos[2])<49980&&meta.pos[1]>0&&meta.pos[1]<150)this.pos=meta.pos.slice();
        if(Number.isFinite(meta.yaw))this.yaw=meta.yaw%(Math.PI*2);if(Number.isFinite(meta.pitch))this.pitch=clamp(meta.pitch,-1.54,1.54);this.flying=!!meta.flying;this.health=clamp(Number(meta.health)||100,1,100);this.oxygen=clamp(Number(meta.oxygen)||100,1,100);this.distance=Math.max(0,Number(meta.distance)||0);
    }
    snapshot(){return {pos:this.pos.slice(),yaw:this.yaw,pitch:this.pitch,flying:this.flying,health:this.health,oxygen:this.oxygen,distance:this.distance}}
    intersects(x,y,z){return this.pos[0]+.29>x&&this.pos[0]-.29<x+1&&this.pos[1]+1.77>y&&this.pos[1]<y+1&&this.pos[2]+.29>z&&this.pos[2]-.29<z+1}
    update(dt,keys,world,{creative=true,photo=false}={}){
        const old=this.pos.slice(),inWater=world.get(Math.floor(this.pos[0]),Math.floor(this.pos[1]+.6),Math.floor(this.pos[2]))===5,eye=this.eye(false);
        this.underwater=world.get(...eye.map(Math.floor))===5;
        if(!creative&&!photo){this.oxygen=clamp(this.oxygen+(this.underwater?-5:23)*dt,0,100);if(this.oxygen===0)this.health-=7*dt;else if(this.oxygen>98&&this.health>0)this.health=Math.min(100,this.health+.35*dt);}
        let f=+keys.has('KeyW')-+keys.has('KeyS'),s=+keys.has('KeyD')-+keys.has('KeyA'),speed=this.flying?(keys.has('ControlLeft')?24:10):(keys.has('ShiftLeft')?7.5:4.6);
        if(photo)speed=keys.has('ControlLeft')?32:11;if(inWater&&!this.flying)speed=3.3;
        if(f||s){const l=Math.hypot(f,s);f/=l;s/=l;}const want=[(Math.sin(this.yaw)*f+Math.cos(this.yaw)*s)*speed,0,(-Math.cos(this.yaw)*f+Math.sin(this.yaw)*s)*speed];
        const blend=1-Math.exp(-dt*(this.grounded||this.flying?13:5));this.vel[0]=lerp(this.vel[0],want[0],blend);this.vel[2]=lerp(this.vel[2],want[2],blend);
        if(this.flying||photo){const vertical=(+keys.has('Space')-+keys.has('ShiftLeft'))*speed;this.vel[1]=lerp(this.vel[1],vertical,1-Math.exp(-dt*12));}
        else if(inWater){this.vel[1]=lerp(this.vel[1],keys.has('Space')?4:keys.has('ControlLeft')?-4:-1.3,dt*5);}
        else{this.vel[1]=Math.max(-40,this.vel[1]-24*dt);if(keys.has('Space')&&!this.jumpHeld&&this.grounded){this.vel[1]=8.2;this.grounded=false;}}
        this.jumpHeld=keys.has('Space');this.grounded=false;
        for(const axis of [0,2,1]){
            const amount=this.vel[axis]*dt;if(amount===0)continue;const p=this.pos.slice();p[axis]+=amount;
            if(photo||!world.collides(p)){this.pos=p;continue;}
            if(axis!==1&&!this.flying){
                // Kleine Unebenheiten bis 0,55 Block, keine magischen Ein-Block-Sprünge.
                const step=p.slice();step[1]+=.55;if(!world.collides(step)&&world.collides([step[0],step[1]-.58,step[2]])){this.pos=step;continue;}
            }
            let lo=0,hi=1;for(let i=0;i<9;i++){const m=(lo+hi)/2,q=this.pos.slice();q[axis]+=amount*m;if(world.collides(q))hi=m;else lo=m;}this.pos[axis]+=amount*lo;
            if(axis===1&&amount<0){this.grounded=true;if(!creative&&!photo&&this.vel[1]<-12)this.health-=Math.min(55,(-this.vel[1]-12)*3);}
            this.vel[axis]=0;
        }
        this.pos[0]=clamp(this.pos[0],-49980,49980);this.pos[2]=clamp(this.pos[2],-49980,49980);this.pos[1]=Math.min(145,this.pos[1]);
        const traveled=Math.hypot(this.pos[0]-old[0],this.pos[2]-old[2]);if(!photo)this.distance+=traveled;this.bob+=traveled*2.6;
        let stepSound=false;if(this.grounded&&traveled>.001){this.stepTime+=traveled;if(this.stepTime>.95){this.stepTime=0;stepSound=true;}}
        if(this.pos[1]< -3||this.health<=0){this.pos=this.spawn.slice();this.vel=[0,0,0];this.health=100;this.oxygen=100;this.onRespawn?.();}
        return {step:stepSound,water:inWater};
    }
}
