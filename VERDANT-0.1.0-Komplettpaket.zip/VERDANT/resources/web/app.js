import {Renderer,PRESETS} from './renderer.js';
import {VoxelWorld} from './world.js';
import {Player} from './player.js';
import {Soundscape} from './audio.js';
import {BLOCKS,PALETTE,solid} from './materials.js';
import {clamp,lerp,norm} from './math.js';

const $=id=>document.getElementById(id);
const DEFAULTS={quality:1,fov:73,sensitivity:1,exposure:1,volume:.42,bob:true,mode:'creative',weather:'auto',daySpeed:1};
const DEFAULT_BAR=[12,3,14,27,6,7,19,22,1];
const JOURNEY=[
 ['first-mine','Der erste Fund','Baue deinen ersten Block ab.'],['first-build','Eine Spur im Tal','Setze deinen ersten eigenen Block.'],
 ['craft','Aus wenig wird mehr','Stelle etwas an der Werkbank her.'],['copper','Unter der Oberfläche','Finde und baue Kupfererz ab.'],
 ['crystal','Ein Licht im Stein','Baue einen Bergkristall ab.'],['dive','Die andere Seite des Sees','Tauche unter die Wasseroberfläche.'],
 ['forest','Zwischen den Fichten','Erkunde den nördlichen Wald.'],['summit','Über den Wolken','Erreiche eine Höhe von 80 Blöcken.'],
 ['night','Das Tal bei Nacht','Erlebe die Welt nach Sonnenuntergang.'],['builder','Ein Ort zum Bleiben','Platziere insgesamt 100 Blöcke.'],
 ['wanderer','Ein Kilometer Freiheit','Lege zu Fuß oder im Kreativflug 1.000 Blöcke zurück.'],['photo','Ein Moment für später','Nimm mit F2 ein Foto auf.']
];
const RECIPES=[
 {id:'boards',out:12,qty:8,needs:{6:2},name:'Eichenbretter'},
 {id:'darkwood',out:22,qty:8,needs:{8:2},name:'Dunkles Bauholz'},
 {id:'clay',out:20,qty:4,needs:{2:3,4:1},name:'Lehm-Mischung'},
 {id:'brick',out:13,qty:6,needs:{3:4,20:2},name:'Verbundziegel'},
 {id:'cobble',out:21,qty:4,needs:{3:4},name:'Bruchstein'},
 {id:'glass',out:14,qty:4,needs:{4:6,16:1},name:'Bauglas'},
 {id:'marble',out:19,qty:4,needs:{3:6,17:1},name:'Heller Werkstein'},
 {id:'light',out:15,qty:2,needs:{17:2,16:2},name:'Lichtsteine'},
 {id:'lantern',out:27,qty:2,needs:{16:2,12:2,17:1},name:'Laternen'},
 {id:'tool',out:16,qty:1,needs:{16:6,12:4,17:1},name:'Werkzeug verbessern',tool:true}
];
async function api(path,body=null,raw=false,keepalive=false){
    const response=await fetch(path,{method:body===null?'GET':'POST',headers:{'X-Verdant-Key':window.__VERDANT_KEY__,...(body===null?{}:{'Content-Type':'application/json'})},body:body===null?undefined:JSON.stringify(body),signal:keepalive?undefined:AbortSignal.timeout(raw?45000:30000),keepalive});
    if(!response.ok){let error;try{error=await response.json();}catch{}throw Error(error?.error||`Serverantwort ${response.status}`);}
    return raw?response.arrayBuffer():response.json();
}
function toast(title,message='',warning=false){
    const div=document.createElement('div');div.className='toast'+(warning?' warning':'');const strong=document.createElement('strong'),p=document.createElement('p');strong.textContent=title;p.textContent=message;div.append(strong,p);$('toast-stack').append(div);
    if($('toast-stack').children.length>4)$('toast-stack').firstElementChild.remove();setTimeout(()=>{div.classList.add('toast-out');setTimeout(()=>div.remove(),450);},warning?6500:4200);
}
function fatal(error){console.error(error);$('fatal-message').textContent=String(error.message||error);$('fatal').classList.remove('hidden');document.exitPointerLock?.();}
class Game {
    constructor(){
        this.canvas=$('world');this.audio=new Soundscape();this.keys=new Set();this.started=false;this.playing=false;this.panel=null;this.photo=false;this.hideUI=false;this.debug=false;this.clock=.35;this.rain=0;this.time=0;this.selected=0;this.bar=DEFAULT_BAR.slice();this.inventory=Array(30).fill(0);this.inventory[12]=24;this.inventory[3]=16;this.inventory[27]=4;this.stats={mined:0,placed:0,crafted:0,photos:0};this.toolLevel=1;this.found=new Set();this.undo=[];this.busy=false;this.mineProgress=0;this.mouseDown=false;this.rightDown=false;this.lastPlace=0;this.lastSave=0;this.lastHUD=0;this.lastWarning=0;this.fps=0;this.frameTimes=[];this.operation=Promise.resolve();this.saving=null;this.inventoryTab='Alle';this.panelTab='blocks';this.shutdown=false;
        try{this.settings={...DEFAULTS,...JSON.parse(localStorage.getItem('verdant.settings.v1')||'{}')};}catch{this.settings={...DEFAULTS};}this.validateSettings();
    }
    validateSettings(){const s=this.settings;s.quality=clamp(Number(s.quality)||0,0,2)|0;s.fov=clamp(Number(s.fov)||73,55,105);s.sensitivity=clamp(Number(s.sensitivity)||1,.3,2.5);s.exposure=clamp(Number(s.exposure)||1,.60,1.5);s.volume=clamp(Number(s.volume)||0,0,1);s.daySpeed=clamp(Number(s.daySpeed)||0,0,3);s.bob=!!s.bob;if(!['creative','expedition'].includes(s.mode))s.mode='creative';if(!['auto','clear','rain'].includes(s.weather))s.weather='auto';}
    async init(){
        this.renderer=new Renderer(this.canvas);await this.renderer.init();this.renderer.applyPreset(this.settings.quality);this.renderer.onError=fatal;this.world=new VoxelWorld(api,this.renderer);
        this.world.onError=message=>{if(this.time-this.lastWarning>12){toast('Verbindung zur Welt',message,true);this.lastWarning=this.time;}};
        const config=await api('/api/config');this.loadConfig(config);this.bind();this.audio.setVolume(this.settings.volume);this.renderBar();this.updateMode();
        this.lastFrame=performance.now();requestAnimationFrame(t=>this.frame(t));this.initialized=true;window.verdant=this;
        if(config.warning)toast('Spielstand wiederhergestellt',config.warning,true);
    }
    loadConfig(config){
        this.seed=config.seed;this.world.reset(this.seed);this.world.center=null;this.player=new Player(config.spawn);this.player.onRespawn=()=>toast('Zurück am Aussichtspunkt','Deine gesammelten Materialien bleiben erhalten.');
        const p=config.player||{};
        // Weltdatei als dauerhafter Fallback: Browser-Origins ändern sich bei zufälligen Ports.
        if(p.preferences&&typeof p.preferences==='object'&&!Array.isArray(p.preferences)){
            this.settings={...this.settings,...p.preferences};this.validateSettings();
            if(this.renderer.quality!==this.settings.quality)this.renderer.applyPreset(this.settings.quality);
            this.audio.setVolume(this.settings.volume);this.persistSettings();
        }
        this.player.load(p);this.clock=Number.isFinite(p.clock)?((p.clock%1)+1)%1:.35;
        if(Array.isArray(p.inventory)&&p.inventory.length===30)this.inventory=p.inventory.map(n=>clamp(Math.floor(Number(n)||0),0,999999));else{this.inventory=Array(30).fill(0);this.inventory[12]=24;this.inventory[3]=16;this.inventory[27]=4;}
        this.bar=Array.isArray(p.bar)&&p.bar.length===9?p.bar.map((n,i)=>PALETTE.some(b=>b.id===n)?n:DEFAULT_BAR[i]):DEFAULT_BAR.slice();
        this.selected=clamp(Math.floor(Number(p.selected)||0),0,8);this.toolLevel=clamp(Math.floor(Number(p.toolLevel)||1),1,4);
        this.stats={mined:0,placed:0,crafted:0,photos:0};for(const k of Object.keys(this.stats))this.stats[k]=clamp(Math.floor(Number(p.stats?.[k])||0),0,10000000);
        this.found=new Set(Array.isArray(p.found)?p.found.filter(id=>JOURNEY.some(j=>j[0]===id)):[]);this.undo=[];this.mineProgress=0;
        if(this.settings.mode!=='creative')this.player.flying=false;
        $('seed-label').textContent='SEED '+this.seed;this.updateMode();
    }
    bind(){
        $('enter').onclick=()=>this.enter();$('new-world').onclick=()=>this.openPanel('world');$('open-settings').onclick=()=>this.openPanel('settings');$('close-panel').onclick=()=>this.closePanel();
        $('panel-backdrop').onclick=e=>{if(e.target===$('panel-backdrop'))this.closePanel();};
        document.addEventListener('pointerlockchange',()=>{
            if(document.pointerLockElement===this.canvas){this.playing=true;this.started=true;this.panel=null;this.syncUI();}
            else if(this.playing){this.pause();}
        });
        document.addEventListener('pointerlockerror',()=>{if(document.pointerLockElement!==this.canvas){this.playing=false;this.syncUI();toast('Maussteuerung freigeben','Klicke erneut auf „Welt betreten“. Nach Escape kann der Browser eine kurze Pause verlangen.',true);}});
        this.canvas.addEventListener('click',()=>{if(!this.panel&&!this.playing)this.enter();});
        document.addEventListener('mousemove',e=>{if(!this.playing||this.panel)return;const factor=.0022*this.settings.sensitivity;this.player.yaw=(this.player.yaw+e.movementX*factor)%(Math.PI*2);this.player.pitch=clamp(this.player.pitch-e.movementY*factor,-1.545,1.545);});
        document.addEventListener('keydown',e=>this.keyDown(e));document.addEventListener('keyup',e=>this.keys.delete(e.code));
        document.addEventListener('mousedown',e=>{
            if(!this.playing||this.panel||this.photo)return;if(e.button===0)this.mouseDown=true;if(e.button===2){this.rightDown=true;this.place();}if(e.button===1){e.preventDefault();const hit=this.target;if(hit&&PALETTE.some(b=>b.id===hit.id)){this.bar[this.selected]=hit.id;this.renderBar();}}
        });
        document.addEventListener('mouseup',e=>{if(e.button===0){this.mouseDown=false;this.mineProgress=0;}if(e.button===2)this.rightDown=false;});
        this.canvas.addEventListener('contextmenu',e=>e.preventDefault());
        document.addEventListener('wheel',e=>{if(!this.playing||this.panel)return;e.preventDefault();this.selected=(this.selected+(e.deltaY>0?1:8))%9;this.mineProgress=0;this.renderBar();},{passive:false});
        window.addEventListener('blur',()=>{this.keys.clear();if(this.playing)this.pause();});
        document.addEventListener('visibilitychange',()=>{if(document.hidden){if(this.playing)this.pause();this.save(true).catch(()=>{});}});
        window.addEventListener('beforeunload',()=>{if(this.world&&!this.shutdown)api('/api/save',{seed:this.seed,player:this.snapshot()},false,true).catch(()=>{});});
        window.addEventListener('error',e=>{console.error(e.error||e.message);});
    }
    keyDown(e){
        if(e.code==='Escape'){if(this.panel){e.preventDefault();this.closePanel();}else if(this.playing)this.pause();return;}
        if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;
        if(e.repeat&&['KeyE','KeyC','KeyJ','KeyP','KeyF','KeyR','F1','F2','F3','F11'].includes(e.code))return;
        if(e.code==='F2'){e.preventDefault();this.takePhoto();return;}
        if(e.code==='F11'){return;}
        if(e.code==='F3'){e.preventDefault();this.debug=!this.debug;this.syncUI();return;}
        if(e.ctrlKey&&e.code==='KeyS'){e.preventDefault();this.save().catch(err=>toast('Speichern fehlgeschlagen',err.message,true));return;}
        if(e.code==='F1'){e.preventDefault();this.hideUI=!this.hideUI;this.syncUI();return;}
        if(!this.playing||this.panel)return;
        if(['Space','Tab','KeyW','KeyA','KeyS','KeyD','ShiftLeft','ControlLeft'].includes(e.code))e.preventDefault();this.keys.add(e.code);
        if(/^Digit[1-9]$/.test(e.code)){this.selected=Number(e.code.slice(-1))-1;this.renderBar();}
        if(e.code==='KeyE'){e.preventDefault();this.openPanel('inventory');}
        if(e.code==='KeyC'){e.preventDefault();this.panelTab='craft';this.openPanel('inventory');}
        if(e.code==='KeyJ'){e.preventDefault();this.openPanel('journal');}
        if(e.code==='KeyF'){
            if(this.settings.mode==='creative'&&!this.photo){this.player.flying=!this.player.flying;this.player.vel[1]=0;toast(this.player.flying?'Freier Kreativflug':'Wieder zu Fuß',this.player.flying?'Leertaste: aufsteigen · Shift: sinken · Strg: schneller':'Leertaste: springen · Shift: sprinten');}
            else if(!this.photo)toast('Expeditionsmodus','Freies Fliegen ist im Kreativmodus verfügbar.');
        }
        if(e.code==='KeyP')this.togglePhoto();
        if(e.code==='KeyR'&&this.photo){const values=['clear','rain','auto'];this.settings.weather=values[(values.indexOf(this.settings.weather)+1)%3];toast('Wetter',this.settings.weather==='clear'?'Klar':this.settings.weather==='rain'?'Regen zieht auf':'Automatischer Wechsel');this.persistSettings();}
        if(e.ctrlKey&&e.code==='KeyZ'){e.preventDefault();this.undoEdit();}
    }
    async enter(){
        if(!this.ready)return;this.closePanel(false);this.keys.clear();this.audio.start();
        try{const p=this.canvas.requestPointerLock();if(p?.catch)p.catch(err=>{toast('Maussteuerung',err.message,true);});}catch(err){toast('Maussteuerung',err.message,true);}
    }
    pause(){this.playing=false;this.keys.clear();this.mouseDown=false;this.rightDown=false;this.mineProgress=0;if(document.pointerLockElement)document.exitPointerLock();this.syncUI();if(this.started)this.save(true).catch(()=>{});}
    syncUI(){
        const menu=!this.playing&&!this.panel,active=this.playing&&!this.panel;
        $('menu').classList.toggle('hidden',!menu);$('hud').classList.toggle('hidden',!active||this.photo||this.hideUI);$('photo-hud').classList.toggle('hidden',!active||!this.photo||this.hideUI);$('debug').classList.toggle('hidden',!this.debug||this.hideUI);$('panel-backdrop').classList.toggle('hidden',!this.panel);
        document.body.classList.toggle('playing',active||!!this.panel);$('brandbar').style.visibility=this.hideUI&&active?'hidden':'';
        $('enter').querySelector('span').textContent=this.ready?(this.started?'Zurück in die Welt':'Welt betreten'):'Welt wird vorbereitet';
    }
    updateMode(){const creative=this.settings.mode==='creative';$('mode-tag').textContent=creative?'KREATIV':'EXPEDITION';document.querySelector('.menu-foot span:last-child').textContent=creative?'Keine Regeln für deine Ideen.':'Sammeln. Herstellen. Deinen Weg finden.';if(!creative&&!this.photo)this.player.flying=false;$('vitals').classList.toggle('hidden',creative);this.renderBar();}
    openPanel(type){
        this.panel=type;this.playing=false;this.keys.clear();this.mouseDown=false;this.rightDown=false;this.mineProgress=0;if(document.pointerLockElement)document.exitPointerLock();this.syncUI();this.drawPanel();
        setTimeout(()=>$('close-panel').focus(),50);
    }
    closePanel(sync=true){this.panel=null;$('panel-backdrop').classList.add('hidden');if(sync)this.syncUI();}
    drawPanel(){
        const names={inventory:'Dein Inventar',settings:'Ganz dein Gefühl.',journal:'Dein Reisebuch',world:'Eine andere Welt.'};$('panel-title').textContent=names[this.panel]||'VERDANT';$('panel-kicker').textContent=this.panel==='settings'?'GRAFIK, KLANG & STEUERUNG':this.panel==='journal'?'KLEINE SCHRITTE. EIGENE GESCHICHTEN.':'DEIN SPIELRAUM';
        if(this.panel==='inventory')this.drawInventory();if(this.panel==='settings')this.drawSettings();if(this.panel==='journal')this.drawJournal();if(this.panel==='world')this.drawWorldForm();
    }
    icon(id){return this.renderer.materials.icons[id];}
    makeSlot(id,index,mini=false){
        const button=document.createElement('button');button.className='slot'+(index===this.selected?' active':'');button.title=BLOCKS[id].name+' · Platz '+(index+1);button.innerHTML=`<span class="number">${index+1}</span><img src="${this.icon(id)}" alt=""><span class="count">${this.settings.mode==='creative'?'∞':this.inventory[id]}</span>`;
        button.onclick=e=>{e.stopPropagation();this.selected=index;this.renderBar();if(mini)this.drawInventory();};return button;
    }
    renderBar(){if(!this.renderer)return;const h=$('hotbar');h.replaceChildren(...this.bar.map((id,i)=>this.makeSlot(id,i)));$('selected-name').textContent=BLOCKS[this.bar[this.selected]].name;}
    drawInventory(){
        const root=$('panel-content');root.innerHTML=`<div class="tabs"><button class="tab ${this.panelTab==='blocks'?'active':''}" data-tab="blocks">Materialien</button><button class="tab ${this.panelTab==='craft'?'active':''}" data-tab="craft">Werkbank</button><span style="margin-left:auto;align-self:center;font-size:9px;color:var(--muted)">WERKZEUG STUFE ${this.toolLevel} / 4</span></div><div id="inventory-body"></div>`;
        root.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{this.panelTab=b.dataset.tab;this.drawInventory();});
        if(this.panelTab==='craft'){this.drawCraft($('inventory-body'));return;}
        const body=$('inventory-body'),cats=['Alle','Natur','Holz','Gestein','Bauen','Erze','Licht'];
        body.innerHTML=`<div class="tabs" style="border:0;margin-bottom:15px;padding:0;flex-wrap:wrap">${cats.map(c=>`<button class="tab ${this.inventoryTab===c?'active':''}" data-category="${c}">${c}</button>`).join('')}</div><div class="inventory-grid" id="blocks-grid"></div><div class="inventory-footer"><span>Klicke ein Material, um es in Platz <strong>${this.selected+1}</strong> zu legen.</span><div class="mini-hotbar" id="mini-hotbar"></div></div>`;
        body.querySelectorAll('[data-category]').forEach(b=>b.onclick=()=>{this.inventoryTab=b.dataset.category;this.drawInventory();});
        for(const block of PALETTE.filter(b=>this.inventoryTab==='Alle'||b.category===this.inventoryTab)){
            const b=document.createElement('button');b.className='block-card';b.title=block.name;b.innerHTML=`<img src="${this.icon(block.id)}" alt=""><strong>${block.name}</strong><small>${this.settings.mode==='creative'?'Unbegrenzt':this.inventory[block.id]+' im Rucksack'}</small>`;b.onclick=()=>{this.bar[this.selected]=block.id;this.renderBar();this.drawInventory();this.audio.tap('stone',.12);};$('blocks-grid').append(b);
        }
        $('mini-hotbar').replaceChildren(...this.bar.map((id,i)=>this.makeSlot(id,i,true)));
    }
    canCraft(recipe){return (!recipe.tool||this.toolLevel<4)&&(this.settings.mode==='creative'||Object.entries(recipe.needs).every(([id,count])=>this.inventory[id]>=count));}
    drawCraft(body){
        body.innerHTML='<div class="notice">Spielrezepte statt realistischer Fertigungsprozesse. Im Kreativmodus sind Materialien frei. In der Expedition werden Zutaten tatsächlich verbraucht. Shift + Klick stellt bis zu fünf Chargen her.</div><div class="craft-grid" id="recipes"></div>';
        for(const recipe of RECIPES){const div=document.createElement('div');div.className='recipe';div.innerHTML=`<img src="${this.icon(recipe.out)}" alt=""><div><h3>${recipe.name}</h3><p>${Object.entries(recipe.needs).map(([id,c])=>`${c} × ${BLOCKS[id].name}`).join(' · ')}</p></div><button ${this.canCraft(recipe)?'':'disabled'}>${recipe.tool?this.toolLevel>=4?'Maximale Stufe erreicht':'Auf Stufe '+(this.toolLevel+1)+' verbessern':recipe.qty+' × herstellen'}</button>`;div.querySelector('button').onclick=e=>this.craft(recipe,e.shiftKey?5:1);$('recipes').append(div);}
    }
    craft(recipe,batches=1){
        let made=0;for(let i=0;i<batches&&this.canCraft(recipe);i++){
            if(this.settings.mode!=='creative')for(const [id,c] of Object.entries(recipe.needs))this.inventory[id]-=c;
            if(recipe.tool)this.toolLevel++;else this.inventory[recipe.out]=Math.min(999999,this.inventory[recipe.out]+recipe.qty);made++;this.stats.crafted++;
        }
        if(made){this.discover('craft');this.audio.tap('stone',.21);toast(recipe.tool?'Werkzeug verbessert':'Hergestellt',recipe.tool?'Dein Werkzeug arbeitet jetzt schneller.':`${made*recipe.qty} × ${BLOCKS[recipe.out].name}`);this.renderBar();this.drawInventory();}
    }
    drawSettings(){
        const s=this.settings,root=$('panel-content');root.innerHTML=`<div class="preset-grid">${PRESETS.map((p,i)=>`<button class="preset ${s.quality===i?'active':''}" data-quality="${i}"><span class="preset-label">${i===0?'MEHR RESERVEN':i===1?'DIE GOLDENE MITTE':'MEHR SICHTWEITE'}</span><h3>${p.name}</h3><p>${p.radius*16} Blöcke Radius · ${p.shadow}px Schatten<br>${i===0?'Ohne SSAO':'Mit SSAO'} · ${p.reflection}px Spiegelung</p></button>`).join('')}</div>
        <div class="settings-grid">
        ${this.slider('fov','Sichtfeld',55,105,1,s.fov,'°')}${this.slider('sensitivity','Mausempfindlichkeit',.3,2.5,.05,s.sensitivity,'×')}
        ${this.slider('exposure','Belichtung',.6,1.5,.05,s.exposure,'×')}${this.slider('volume','Umgebung & Effekte',0,1,.05,s.volume,'')}
        ${this.slider('clock','Tageszeit',0,23.99,.1,this.clock*24,' Uhr')}${this.slider('daySpeed','Zeitverlauf',0,3,.25,s.daySpeed,'×')}
        <div class="setting"><label>Spielmodus</label><select id="mode-select"><option value="creative" ${s.mode==='creative'?'selected':''}>Kreativ: frei bauen und fliegen</option><option value="expedition" ${s.mode==='expedition'?'selected':''}>Expedition: sammeln, herstellen, erkunden</option></select></div>
        <div class="setting"><label>Wetter</label><select id="weather-select"><option value="auto" ${s.weather==='auto'?'selected':''}>Automatischer Wechsel</option><option value="clear" ${s.weather==='clear'?'selected':''}>Klarer Himmel</option><option value="rain" ${s.weather==='rain'?'selected':''}>Regen</option></select></div>
        <div class="setting"><label>Kamerabewegung beim Gehen</label><select id="bob-select"><option value="yes" ${s.bob?'selected':''}>Leichtes Mitschwingen</option><option value="no" ${!s.bob?'selected':''}>Ruhige Kamera</option></select></div>
        <div class="setting"><label>Rendering</label><p class="muted" style="margin:0;font-size:10px">${this.renderer.floatColor?'HDR aktiv':'Standard-Farbraum als Fallback'} · Native Shader · Kein Shaderpack<br>Die Bildrate hängt von Gerät, Browser und Sichtweite ab.</p></div>
        </div><div class="settings-bottom"><button class="text-button" id="controls-button">Steuerung & Hinweise ↗</button><button class="text-button" id="quit-button">Speichern & beenden</button><button class="primary" id="settings-done">Übernehmen <span>✓</span></button></div>`;
        root.querySelectorAll('[data-quality]').forEach(b=>b.onclick=()=>{s.quality=Number(b.dataset.quality);this.renderer.applyPreset(s.quality);this.world.center=null;this.persistSettings();this.drawSettings();});
        root.querySelectorAll('input[type=range]').forEach(input=>input.oninput=()=>{const name=input.dataset.setting,value=Number(input.value);if(name==='clock')this.clock=value/24;else{s[name]=value;this.audio.setVolume(s.volume);this.persistSettings();}$(name+'-value').textContent=value.toFixed(name==='fov'?0:name==='clock'?1:2)+(input.dataset.unit||'');});
        $('mode-select').onchange=e=>{s.mode=e.target.value;this.updateMode();this.persistSettings();};$('weather-select').onchange=e=>{s.weather=e.target.value;this.persistSettings();};$('bob-select').onchange=e=>{s.bob=e.target.value==='yes';this.persistSettings();};
        $('settings-done').onclick=()=>this.closePanel();$('controls-button').onclick=()=>this.drawControls();$('quit-button').onclick=()=>this.quit();
    }
    slider(name,label,min,max,step,value,unit){return `<div class="setting"><label for="setting-${name}">${label}<small id="${name}-value">${Number(value).toFixed(name==='fov'?0:2)}${unit}</small></label><input id="setting-${name}" type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-setting="${name}" data-unit="${unit}"></div>`;}
    drawControls(){
        $('panel-title').textContent='Schnell zu Hause.';const keys=[['W A S D','Bewegen'],['MAUS','Umsehen'],['LINKS HALTEN','Block abbauen'],['RECHTS','Block platzieren'],['MITTELKLICK','Material übernehmen'],['1 – 9 / MAUSRAD','Schnellleiste'],['LEERTASTE','Springen / hochfliegen'],['SHIFT','Sprinten / herunterfliegen'],['F','Kreativflug an / aus'],['STRG IM FLUG','Schneller fliegen'],['E / C','Inventar / Werkbank'],['J','Reisebuch'],['P','Freier Fotomodus'],['F2','PNG-Foto aufnehmen'],['T / G IM FOTOMODUS','Tageszeit vor / zurück'],['R IM FOTOMODUS','Wetter wechseln'],['F1 / F3','Oberfläche / Diagnostik'],['STRG + Z','Letzten Bau rückgängig (Kreativ)'],['STRG + S','Spielstand speichern'],['ESC','Maus freigeben / Pause']];
        $('panel-content').innerHTML=`<div class="help-grid">${keys.map(([k,v])=>`<div class="help-line"><span>${v}</span><kbd>${k}</kbd></div>`).join('')}</div><div class="notice" style="margin-top:24px">In der Expedition kosten Blöcke Material. Stürze und zu langes Tauchen können dich zum Aussichtspunkt zurückbringen. Es gibt noch keine Gegner, keinen Hunger und keine Schaltkreise. Wasser ist eine animierte, nicht fließende Landschaftsoberfläche. Der Fotomodus verändert deinen Spielerstandort nicht dauerhaft.</div><button id="back-settings" class="text-button">← Zurück zu den Einstellungen</button>`;$('back-settings').onclick=()=>this.drawSettings();
    }
    persistSettings(){try{localStorage.setItem('verdant.settings.v1',JSON.stringify(this.settings));}catch{}}
    drawJournal(){
        $('panel-content').innerHTML=`<div class="journal-summary"><div><strong>${this.found.size}<span style="font-size:15px;color:var(--muted)"> / ${JOURNEY.length}</span></strong><small>ENTDECKUNGEN</small></div><div><strong>${Math.floor(this.player.distance).toLocaleString('de-DE')}</strong><small>BLÖCKE UNTERWEGS</small></div><div><strong>${this.stats.placed}</strong><small>BLÖCKE GESETZT</small></div><div><strong>${this.stats.mined}</strong><small>BLÖCKE ABGEBAUT</small></div></div>${JOURNEY.map(([id,title,detail])=>`<div class="journey-row ${this.found.has(id)?'done':''}"><div class="journey-check">${this.found.has(id)?'✓':'·'}</div><div><h3>${title}</h3><p>${detail}</p></div></div>`).join('')}`;
    }
    drawWorldForm(){
        $('panel-content').innerHTML=`<div class="world-form"><p>Jeder Seed erzeugt eine eigene Variante des Tals. Bereits besuchte Seeds öffnen ihren vorhandenen Spielstand. Deine jetzige Welt wird vorher gespeichert, nicht überschrieben.</p><label for="world-seed">Welt-Seed</label><input id="world-seed" type="number" min="-1000000000" max="1000000000" step="1" value="${this.seed}"><button id="random-seed" class="text-button">Zufälligen Seed wählen ↻</button><button class="primary" id="create-world">Welt öffnen <span>↗</span></button><p style="font-size:10px">Weltgrenzen: ±50.000 Blöcke · Bauhöhe: 128 Blöcke.<br>Maximal 250.000 gespeicherte Blockänderungen pro Welt.</p></div>`;
        $('random-seed').onclick=()=>{$('world-seed').value=Math.floor(Math.random()*999999999);};
        $('create-world').onclick=async()=>{const seed=Number($('world-seed').value);if(!Number.isInteger(seed)||Math.abs(seed)>1000000000){toast('Ungültiger Seed','Bitte eine ganze Zahl zwischen −1 Milliarde und 1 Milliarde eingeben.',true);return;}const button=$('create-world');button.disabled=true;button.textContent='Welt wird geöffnet …';
            try{if(this.photo)this.togglePhoto();await this.save(true);const config=await api('/api/world',{seed});this.loadConfig(config);this.ready=false;this.started=false;this.closePanel();this.syncUI();toast('Eine neue Aussicht',`Welt ${seed} wird aufgebaut.`);}catch(err){toast('Welt nicht geöffnet',err.message,true);button.disabled=false;button.textContent='Erneut versuchen';}
        };
    }
    async quit(){
        const button=$('quit-button');if(button){button.disabled=true;button.textContent='Wird gespeichert …';}
        try{await this.save(true);await api('/api/quit',{});this.shutdown=true;$('fatal').classList.remove('hidden');$('fatal').querySelector('h2').textContent='Bis zum nächsten Kapitel.';$('fatal-message').textContent='Deine Welt wurde gespeichert. Der lokale Java-Server wurde beendet. Du kannst diesen Tab jetzt schließen.';$('fatal').querySelector('button').style.display='none';}
        catch(err){toast('Noch nicht beendet',err.message,true);if(button){button.disabled=false;button.textContent='Speichern & beenden';}}
    }
    discover(id){if(this.found.has(id))return;const item=JOURNEY.find(j=>j[0]===id);if(!item)return;this.found.add(id);this.audio.chime();toast('Entdeckung · '+item[1],item[2]);}
    biome(){const [x,y,z]=this.player.pos;if(y>77)return 'Schneegipfel';if(z< -36)return 'Fichtenwald';if(Math.hypot((x+3)/43,(z+5)/53)<1.35)return 'Am Alpensee';return 'Wiesenland';}
    checkDiscoveries(){if(!this.started||this.photo)return;const p=this.player;if(p.underwater)this.discover('dive');if(p.pos[2]<-36)this.discover('forest');if(p.pos[1]>80)this.discover('summit');if(this.clock>.80||this.clock<.22)this.discover('night');if(p.distance>=1000)this.discover('wanderer');}
    async mine(hit){
        if(this.busy||hit.id===26)return;this.busy=true;
        this.operation=(async()=>{
            try{const old=await this.world.edit(hit.x,hit.y,hit.z,0);if(old===0)return;this.inventory[old]=Math.min(999999,this.inventory[old]+1);this.stats.mined++;this.undo.push({...hit,old,id:0});if(this.undo.length>128)this.undo.shift();this.renderer.burst(hit.x,hit.y,hit.z,old);this.audio.tap(old===1||old===7||old===9?'grass':'stone');this.discover('first-mine');if(old===16)this.discover('copper');if(old===17)this.discover('crystal');this.renderBar();}
            catch(err){toast('Block blieb unverändert',err.message,true);}
            finally{this.busy=false;this.mineProgress=0;}
        })();await this.operation;
    }
    async place(){
        if(!this.playing||this.photo||this.busy||!this.target||this.time-this.lastPlace<.18)return;this.lastPlace=this.time;
        const h=this.target,id=this.bar[this.selected],x=h.x+h.normal[0],y=h.y+h.normal[1],z=h.z+h.normal[2];
        if(this.settings.mode!=='creative'&&this.inventory[id]<=0){toast('Material fehlt',`${BLOCKS[id].name} musst du erst sammeln oder herstellen.`);return;}
        if(this.player.intersects(x,y,z)){toast('Da stehst du gerade.','Ein Schritt zurück schafft Platz.');return;}
        const current=this.world.get(x,y,z);if(current===null||current!==0&&current!==24&&current!==25&&current!==5)return;if(y<=0||y>=128)return;
        this.busy=true;this.operation=(async()=>{
            try{const old=await this.world.edit(x,y,z,id);if(this.settings.mode!=='creative')this.inventory[id]--;this.stats.placed++;this.undo.push({x,y,z,old,id});if(this.undo.length>128)this.undo.shift();this.audio.tap('stone',.24);this.discover('first-build');if(this.stats.placed>=100)this.discover('builder');this.renderBar();}
            catch(err){toast('Nicht gebaut',err.message,true);}finally{this.busy=false;}
        })();await this.operation;
    }
    async undoEdit(){
        if(this.settings.mode!=='creative'){toast('Rückgängig ist im Kreativmodus verfügbar.');return;}if(this.busy||!this.undo.length)return;const edit=this.undo[this.undo.length-1];if(solid(edit.old)&&this.player.intersects(edit.x,edit.y,edit.z)){toast('Erst einen Schritt zurück.','Der ursprüngliche Block würde deinen Standort belegen.');return;}
        this.busy=true;this.operation=(async()=>{try{await this.world.edit(edit.x,edit.y,edit.z,edit.old);this.undo.pop();toast('Letzte Änderung rückgängig gemacht.');}catch(err){toast('Nicht rückgängig gemacht',err.message,true);}finally{this.busy=false;}})();await this.operation;
    }
    togglePhoto(){
        if(!this.photo){this.photoOrigin=this.player.snapshot();this.player.flying=true;this.player.vel=[0,0,0];this.photo=true;this.mouseDown=false;this.rightDown=false;toast('Freier Fotomodus','T / G: Licht verändern · R: Wetter · F2: PNG-Foto · P: zurück');}
        else{this.player.load(this.photoOrigin);this.player.vel=[0,0,0];this.photo=false;}this.syncUI();
    }
    async takePhoto(){
        if(!this.initialized||this.shutdown)return;const state=this.renderState(0);state.hideUI=true;state.target=null;this.renderer.render(this.world,this.camera(),state);
        const blob=await this.renderer.screenshot();if(!blob){toast('Foto fehlgeschlagen','Der Browser konnte kein PNG erstellen.',true);return;}
        const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='VERDANT_'+this.seed+'_'+new Date().toISOString().replace(/[:.]/g,'-')+'.png';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);this.stats.photos++;this.discover('photo');toast('Moment festgehalten','Das PNG wurde an den Browser-Download übergeben.');
    }
    snapshot(){
        const base=this.photo?this.photoOrigin:this.player.snapshot();return {...base,preferences:{...this.settings},clock:this.clock,inventory:this.inventory.slice(),bar:this.bar.slice(),selected:this.selected,toolLevel:this.toolLevel,stats:{...this.stats},found:[...this.found]};
    }
    async save(quiet=false){
        if(!this.world||this.shutdown)return;if(this.saving)return this.saving;
        this.saving=(async()=>{await this.operation;await api('/api/save',{seed:this.seed,player:this.snapshot()});this.lastSave=this.time;$('save-label').textContent='Lokal gespeichert';if(!quiet)toast('Welt gespeichert','Standort, Rucksack, Entdeckungen und Blockänderungen sind gesichert.');})();
        try{return await this.saving;}finally{this.saving=null;}
    }
    camera(){
        if(!this.started){const eye=[22.5,40.2,37.5],focus=[-8,34,-29],dir=norm(focus.map((v,i)=>v-eye[i]));return {eye,dir,fov:68};}
        return {eye:this.player.eye(this.settings.bob&&!this.photo),dir:this.player.direction(),fov:this.settings.fov};
    }
    renderState(dt){return {clock:this.clock,time:this.time,rain:this.rain,exposure:this.settings.exposure,underwater:this.started&&this.player.underwater,target:this.playing?this.target:null,hideUI:this.hideUI||this.photo,dt};}
    frame(now){
        if(this.shutdown)return;requestAnimationFrame(t=>this.frame(t));let dt=Math.min(.05,Math.max(0,(now-this.lastFrame)/1000));const actual=(now-this.lastFrame)/1000;this.lastFrame=now;this.time+=dt;
        this.frameTimes.push(actual);if(this.frameTimes.length>45)this.frameTimes.shift();this.fps=this.frameTimes.length/this.frameTimes.reduce((a,b)=>a+b,0);
        const desiredRain=this.settings.weather==='rain'?1:this.settings.weather==='clear'?0:clamp((Math.sin(this.time/110-1.7)-.80)/.17,0,1);this.rain=lerp(this.rain,desiredRain,1-Math.exp(-dt*.17));
        if(this.playing){
            if(this.photo){if(this.keys.has('KeyT'))this.clock=(this.clock+dt*.055)%1;if(this.keys.has('KeyG'))this.clock=(this.clock-dt*.055+1)%1;}
            else this.clock=(this.clock+dt/1200*this.settings.daySpeed)%1;
            const steps=Math.max(1,Math.ceil(dt/(1/120)));for(let i=0;i<steps;i++){const result=this.player.update(dt/steps,this.keys,this.world,{creative:this.settings.mode==='creative',photo:this.photo});if(result.step){const id=this.world.get(Math.floor(this.player.pos[0]),Math.floor(this.player.pos[1]-.1),Math.floor(this.player.pos[2]));this.audio.tap(result.water?'water':id===1?'grass':'stone',.15);}}
            this.target=this.photo?null:this.world.raycast(this.player.eye(false),this.player.direction(),7);
            if(this.mouseDown&&this.target&&!this.busy&&!this.photo){
                const k=`${this.target.x},${this.target.y},${this.target.z}`;if(k!==this.mineKey){this.mineKey=k;this.mineProgress=0;}
                const duration=this.settings.mode==='creative'?.16:Math.max(.10,BLOCKS[this.target.id].hardness/(.7+(this.toolLevel-1)*.38));this.mineProgress+=dt/duration;if(this.mineProgress>=1)this.mine({...this.target});
            }else if(!this.mouseDown||!this.target)this.mineProgress=0;
            if(this.rightDown&&!this.busy)this.place();
        }
        const camera=this.camera();this.world.update(camera.eye,this.renderer.settings.radius);
        if(!this.ready&&this.renderer.chunkCount>=9){this.ready=true;$('enter').disabled=false;this.syncUI();}
        try{this.renderer.render(this.world,camera,this.renderState(dt));}catch(err){this.shutdown=true;fatal(err);return;}
        this.audio.update(this.time,this.rain,this.renderer.env?.day||1,!this.playing);
        if(this.time-this.lastHUD>.17){this.lastHUD=this.time;this.updateHUD();this.checkDiscoveries();}
        if(this.started&&this.time-this.lastSave>20&&!this.saving){this.lastSave=this.time;this.save(true).catch(err=>toast('Automatisches Speichern fehlgeschlagen',err.message,true));}
    }
    updateHUD(){
        const p=this.player,clock=Math.floor(this.clock*1440),h=String(Math.floor(clock/60)).padStart(2,'0'),m=String(clock%60).padStart(2,'0');$('world-time').textContent=h+':'+m;$('weather-label').textContent=this.rain>.4?'Regen':this.rain>.1?'Bewölkt':'Klar';$('coordinates').textContent=p.pos.map(v=>Math.floor(v)).join(' / ');$('biome-label').textContent=this.biome();$('flight-label').textContent=this.photo?'FREIE KAMERA':p.flying?'KREATIVFLUG':p.underwater?'UNTER WASSER':'ZU FUSS';$('target-label').textContent=this.target&&!this.photo?BLOCKS[this.target.id].name:'';$('mine-ring').style.strokeDashoffset=119.4*(1-clamp(this.mineProgress,0,1));$('health').value=p.health;$('oxygen').value=p.oxygen;$('oxygen-wrap').style.opacity=p.oxygen<99?'1':'.35';
        const stat=this.renderer.stats();$('load-status').textContent=this.world.queue.length||this.world.loading?`${this.world.totalLoaded} Landschaftsabschnitte · weitere werden geladen`:`${stat.loaded} Landschaftsabschnitte · Welt bereit`;
        if(this.debug)$('debug').textContent=`VERDANT 0.1 / ${stat.quality}\n${Math.round(this.fps)} FPS · ${stat.width} × ${stat.height}\n${stat.visible} sichtbar / ${stat.loaded} Chunks\n${Math.round(stat.triangles/1000)}k Dreiecke / ${stat.drawCalls} Draw Calls\nJava-Seed ${this.seed} / ${this.world.jobs.size} Mesh-Jobs\n${stat.floatColor?'HDR +':'LDR +'} PCF-Schatten + Wasserreflexion\n${stat.device.slice(0,96)}`;
    }
}
const game=new Game();game.init().catch(fatal);
