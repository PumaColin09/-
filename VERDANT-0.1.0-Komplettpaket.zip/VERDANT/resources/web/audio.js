/** Leise, prozedural erzeugte Klänge. Kein Audio-Download und keine Samples. */
export class Soundscape {
    constructor(){this.volume=.42;this.lastBird=0;}
    start(){
        if(this.ctx){this.ctx.resume().catch(()=>{});return;}
        try{
            this.ctx=new (window.AudioContext||window.webkitAudioContext)();const c=this.ctx;this.master=c.createGain();this.master.gain.value=this.volume;this.master.connect(c.destination);
            const b=c.createBuffer(1,c.sampleRate*3,c.sampleRate),d=b.getChannelData(0);let v=0;for(let i=0;i<d.length;i++){v=(v+(Math.random()*2-1)*.022)/1.023;d[i]=v*3.2;}
            this.noise=b;const n=c.createBufferSource();n.buffer=b;n.loop=true;const filter=c.createBiquadFilter();filter.type='lowpass';filter.frequency.value=380;this.wind=c.createGain();this.wind.gain.value=.045;n.connect(filter);filter.connect(this.wind);this.wind.connect(this.master);n.start();
            const rain=c.createBufferSource();rain.buffer=b;rain.loop=true;rain.playbackRate.value=2.7;this.rain=c.createGain();this.rain.gain.value=0;rain.connect(this.rain);this.rain.connect(this.master);rain.start();
        }catch(e){console.warn('Audio nicht verfügbar',e);}
    }
    setVolume(v){this.volume=v;if(this.master)this.master.gain.setTargetAtTime(v,this.ctx.currentTime,.1);}
    tap(kind='stone',volume=.28){
        if(!this.ctx||this.ctx.state!=='running')return;const c=this.ctx,t=c.currentTime,n=c.createBufferSource();n.buffer=this.noise;n.playbackRate.value=kind==='grass'?2.1:kind==='water'?.65:1.2;
        const f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=kind==='grass'?1800:kind==='water'?650:420;const g=c.createGain();g.gain.setValueAtTime(volume,t);g.gain.exponentialRampToValueAtTime(.001,t+.11);n.connect(f);f.connect(g);g.connect(this.master);n.start(t);n.stop(t+.13);
    }
    chime(){if(!this.ctx)return;const c=this.ctx,t=c.currentTime;for(const [hz,off]of [[660,0],[990,.10]]){const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=hz;g.gain.setValueAtTime(0,t+off);g.gain.linearRampToValueAtTime(.05,t+off+.01);g.gain.exponentialRampToValueAtTime(.001,t+off+.5);o.connect(g);g.connect(this.master);o.start(t+off);o.stop(t+off+.6);}}
    update(time,rain,day,paused){
        if(!this.ctx)return;this.rain.gain.setTargetAtTime(paused?0:rain*.11,this.ctx.currentTime,.6);this.wind.gain.setTargetAtTime(paused?.015:.04+rain*.015,this.ctx.currentTime,.8);
        if(day>.6&&rain<.3&&!paused&&time-this.lastBird>14){this.lastBird=time;const c=this.ctx,t=c.currentTime;for(let i=0;i<3;i++){const o=c.createOscillator(),g=c.createGain(),at=t+i*.16;o.frequency.setValueAtTime(1700+i*120,at);o.frequency.exponentialRampToValueAtTime(2900-i*150,at+.055);o.frequency.exponentialRampToValueAtTime(1400,at+.12);g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(.017,at+.02);g.gain.exponentialRampToValueAtTime(.0001,at+.12);o.connect(g);g.connect(this.master);o.start(at);o.stop(at+.14);}}
    }
}
