import {perspective,lookAt,multiply,invert,ortho,frustum,visible,norm,clamp,lerp} from './math.js';
import {makeMaterials,tint} from './materials.js';
import {blockIndex,H} from './mesher.js';
const PRESETS=[
    {name:'Leicht',radius:5,scale:.80,shadow:1024,reflection:256,ao:0,bloom:.07},
    {name:'Ausgewogen',radius:9,scale:1,shadow:2048,reflection:512,ao:1,bloom:.12},
    {name:'Cinematic',radius:10,scale:1.15,shadow:4096,reflection:768,ao:2,bloom:.16}
];
export {PRESETS};
class Program {
    constructor(gl,name,vs,fs){this.gl=gl;this.name=name;const shader=(type,source)=>{const sh=gl.createShader(type);gl.shaderSource(sh,source);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS)){const error=gl.getShaderInfoLog(sh);gl.deleteShader(sh);throw Error(`${name}: ${error}`);}return sh;};let v=shader(gl.VERTEX_SHADER,vs),f=shader(gl.FRAGMENT_SHADER,fs);this.id=gl.createProgram();gl.attachShader(this.id,v);gl.attachShader(this.id,f);gl.linkProgram(this.id);gl.deleteShader(v);gl.deleteShader(f);if(!gl.getProgramParameter(this.id,gl.LINK_STATUS))throw Error(name+': '+gl.getProgramInfoLog(this.id));this.locations=new Map();}
    use(){this.gl.useProgram(this.id);return this}
    loc(name){if(!this.locations.has(name))this.locations.set(name,this.gl.getUniformLocation(this.id,name));return this.locations.get(name)}
    f(name,v){this.gl.uniform1f(this.loc(name),v);return this}
    i(name,v){this.gl.uniform1i(this.loc(name),v);return this}
    v2(name,v){this.gl.uniform2fv(this.loc(name),v);return this}
    v3(name,v){this.gl.uniform3fv(this.loc(name),v);return this}
    v4(name,v){this.gl.uniform4fv(this.loc(name),v);return this}
    m(name,v){this.gl.uniformMatrix4fv(this.loc(name),false,v);return this}
}
export class Renderer {
    constructor(canvas){
        this.canvas=canvas;this.gl=canvas.getContext('webgl2',{alpha:false,antialias:false,depth:true,powerPreference:'high-performance',preserveDrawingBuffer:false});
        if(!this.gl)throw Error('WebGL 2 ist nicht verfügbar. Bitte Chrome, Edge oder Firefox mit aktivierter Hardwarebeschleunigung verwenden.');
        const gl=this.gl;this.floatColor=!!gl.getExtension('EXT_color_buffer_float');this.materials=makeMaterials(gl);this.emptyVAO=gl.createVertexArray();
        const info=gl.getExtension('WEBGL_debug_renderer_info');this.device=info?gl.getParameter(info.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);
        this.frame=0;this.targets=[];this.particles=[];this.drawCalls=0;this.triangles=0;this.shadowSize=0;this.settings={...PRESETS[1]};
        this.particleVAO=gl.createVertexArray();this.particleBuffer=gl.createBuffer();gl.bindVertexArray(this.particleVAO);gl.bindBuffer(gl.ARRAY_BUFFER,this.particleBuffer);
        for(const [i,size,offset]of [[0,3,0],[1,4,3],[2,1,7]]){gl.enableVertexAttribArray(i);gl.vertexAttribPointer(i,size,gl.FLOAT,false,32,offset*4);}gl.bindVertexArray(null);
        const line=[];const edges=[[0,1],[0,2],[0,4],[1,3],[1,5],[2,3],[2,6],[3,7],[4,5],[4,6],[5,7],[6,7]];
        for(const edge of edges)for(const i of edge)line.push(((i&1)?1.003:-.003),((i&2)?1.003:-.003),((i&4)?1.003:-.003));
        this.lineVAO=gl.createVertexArray();this.lineBuffer=gl.createBuffer();gl.bindVertexArray(this.lineVAO);gl.bindBuffer(gl.ARRAY_BUFFER,this.lineBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(line),gl.STATIC_DRAW);gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,3,gl.FLOAT,false,12,0);gl.bindVertexArray(null);
        this.rainSeeds=Array.from({length:420},(_,i)=>{let r=()=>{let x=Math.sin((i+1)*13.37+Math.random()*3)*43758;return x-Math.floor(x)};return [(r()-.5)*44,r()*32,(r()-.5)*44,r()]});
        canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true;this.onError?.('Die Grafikkarte hat den WebGL-Kontext verloren. Weltänderungen bleiben auf dem Java-Server. Bitte neu laden.');});
        canvas.addEventListener('webglcontextrestored',()=>location.reload());
    }
    async init(){
        const files=['terrain.vert','terrain.frag','shadow.frag','fullscreen.vert','sky.frag','water.vert','water.frag','bloom.frag','post.frag','line.vert','line.frag','particle.vert','particle.frag'];
        const map={};await Promise.all(files.map(async n=>{const r=await fetch('/shaders/'+n+'.glsl');if(!r.ok)throw Error('Shader fehlt: '+n);map[n]=await r.text();}));
        const g=this.gl,p=(name,v,f)=>new Program(g,name,map[v],map[f]);
        this.terrain=p('Oberflächen','terrain.vert','terrain.frag');this.shadowProgram=p('Schatten','terrain.vert','shadow.frag');this.sky=p('Atmosphäre','fullscreen.vert','sky.frag');this.water=p('Wasser','water.vert','water.frag');this.bloom=p('Bloom','fullscreen.vert','bloom.frag');this.post=p('Nachbearbeitung','fullscreen.vert','post.frag');this.line=p('Blockmarkierung','line.vert','line.frag');this.particle=p('Partikel','particle.vert','particle.frag');
        this.applyPreset(1);return this;
    }
    applyPreset(index){this.quality=clamp(index|0,0,2);this.settings={...PRESETS[this.quality]};this.resize(true);}
    texture2D(w,h,depth=false){
        const gl=this.gl,t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);
        gl.texImage2D(gl.TEXTURE_2D,0,depth?gl.DEPTH_COMPONENT24:this.floatColor?gl.RGBA16F:gl.RGBA8,w,h,0,depth?gl.DEPTH_COMPONENT:gl.RGBA,depth?gl.UNSIGNED_INT:this.floatColor?gl.HALF_FLOAT:gl.UNSIGNED_BYTE,null);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,depth?gl.NEAREST:gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,depth?gl.NEAREST:gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);return t;
    }
    target(w,h,depth=true,color=true){
        const gl=this.gl,fbo=gl.createFramebuffer(),t={fbo,w,h};gl.bindFramebuffer(gl.FRAMEBUFFER,fbo);
        if(color){t.color=this.texture2D(w,h);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,t.color,0);}else{gl.drawBuffers([gl.NONE]);gl.readBuffer(gl.NONE);}
        if(depth){t.depth=this.texture2D(w,h,true);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.DEPTH_ATTACHMENT,gl.TEXTURE_2D,t.depth,0);}
        if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Die Grafikkarte unterstützt dieses Renderziel nicht.');this.targets.push(t);gl.bindFramebuffer(gl.FRAMEBUFFER,null);return t;
    }
    resize(force=false){
        const scale=Math.min(devicePixelRatio||1,1.5)*this.settings.scale,w=Math.max(480,Math.min(2560,Math.round(innerWidth*scale))),h=Math.max(270,Math.min(1600,Math.round(innerHeight*scale)));
        if(!force&&this.canvas.width===w&&this.canvas.height===h)return;
        this.canvas.width=w;this.canvas.height=h;const gl=this.gl;
        for(const t of this.targets){gl.deleteFramebuffer(t.fbo);if(t.color)gl.deleteTexture(t.color);if(t.depth)gl.deleteTexture(t.depth);}this.targets=[];
        this.scene=this.target(w,h);this.final=this.target(w,h);let rw=this.settings.reflection;this.reflection=this.target(rw,Math.max(128,Math.round(rw*h/w)));
        this.bloomA=this.target(Math.max(64,Math.floor(w/4)),Math.max(64,Math.floor(h/4)),false);this.bloomB=this.target(this.bloomA.w,this.bloomA.h,false);
        this.shadowSize=Math.min(this.settings.shadow,gl.getParameter(gl.MAX_TEXTURE_SIZE));this.shadow=this.target(this.shadowSize,this.shadowSize,true,false);this.reflectionVP=null;
    }
    bindTexture(unit,texture,target=this.gl.TEXTURE_2D){const gl=this.gl;gl.activeTexture(gl.TEXTURE0+unit);gl.bindTexture(target,texture);}
    setTarget(t){const gl=this.gl;gl.bindFramebuffer(gl.FRAMEBUFFER,t?.fbo||null);gl.viewport(0,0,t?.w||this.canvas.width,t?.h||this.canvas.height);}
    full(program){this.gl.bindVertexArray(this.emptyVAO);this.gl.drawArrays(this.gl.TRIANGLES,0,3);this.drawCalls++;}
    uploadMesh(data){
        if(!data.length)return null;const gl=this.gl,vao=gl.createVertexArray(),vbo=gl.createBuffer();gl.bindVertexArray(vao);gl.bindBuffer(gl.ARRAY_BUFFER,vbo);gl.bufferData(gl.ARRAY_BUFFER,data,gl.STATIC_DRAW);
        for(const [loc,size,offset]of [[0,3,0],[1,3,3],[2,2,6],[3,1,8],[4,1,9],[5,1,10]]){gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,44,offset*4);}gl.bindVertexArray(null);return {vao,vbo,count:data.length/11};
    }
    uploadChunk(c,m){
        this.deleteChunk(c);c.gpu={solid:this.uploadMesh(m.solid),water:this.uploadMesh(m.water),glass:this.uploadMesh(m.glass)};c.quads=m.quads;c.lights=[];
        for(let y=1;y<H;y++)for(let z=0;z<16;z++)for(let x=0;x<16;x++){const id=c.data[blockIndex(x,y,z)];if(id===15||id===27)c.lights.push({pos:[c.cx*16+x+.5,y+.7,c.cz*16+z+.5],color:id===27?[1,.63,.25]:[.60,.92,.55]});}
    }
    deleteChunk(c){if(!c.gpu)return;const gl=this.gl;for(const m of Object.values(c.gpu))if(m){gl.deleteVertexArray(m.vao);gl.deleteBuffer(m.vbo);}c.gpu=null;}
    drawMesh(m){if(!m)return;this.gl.bindVertexArray(m.vao);this.gl.drawArrays(this.gl.TRIANGLES,0,m.count);this.drawCalls++;this.triangles+=m.count/3;}
    environment(clock,rain,time){
        const angle=(clock-.25)*Math.PI*2,real=norm([Math.cos(angle)*.78,Math.sin(angle),.36]),day=clamp((real[1]+.11)/.28,0,1),sun=real[1]>0?real:norm([-.5,.65,-.6]);
        const warmth=clamp((sun[1]-.10)/.6,0,1),sunColor=[1,lerp(.64,.94,warmth),lerp(.34,.81,warmth)];return {sun,day,sunColor,time,rain,fog:lerp(.00165,.0065,rain),wind:1+rain*1.6};
    }
    baseUniforms(p,camera,env,vp){p.m('uViewProj',vp).m('uLightMatrix',this.lightMatrix).v3('uCamera',camera).v3('uSun',env.sun).v3('uSunColor',env.sunColor).f('uDay',env.day).f('uTime',env.time).f('uRain',env.rain).f('uWind',env.wind).f('uFog',env.fog).f('uViewDistance',(this.settings.radius-.3)*16);}
    terrainUniforms(camera,env,vp,reflection=0){
        const gl=this.gl,p=this.terrain.use();this.baseUniforms(p,camera,env,vp);p.i('uAlbedo',0).i('uNormal',1).i('uShadowMap',2).f('uShadowTexel',1/this.shadowSize).i('uShadows',1).i('uReflection',reflection).i('uDistant',0).i('uLightCount',this.lights.length);
        if(this.lights.length){p.v3('uPointPos[0]',this.lights.flatMap(l=>l.pos));p.v3('uPointColor[0]',this.lights.flatMap(l=>l.color));}
        this.bindTexture(0,this.materials.albedo,gl.TEXTURE_2D_ARRAY);this.bindTexture(1,this.materials.normal,gl.TEXTURE_2D_ARRAY);this.bindTexture(2,this.shadow.depth);
    }
    drawSky(camera,env,vp){
        const gl=this.gl;gl.disable(gl.DEPTH_TEST);gl.depthMask(false);gl.disable(gl.BLEND);const p=this.sky.use();this.baseUniforms(p,camera,env,vp);p.m('uInvViewProj',invert(vp));this.full(p);gl.depthMask(true);gl.enable(gl.DEPTH_TEST);
    }
    render(world,camera,state){
        if(this.lost)return;this.resize();const gl=this.gl;this.frame++;this.drawCalls=0;this.triangles=0;
        const eye=camera.eye,dir=camera.dir,far=420,proj=perspective(camera.fov*Math.PI/180,this.canvas.width/this.canvas.height,.08,far),view=lookAt(eye,eye.map((x,i)=>x+dir[i])),vp=multiply(proj,view),planes=frustum(vp),env=this.environment(state.clock,state.rain,state.time);
        this.lastVP=vp;this.env=env;this.lastCamera=eye;this.lastState=state;
        const chunks=Array.from(world.chunks.values()).filter(c=>c.gpu),mainChunks=chunks.filter(c=>visible(c.box,planes));
        this.lights=chunks.flatMap(c=>c.lights||[]).sort((a,b)=>Math.hypot(...a.pos.map((x,i)=>x-eye[i]))-Math.hypot(...b.pos.map((x,i)=>x-eye[i]))).slice(0,8);
        const center=[Math.floor(eye[0]/8)*8,35,Math.floor(eye[2]/8)*8],extent=(this.settings.radius+1)*16;
        const lightEye=center.map((x,i)=>x+env.sun[i]*240),lm=multiply(ortho(-extent,extent,-extent,extent,1,520),lookAt(lightEye,center));this.lightMatrix=lm;
        // 1. Sonnen-Schattenkarte, einschließlich Vegetation mit Alpha-Ausschnitt.
        this.setTarget(this.shadow);gl.enable(gl.DEPTH_TEST);gl.depthMask(true);gl.disable(gl.BLEND);gl.disable(gl.CULL_FACE);gl.clearDepth(1);gl.clear(gl.DEPTH_BUFFER_BIT);gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(1.4,2.0);
        let p=this.shadowProgram.use();this.baseUniforms(p,eye,env,lm);p.i('uAlbedo',0);this.bindTexture(0,this.materials.albedo,gl.TEXTURE_2D_ARRAY);for(const c of chunks)this.drawMesh(c.gpu.solid);gl.disable(gl.POLYGON_OFFSET_FILL);
        // 2. Echte planare Spiegelung: zweite Kamera an der Seeoberfläche gespiegelt.
        const reflectedEye=[eye[0],55.8-eye[1],eye[2]],reflectedDir=[dir[0],-dir[1],dir[2]],rvp=multiply(proj,lookAt(reflectedEye,reflectedEye.map((x,i)=>x+reflectedDir[i])));
        this.reflectionVP=rvp;this.setTarget(this.reflection);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);this.drawSky(reflectedEye,env,rvp);
        this.terrainUniforms(reflectedEye,env,rvp,1);if(world.lod){this.terrain.i("uDistant",1);this.drawMesh(world.lod.gpu.solid);this.terrain.i("uDistant",0);}const rp=frustum(rvp);for(const c of chunks)if(visible(c.box,rp))this.drawMesh(c.gpu.solid);
        // 3. Undurchsichtige Welt. Dies ist die Quelle für Brechung und Tiefenmessung.
        this.setTarget(this.scene);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);this.drawSky(eye,env,vp);this.terrainUniforms(eye,env,vp);if(world.lod){this.terrain.i("uDistant",1);this.drawMesh(world.lod.gpu.solid);this.terrain.i("uDistant",0);}for(const c of mainChunks)this.drawMesh(c.gpu.solid);
        gl.bindFramebuffer(gl.READ_FRAMEBUFFER,this.scene.fbo);gl.bindFramebuffer(gl.DRAW_FRAMEBUFFER,this.final.fbo);gl.blitFramebuffer(0,0,this.scene.w,this.scene.h,0,0,this.final.w,this.final.h,gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT,gl.NEAREST);
        // 4. Wasser mit Brechung, Tiefenabsorption, Fresnel-Effekt und Wellen.
        this.setTarget(this.final);p=this.water.use();this.baseUniforms(p,eye,env,vp);p.m('uReflectionVP',rvp).v2('uResolution',[this.canvas.width,this.canvas.height]).f('uFar',far).i('uScene',0).i('uDepth',1).i('uReflection',2).i('uReflections',1);
        this.bindTexture(0,this.scene.color);this.bindTexture(1,this.scene.depth);this.bindTexture(2,this.reflection.color);gl.disable(gl.BLEND);gl.depthMask(true);for(const c of mainChunks)this.drawMesh(c.gpu.water);
        // 5. Glas und Eis, von hinten nach vorn auf Chunkebene sortiert.
        this.terrainUniforms(eye,env,vp);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);
        mainChunks.sort((a,b)=>(b.cx*16+8-eye[0])**2+(b.cz*16+8-eye[2])**2-((a.cx*16+8-eye[0])**2+(a.cz*16+8-eye[2])**2));for(const c of mainChunks)this.drawMesh(c.gpu.glass);gl.depthMask(true);
        if(state.target&&!state.hideUI){p=this.line.use().m('uViewProj',vp).v3('uOffset',[state.target.x,state.target.y,state.target.z]).v4('uColor',[.87,.95,.75,.80]);gl.bindVertexArray(this.lineVAO);gl.depthFunc(gl.LEQUAL);gl.drawArrays(gl.LINES,0,24);gl.depthFunc(gl.LESS);}
        this.drawParticles(eye,env,vp,state.dt||0);gl.disable(gl.BLEND);
        // 6. Bloom und endgültiges Bild inklusive SSAO, Tonemapping und Kantenfilter.
        gl.disable(gl.DEPTH_TEST);gl.depthMask(false);this.setTarget(this.bloomA);p=this.bloom.use().i('uTexture',0).i('uExtract',1).v2('uDirection',[1/this.canvas.width,0]);this.bindTexture(0,this.final.color);this.full(p);
        this.setTarget(this.bloomB);p.use().i('uExtract',0).v2('uDirection',[1/this.bloomA.w,0]);this.bindTexture(0,this.bloomA.color);this.full(p);
        this.setTarget(this.bloomA);p.use().v2('uDirection',[0,1/this.bloomA.h]);this.bindTexture(0,this.bloomB.color);this.full(p);
        this.setTarget(null);p=this.post.use().i('uScene',0).i('uDepth',1).i('uBloom',2).m('uInvProjection',invert(proj)).v2('uResolution',[this.canvas.width,this.canvas.height]).f('uExposure',state.exposure??1).f('uBloomStrength',this.settings.bloom).f('uTime',state.time).i('uAO',this.settings.ao).i('uUnderwater',state.underwater?1:0);
        this.bindTexture(0,this.final.color);this.bindTexture(1,this.final.depth);this.bindTexture(2,this.bloomA.color);this.full(p);gl.depthMask(true);gl.bindVertexArray(null);
        this.visibleChunks=mainChunks.length;this.chunkCount=chunks.length;
    }
    burst(x,y,z,id){
        const c=tint(id).map(v=>(v/255)**2.2);for(let i=0;i<22;i++)this.particles.push({p:[x+.5+(Math.random()-.5)*.6,y+.5+(Math.random()-.5)*.6,z+.5+(Math.random()-.5)*.6],v:[(Math.random()-.5)*3,1.7+Math.random()*3,(Math.random()-.5)*3],c,life:.45+Math.random()*.45,size:.04+Math.random()*.07});if(this.particles.length>300)this.particles.splice(0,this.particles.length-300);
    }
    drawParticles(eye,env,vp,dt){
        const gl=this.gl;for(const p of this.particles){p.life-=dt;p.v[1]-=8*dt;for(let k=0;k<3;k++)p.p[k]+=p.v[k]*dt;}this.particles=this.particles.filter(p=>p.life>0);
        const submit=(arr,rain)=>{if(!arr.length)return;const p=this.particle.use().m('uViewProj',vp).v3('uCamera',eye).f('uScale',this.canvas.height*.65).i('uRainMode',rain);gl.bindVertexArray(this.particleVAO);gl.bindBuffer(gl.ARRAY_BUFFER,this.particleBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.DYNAMIC_DRAW);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.enable(gl.DEPTH_TEST);gl.depthMask(false);gl.drawArrays(gl.POINTS,0,arr.length/8);gl.depthMask(true);};
        submit(this.particles.flatMap(p=>[...p.p,...p.c,Math.min(1,p.life*3),p.size]),0);
        if(env.rain>.04){const arr=[];for(let i=0;i<this.rainSeeds.length*env.rain;i++){const s=this.rainSeeds[i],y=((s[1]-env.time*17)%32+32)%32-8,xx=((s[0]+env.time*2)%44+66)%44-22;arr.push(eye[0]+xx,eye[1]+y,eye[2]+s[2],.49,.62,.65,.36*env.rain,.36+s[3]*.16);}submit(arr,1);}
    }
    screenshot(){return new Promise(resolve=>this.canvas.toBlob(resolve,'image/png'));}
    stats(){return {device:this.device,floatColor:this.floatColor,drawCalls:this.drawCalls,triangles:this.triangles,loaded:this.chunkCount,visible:this.visibleChunks,shaders:8,quality:this.settings.name,width:this.canvas.width,height:this.canvas.height};}
}
