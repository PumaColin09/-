import {opaque,solid} from './materials.js';
export const H=128,P=18,S=16;
export const blockIndex=(x,y,z)=>((y+1)*P+(z+1))*P+x+1;
const dims=[16,H,16];
const get=(a,x,y,z)=>x< -1||x>16||z< -1||z>16||y< -1||y>H?0:a[blockIndex(x,y,z)];
const occ=id=>opaque(id)&&id!==7&&id!==9;
const layer=(b,d,sg)=>b===1&&d===1?(sg>0?31:2):(b===6||b===8)&&d===1?30:b;
function boundary(b,n){
    if(!solid(b)||b===5)return false;
    if(b===14||b===29)return n!==b&&!opaque(n);
    if(b===7||b===9)return n!==b&&!occ(n);
    return !occ(n);
}
function ambient(a,p,d,u,v,sg){
    const q=p.slice();q[d]+=sg;let bits=0;
    for(let i=0;i<4;i++){
        const su=(i===0||i===3)?-1:1,sv=i<2?-1:1,r=q.slice(),s=q.slice(),t=q.slice();r[u]+=su;s[v]+=sv;t[u]+=su;t[v]+=sv;
        const x=+occ(get(a,...r)),y=+occ(get(a,...s)),z=+occ(get(a,...t)),value=x&&y?0:3-x-y-z;bits|=value<<(i*2);
    }
    return bits;
}
const AO=[.43,.64,.82,1];
function quad(out,p,du,dv,n,uvW,uvH,mat,ao,offset,sky=1){
    const points=[p,p.map((x,i)=>x+du[i]),p.map((x,i)=>x+du[i]+dv[i]),p.map((x,i)=>x+dv[i])];
    const flip=n[0]+n[1]+n[2]<0;const order=flip?[0,2,1,0,3,2]:[0,1,2,0,2,3],uv=[[0,0],[uvW,0],[uvW,uvH],[0,uvH]];
    for(const i of order){const q=points[i];out.push(q[0]+offset[0],q[1],q[2]+offset[1],n[0],n[1],n[2],uv[i][0],uv[i][1],mat,AO[(ao>>(i*2))&3],sky);}
}
export function meshChunk(a,cx,cz){
    const out=[],water=[],glass=[],off=[cx*16,cz*16];let quads=0;
    const tops=new Int16Array(P*P);for(let z=-1;z<=16;z++)for(let x=-1;x<=16;x++){for(let y=H-1;y>=0;y--)if(occ(get(a,x,y,z))){tops[(z+1)*P+x+1]=y;break;}}
    for(let d=0;d<3;d++)for(const sg of [-1,1]){
        const u=(d+1)%3,v=(d+2)%3,W=dims[u],V=dims[v],mask=new Int32Array(W*V);
        for(let depth=0;depth<dims[d];depth++){
            mask.fill(0);
            for(let j=0;j<V;j++)for(let i=0;i<W;i++){
                const p=[0,0,0];p[d]=depth;p[u]=i;p[v]=j;const b=get(a,...p);if(!solid(b))continue;
                const q=p.slice();q[d]+=sg;const near=get(a,...q);if(!boundary(b,near))continue;
                const mat=layer(b,d,sg),ao=ambient(a,p,d,u,v,sg);const roof=Math.min(tops[(p[2]+1)*P+p[0]+1],tops[(q[2]+1)*P+q[0]+1]??127);const sky=Math.max(2,Math.min(15,Math.round(15*Math.exp(-Math.max(0,roof-p[1]-1)*.20))));mask[j*W+i]=(sky<<14)|((mat+1)<<8)|ao;
            }
            for(let j=0;j<V;j++)for(let i=0;i<W;){
                const key=mask[j*W+i];if(!key){i++;continue;}let w=1,h=1;
                while(i+w<W&&mask[j*W+i+w]===key)w++;
                height:while(j+h<V){for(let k=0;k<w;k++)if(mask[(j+h)*W+i+k]!==key)break height;h++;}
                const p=[0,0,0],du=[0,0,0],dv=[0,0,0],n=[0,0,0];p[d]=depth+(sg>0?1:0);p[u]=i;p[v]=j;du[u]=w;dv[v]=h;n[d]=sg;
                const mat=((key>>8)&63)-1,target=mat===14||mat===29?glass:out;quad(target,p,du,dv,n,w,h,mat,key&255,off,(key>>14)/15);quads++;
                for(let y=0;y<h;y++)mask.fill(0,(j+y)*W+i,(j+y)*W+i+w);i+=w;
            }
        }
    }
    // Getrennte Wassergeometrie: nur Oberflächen, keine versteckten Wasserwürfel.
    for(let y=0;y<H;y++)for(let z=0;z<16;z++)for(let x=0;x<16;x++){
        const b=get(a,x,y,z);
        if(b===5&&get(a,x,y+1,z)!==5){
            quad(water,[x,y+.90,z],[0,0,1],[1,0,0],[0,1,0],1,1,5,255,off);quads++;
        }
        if(b===24||b===25){
            const height=b===25?.74:.82;
            for(const sign of [-1,1]){
                const n=[.707,0,-sign*.707],positions=[[x+.15,y,z+(sign<0?.85:.15)],[x+.85,y,z+(sign<0?.15:.85)],[x+.85,y+height,z+(sign<0?.15:.85)],[x+.15,y+height,z+(sign<0?.85:.15)]],uv=[[0,1],[1,1],[1,0],[0,0]];
                for(const i of [0,1,2,0,2,3])out.push(positions[i][0]+off[0],positions[i][1],positions[i][2]+off[1],...n,...uv[i],b,.94,1);
            }
        }
    }
    return {solid:new Float32Array(out),water:new Float32Array(water),glass:new Float32Array(glass),quads};
}
