import {blockIndex,H,P,S} from './mesher.js';
import {solid} from './materials.js';
export class VoxelWorld {
    constructor(api,renderer){
        this.api=api;this.renderer=renderer;this.chunks=new Map();this.pending=new Set();this.loading=0;this.epoch=0;this.seed=0;this.failed=0;
        this.workers=Array.from({length:Math.max(1,Math.min(3,(navigator.hardwareConcurrency||4)-1))},()=>{const w=new Worker('/worker.js',{type:'module'});w.onmessage=e=>this.meshed(e.data);w.onerror=e=>{console.error('Mesh-Worker',e.message);this.onError?.('Die Weltgeometrie konnte nicht erstellt werden. Bitte neu laden.');};return w;});
        this.jobs=new Map();this.jobId=0;this.workerIndex=0;this.lod=null;this.lodCenter=null;this.queue=[];this.dirty=new Set();this.totalLoaded=0;
    }
    reset(seed){if(this.lod)this.renderer.deleteChunk(this.lod);this.lod=null;this.lodCenter=null;for(const c of this.chunks.values())this.renderer.deleteChunk(c);this.chunks.clear();this.pending.clear();this.queue=[];this.epoch++;this.seed=seed;this.failed=0;this.totalLoaded=0;this.dirty.clear();}
    key(cx,cz){return cx+','+cz}
    get(x,y,z){
        if(y<0)return 26;if(y>=H)return 0;const cx=Math.floor(x/16),cz=Math.floor(z/16),c=this.chunks.get(this.key(cx,cz));
        if(!c)return null;return c.data[blockIndex(x-cx*16,y,z-cz*16)];
    }
    requestMesh(c){
        if(c.meshing){c.remesh=true;return;}c.meshing=true;const id=++this.jobId;this.jobs.set(id,{c,epoch:this.epoch});
        const copy=c.data.slice();this.workers[this.workerIndex++%this.workers.length].postMessage({id,cx:c.cx,cz:c.cz,buffer:copy.buffer,version:c.version},[copy.buffer]);
    }
    meshed(msg){
        const job=this.jobs.get(msg.id);this.jobs.delete(msg.id);if(!job)return;const {c,epoch}=job;c.meshing=false;
        if(epoch!==this.epoch||this.chunks.get(this.key(c.cx,c.cz))!==c)return;
        if(msg.error){console.error(msg.error);this.onError?.('Fehler beim Erstellen eines Landschaftsabschnitts.');return;}
        if(msg.version===c.version)this.renderer.uploadChunk(c,msg);
        if(c.remesh||msg.version!==c.version){c.remesh=false;this.requestMesh(c);}
    }
    update(position,radius){
        const cx=Math.floor(position[0]/16),cz=Math.floor(position[2]/16);
        const lx=Math.floor(position[0]/64)*64,lz=Math.floor(position[2]/64)*64;if(this.lodCenter!==lx+","+lz&&!this.lodPending){this.lodCenter=lx+","+lz;this.loadLOD(lx,lz);}
        if(this.center!==cx+','+cz+','+radius||this.failed>0){
            this.center=cx+','+cz+','+radius;this.queue=[];
            for(let z=cz-radius;z<=cz+radius;z++)for(let x=cx-radius;x<=cx+radius;x++){
                if((x-cx)**2+(z-cz)**2>(radius+.6)**2||Math.abs(x)>3124||Math.abs(z)>3124)continue;
                const key=this.key(x,z);if(!this.chunks.has(key)&&!this.pending.has(key))this.queue.push({x,z,d:(x-cx)**2+(z-cz)**2});
            }
            this.queue.sort((a,b)=>a.d-b.d);
            for(const [key,c] of this.chunks)if(Math.max(Math.abs(c.cx-cx),Math.abs(c.cz-cz))>radius+2){this.renderer.deleteChunk(c);this.chunks.delete(key);}
            this.failed=0;
        }
        while(this.loading<4&&this.queue.length){const q=this.queue.shift();this.load(q.x,q.z);}
    }
    async loadLOD(x,z){
        this.lodPending=true;const epoch=this.epoch;
        try{
            const bytes=await this.api(`/api/lod?x=${x}&z=${z}&seed=${this.seed}`,null,true);if(epoch!==this.epoch)return;if(bytes.byteLength!==65*65*2)throw Error('Ungültige Fernsichtdaten');
            const d=new DataView(bytes),vertices=[],height=(i,j)=>d.getUint16((j*65+i)*2,false),point=(i,j)=>[x+(i-32)*8,Math.max(26,height(i,j)-1.5),z+(j-32)*8];
            for(let j=0;j<64;j++)for(let i=0;i<64;i++){
                const points=[point(i,j),point(i,j+1),point(i+1,j+1),point(i+1,j)];
                for(const tri of [[0,1,2],[0,2,3]]){
                    const [a,b,c]=tri.map(k=>points[k]),u=b.map((v,k)=>v-a[k]),v=c.map((n,k)=>n-a[k]),n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],len=Math.hypot(...n);for(let k=0;k<3;k++)n[k]/=len;
                    const h=(a[1]+b[1]+c[1])/3,mat=h>79?10:h>62||n[1]<.68?3:h<29?4:31;
                    for(const p of [a,b,c])vertices.push(...p,...n,p[0],p[2],mat,1,1);
                }
            }
            if(this.lod)this.renderer.deleteChunk(this.lod);this.lod={gpu:{solid:this.renderer.uploadMesh(new Float32Array(vertices))}};
        }catch(e){console.warn('Fernsicht:',e);if(epoch===this.epoch)this.lodCenter=null;}
        finally{this.lodPending=false;}
    }
    async load(cx,cz){
        const epoch=this.epoch,seed=this.seed,key=this.key(cx,cz);this.pending.add(key);this.loading++;
        try{
            const buffer=await this.api(`/api/chunk?x=${cx}&z=${cz}&seed=${seed}`,null,true);
            if(epoch!==this.epoch)return;
            if(buffer.byteLength!==P*(H+2)*P)throw Error('Ungültige Chunkdaten');
            const c={cx,cz,data:new Uint8Array(buffer),version:0,meshing:false,box:[cx*16,0,cz*16,cx*16+16,H,cz*16+16]};
            this.chunks.set(key,c);this.totalLoaded++;this.requestMesh(c);
        }catch(e){if(epoch===this.epoch){this.failed++;if(this.failed===1)this.onError?.('Weltserver nicht erreichbar. Das Java-Fenster muss geöffnet bleiben.');}console.warn(e);}
        finally{this.loading--;if(epoch===this.epoch)this.pending.delete(key);}
    }
    apply(x,y,z,id){
        const cx=Math.floor(x/16),cz=Math.floor(z/16);
        for(let nx=cx-1;nx<=cx+1;nx++)for(let nz=cz-1;nz<=cz+1;nz++){
            const c=this.chunks.get(this.key(nx,nz));if(!c)continue;const lx=x-nx*16,lz=z-nz*16;if(lx< -1||lx>16||lz< -1||lz>16)continue;
            c.data[blockIndex(lx,y,lz)]=id;c.version++;this.requestMesh(c);
        }
    }
    async edit(x,y,z,id){
        if(y<=0||y>=H||Math.abs(x)>50000||Math.abs(z)>50000)throw Error('Hier ist die Weltgrenze.');
        const old=this.get(x,y,z);if(old===null)throw Error('Dieser Abschnitt lädt noch.');
        await this.api('/api/edit',{seed:this.seed,x,y,z,id});this.apply(x,y,z,id);return old;
    }
    raycast(origin,direction,max=7){
        let cell=origin.map(Math.floor),normal=[0,0,0];const step=direction.map(v=>v>0?1:-1),delta=direction.map(v=>Math.abs(v)<1e-10?Infinity:Math.abs(1/v));
        let tmax=direction.map((v,i)=>Math.abs(v)<1e-10?Infinity:((cell[i]+(v>0?1:0))-origin[i])/v),distance=0;
        while(distance<=max){
            const b=this.get(...cell);if(b===null)return null;
            if(b!==0&&b!==5)return {x:cell[0],y:cell[1],z:cell[2],id:b,normal:normal.slice(),distance};
            let axis=tmax[0]<tmax[1]?(tmax[0]<tmax[2]?0:2):(tmax[1]<tmax[2]?1:2);distance=tmax[axis];tmax[axis]+=delta[axis];cell[axis]+=step[axis];normal=[0,0,0];normal[axis]=-step[axis];
        }
        return null;
    }
    collides(pos){
        const r=.29,lo=[pos[0]-r,pos[1]+.002,pos[2]-r],hi=[pos[0]+r,pos[1]+1.77,pos[2]+r];
        for(let y=Math.floor(lo[1]);y<=Math.floor(hi[1]);y++)for(let z=Math.floor(lo[2]);z<=Math.floor(hi[2]);z++)for(let x=Math.floor(lo[0]);x<=Math.floor(hi[0]);x++){
            const b=this.get(x,y,z);if(b===null||solid(b))return true;
        }
        return false;
    }
    dispose(){for(const w of this.workers)w.terminate();for(const c of this.chunks.values())this.renderer.deleteChunk(c);}
}
