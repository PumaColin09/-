#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
uniform mat4 uViewProj;
uniform vec3 uOffset;
void main(){gl_Position=uViewProj*vec4(aPosition+uOffset,1.);}
