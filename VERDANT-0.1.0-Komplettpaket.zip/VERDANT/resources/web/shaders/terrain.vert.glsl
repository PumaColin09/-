#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
layout(location=1) in vec3 aNormal;
layout(location=2) in vec2 aUV;
layout(location=3) in float aMaterial;
layout(location=4) in float aAO;
layout(location=5) in float aSky;
uniform mat4 uViewProj;
uniform mat4 uLightMatrix;
uniform float uTime;
uniform float uWind;
out vec3 vWorld;
out vec3 vNormal;
out vec2 vUV;
flat out int vMaterial;
out float vAO;
out float vSky;
out vec4 vShadow;
void main(){
    vec3 p=aPosition;int mat=int(aMaterial+.5);
    if(mat==7||mat==9){float w=sin(p.x*.51+p.z*.28+uTime*1.7)*sin(p.y*.66+uTime*.7);p.xz+=vec2(w,w*.37)*.065*uWind;}
    if(mat==24||mat==25){float bend=(1.-aUV.y);p.xz+=vec2(sin(uTime*2.1+p.x*.67+p.z*.37),cos(uTime*1.3+p.z*.3))*.12*bend*uWind;}
    vWorld=p;vNormal=aNormal;vUV=aUV;vMaterial=mat;vAO=aAO;vSky=aSky;vShadow=uLightMatrix*vec4(p,1.);gl_Position=uViewProj*vec4(p,1.);
}
