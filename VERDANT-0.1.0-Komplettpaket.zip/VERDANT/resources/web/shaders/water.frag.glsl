#version 300 es
precision highp float;
in vec3 vWorld;
in vec4 vReflection;
uniform sampler2D uScene;
uniform sampler2D uDepth;
uniform sampler2D uReflection;
uniform vec2 uResolution;
uniform vec3 uCamera;
uniform vec3 uSun;
uniform vec3 uSunColor;
uniform float uTime;
uniform float uDay;
uniform float uRain;
uniform float uFog;
uniform float uFar;
uniform int uReflections;
out vec4 fragColor;
float linearDepth(float z){float n=.08;return 2.*n*uFar/(uFar+n-(z*2.-1.)*(uFar-n));}
void main(){
    vec2 uv=gl_FragCoord.xy/uResolution;
    float a=vWorld.x*.42+vWorld.z*.31+uTime*1.35,b=vWorld.z*.81-vWorld.x*.18-uTime*1.9;
    float dx=cos(a)*.034*.42-cos(b)*.021*.18,dz=cos(a)*.034*.31+cos(b)*.021*.81;
    float rip=sin(vWorld.x*5.4+uTime*3.)*cos(vWorld.z*4.2-uTime*2.3)*.007*(1.+uRain*2.);
    vec3 N=normalize(vec3(-(dx+rip)*(3.+uRain),1.,-(dz-rip)*(3.+uRain))),V=normalize(uCamera-vWorld);
    if(uCamera.y<vWorld.y)N=-N;
    float thickness=clamp(linearDepth(texture(uDepth,uv).r)-linearDepth(gl_FragCoord.z),0.,35.);
    vec2 distort=N.xz*.018*smoothstep(.1,1.,thickness);vec2 refrUV=clamp(uv+distort,vec2(.001),vec2(.999));
    if(linearDepth(texture(uDepth,refrUV).r)<linearDepth(gl_FragCoord.z))refrUV=uv;
    vec3 under=texture(uScene,refrUV).rgb;
    vec3 waterColor=mix(vec3(.015,.04,.075),vec3(.028,.145,.155),uDay);
    vec3 transmission=exp(-vec3(.27,.095,.07)*thickness);
    vec3 refractColor=under*transmission+waterColor*(1.-transmission);
    vec2 ruv=vReflection.xy/vReflection.w*.5+.5;ruv+=N.xz*.027;ruv=clamp(ruv,vec2(.002),vec2(.998));
    vec3 reflection=uReflections==1?texture(uReflection,ruv).rgb:mix(vec3(.02,.04,.08),vec3(.33,.47,.54),uDay);
    float fresnel=.035+.965*pow(1.-clamp(dot(N,V),0.,1.),5.);
    vec3 color=mix(refractColor,reflection,clamp(fresnel,.06,.94));
    vec3 R=reflect(-uSun,N);float spec=pow(max(dot(R,V),0.),200.);color+=uSunColor*spec*4.5*uDay*(1.-uRain*.8);
    float foam=(1.-smoothstep(.12,1.15,thickness))*(.4+.6*sin(vWorld.x*3.2+sin(vWorld.z*2.8)+uTime*1.6)*.5);
    color=mix(color,vec3(.66,.79,.73)*mix(.15,1.,uDay),clamp(foam,0.,.38));
    float fog=1.-exp(-length(uCamera-vWorld)*uFog*.95);vec3 horizon=mix(vec3(.025,.036,.061),vec3(.56,.66,.69),uDay);
    fragColor=vec4(mix(color,horizon,fog),1.);
}
