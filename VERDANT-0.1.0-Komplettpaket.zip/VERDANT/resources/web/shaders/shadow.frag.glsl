#version 300 es
precision highp float;
precision highp sampler2DArray;
in vec2 vUV;
in vec3 vWorld;
in vec3 vNormal;
flat in int vMaterial;
uniform sampler2DArray uAlbedo;
void main(){int m=vMaterial;vec3 an=abs(vNormal);vec2 uv=an.x>.8?vec2(vWorld.z,1.-vWorld.y):an.y>.8?vec2(vWorld.x,vWorld.z):vec2(vWorld.x,1.-vWorld.y);if(m==24||m==25)uv=vUV;if((m==7||m==9||m==24||m==25)&&texture(uAlbedo,vec3(uv,float(m))).a<.5)discard;}
