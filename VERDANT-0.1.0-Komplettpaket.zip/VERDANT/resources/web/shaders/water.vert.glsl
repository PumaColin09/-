#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
uniform mat4 uViewProj;
uniform mat4 uReflectionVP;
uniform float uTime;
uniform float uRain;
out vec3 vWorld;
out vec4 vReflection;
void main(){vec3 p=aPosition;float wave=sin(p.x*.42+p.z*.31+uTime*1.35)*.034+sin(p.z*.81-p.x*.18-uTime*1.9)*.021;p.y+=wave*(1.+uRain*.65);vWorld=p;vReflection=uReflectionVP*vec4(p.x,27.90,p.z,1.);gl_Position=uViewProj*vec4(p,1.);}
