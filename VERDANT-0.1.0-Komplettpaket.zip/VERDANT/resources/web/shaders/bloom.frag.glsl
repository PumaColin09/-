#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uTexture;
uniform vec2 uDirection;
uniform int uExtract;
out vec4 fragColor;
vec3 sampleColor(vec2 uv){vec3 c=texture(uTexture,uv).rgb;if(uExtract==1)c*=clamp((max(c.r,max(c.g,c.b))-.90)*.70,0.,1.);return c;}
void main(){vec3 c=sampleColor(vUV)*.227027;c+=(sampleColor(vUV+uDirection*1.384615)+sampleColor(vUV-uDirection*1.384615))*.316216;c+=(sampleColor(vUV+uDirection*3.230769)+sampleColor(vUV-uDirection*3.230769))*.070270;fragColor=vec4(c,1.);}
