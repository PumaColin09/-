#version 300 es
precision highp float;
precision highp sampler2DArray;
in vec3 vWorld;
in vec3 vNormal;
in vec2 vUV;
flat in int vMaterial;
in float vAO;
in float vSky;
in vec4 vShadow;
uniform sampler2DArray uAlbedo;
uniform sampler2DArray uNormal;
uniform sampler2D uShadowMap;
uniform vec3 uCamera;
uniform vec3 uSun;
uniform vec3 uSunColor;
uniform float uDay;
uniform float uTime;
uniform float uRain;
uniform float uFog;
uniform float uViewDistance;
uniform float uShadowTexel;
uniform int uShadows;
uniform int uReflection;
uniform int uDistant;
uniform int uLightCount;
uniform vec3 uPointPos[8];
uniform vec3 uPointColor[8];
out vec4 fragColor;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float visibility(vec3 n){
    if(uShadows==0)return 1.;vec3 q=vShadow.xyz/vShadow.w*.5+.5;
    if(q.z<0.||q.z>1.||any(lessThan(q.xy,vec2(.002)))||any(greaterThan(q.xy,vec2(.998))))return 1.;
    float bias=max(.00030*(1.-dot(n,uSun)),.000085),lit=0.;
    for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++){float depth=texture(uShadowMap,q.xy+vec2(float(x),float(y))*uShadowTexel*1.18).r;lit+=step(q.z-bias,depth);}
    return lit/9.;
}
void main(){
    if(uReflection==1&&vWorld.y<27.88)discard;
    if(uDistant==1&&length(vWorld.xz-uCamera.xz)<uViewDistance-26.)discard;
    int m=vMaterial;vec3 an=abs(vNormal);vec2 uv=an.x>.8?vec2(vWorld.z,1.-vWorld.y):an.y>.8?vec2(vWorld.x,vWorld.z):vec2(vWorld.x,1.-vWorld.y);if(m==24||m==25)uv=vUV;vec4 tex=texture(uAlbedo,vec3(uv,float(m)));
    if((m==7||m==9||m==24||m==25)&&tex.a<.48)discard;
    vec3 N=normalize(vNormal);if(!gl_FrontFacing)N=-N;
    vec3 absN=abs(vNormal),T,B;
    if(absN.x>.8){T=vec3(0,0,1);B=vec3(0,-1,0);}else if(absN.y>.8){T=vec3(1,0,0);B=vec3(0,0,1);}else{T=vec3(1,0,0);B=vec3(0,-1,0);}
    vec4 bump=texture(uNormal,vec3(uv,float(m)));vec3 micro=bump.xyz*2.-1.;N=normalize(N+T*micro.x*.43+B*micro.y*.43);
    vec3 albedo=tex.rgb;float variance=.93+.10*sin(vWorld.x*.079+sin(vWorld.z*.043)*2.);
    if(m==7||m==9||m==31||m==1)albedo*=vec3(variance,1.,.94);
    bool foliage=m==7||m==9||m==24||m==25;
    float wet=uRain*clamp(vNormal.y*.8+.2,0.,1.)*vSky;albedo*=1.-wet*.23;
    vec3 V=normalize(uCamera-vWorld);float ndl=max(dot(N,uSun),0.);
    float shadow=visibility(normalize(vNormal));float cloud=1.-uRain*.58;
    vec3 ambient=mix(vec3(.017,.026,.045),vec3(.25,.32,.40),uDay);
    ambient*=mix(.60,1.05,clamp(N.y*.5+.5,0.,1.));
    vec3 light=ambient*vAO*(.09+.91*vSky);
    light+=uSunColor*ndl*shadow*1.85*uDay*cloud*mix(.65,1.,vAO);
    if(foliage)light+=uSunColor*pow(max(dot(-uSun,V),0.),4.)*.34*shadow*uDay*vSky;
    vec3 color=albedo*light;
    float rough=bump.a;rough=mix(rough,.19,wet*.62);float shine=pow(max(dot(N,normalize(uSun+V)),0.),mix(140.,12.,rough));
    color+=uSunColor*shine*mix(.24,.028,rough)*shadow*uDay*ndl;
    for(int i=0;i<8;i++){if(i>=uLightCount)break;vec3 L=uPointPos[i]-vWorld;float dist=length(L),att=pow(max(0.,1.-dist/13.),2.);color+=albedo*uPointColor[i]*att*max(.15,dot(N,normalize(L)))*3.4;}
    if(m==15)color+=tex.rgb*2.1;
    if(m==27&&dot(tex.rgb,vec3(.2126,.7152,.0722))>.30)color+=tex.rgb*3.6;
    if(m==17)color+=albedo*.055;
    float distance=length(uCamera-vWorld),heightFog=exp(-max(vWorld.y-28.,0.)*.037);
    float fog=1.-exp(-distance*uFog*(.50+heightFog*.62));fog=clamp(fog+(uDistant==1?smoothstep(195.,270.,distance)*.90:smoothstep(uViewDistance*.87,uViewDistance+5.,distance)*.28),0.,1.);
    vec3 horizon=mix(vec3(.028,.040,.068),vec3(.56,.66,.69),uDay);horizon=mix(horizon,vec3(.28,.34,.37),uRain*.63);
    float towards=pow(max(dot(normalize(vWorld-uCamera),uSun),0.),10.);horizon+=uSunColor*towards*.22*uDay;
    color=mix(color,horizon,fog);
    float alpha=1.;if(m==14||m==29){float fres=pow(1.-max(0.,dot(N,V)),4.);alpha=m==14?.18+fres*.37:.54+fres*.22;color=mix(color,horizon,.29)+uSunColor*shine*.65;}
    fragColor=vec4(color,alpha);
}
