#version 300 es
precision highp float;
layout(location=0) in vec3 aPosition;
layout(location=1) in vec4 aColor;
layout(location=2) in float aSize;
uniform mat4 uViewProj;
uniform vec3 uCamera;
uniform float uScale;
out vec4 vColor;
void main(){vColor=aColor;gl_Position=uViewProj*vec4(aPosition,1.);gl_PointSize=clamp(aSize*uScale/max(length(aPosition-uCamera),.5),1.,22.);}
