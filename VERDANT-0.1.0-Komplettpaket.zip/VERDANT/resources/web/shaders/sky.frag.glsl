#version 300 es
precision highp float;
in vec2 vUV;
uniform mat4 uInvViewProj;
uniform vec3 uCamera;
uniform vec3 uSun;
uniform vec3 uSunColor;
uniform float uTime;
uniform float uDay;
uniform float uRain;
out vec4 fragColor;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
float fbm(vec2 p){float n=0.,a=.5;for(int i=0;i<5;i++){n+=a*noise(p);p=mat2(1.62,1.17,-1.17,1.62)*p;a*=.51;}return n;}
void main(){
    vec4 world=uInvViewProj*vec4(vUV*2.-1.,1.,1.);vec3 rd=normalize(world.xyz/world.w-uCamera);
    float h=pow(max(rd.y,0.),.45),sunDot=max(dot(rd,uSun),0.);
    vec3 horizon=mix(vec3(.017,.026,.056),vec3(.56,.66,.71),uDay),zenith=mix(vec3(.004,.009,.027),vec3(.105,.275,.47),uDay);
    vec3 color=mix(horizon,zenith,h);float sunset=(1.-smoothstep(.12,.62,uSun.y))*uDay;
    color+=vec3(.56,.24,.085)*pow(1.-abs(rd.y),5.)*pow(sunDot,5.)*sunset;
    color+=uSunColor*pow(sunDot,48.)*.20*uDay;
    float disc=smoothstep(.99980,.99993,sunDot);color+=uSunColor*disc*8.*uDay;
    if(uDay<.45&&rd.y>0.){vec2 uv=vec2(atan(rd.z,rd.x),asin(rd.y))*210.;float s=hash(floor(uv));float star=step(.9973,s)*pow(max(0.,1.-length(fract(uv)-.5)*2.),4.);color+=star*(1.-uDay)*1.3;float moon=dot(rd,normalize(vec3(-.5,.62,-.6)));color+=vec3(.49,.58,.76)*smoothstep(.99955,.9998,moon)*(1.-uDay);}
    if(rd.y>.035){
        vec2 q=uCamera.xz+rd.xz*((170.-uCamera.y)/rd.y);q=q*.0045+vec2(uTime*.0055,uTime*.0016);
        float clouds=fbm(q+fbm(q*.45)*.7),density=smoothstep(.51-uRain*.13,.76-uRain*.04,clouds);
        float lower=fbm(q+uSun.xz*.16);vec3 cc=mix(vec3(.15,.20,.28),mix(vec3(.83,.87,.86),vec3(1.12,1.02,.83),sunset*.6),uDay);
        cc*=.76+clamp((clouds-lower)*2.4+.2,0.,1.);cc=mix(cc,vec3(.26,.30,.34),uRain*.65);
        color=mix(color,cc,density*smoothstep(.035,.14,rd.y)*.94);
    }
    color=mix(color,vec3(.28,.34,.39)*mix(.12,1.,uDay),uRain*.35);
    if(rd.y<0.)color=mix(color,horizon,clamp(-rd.y*3.,0.,1.));
    fragColor=vec4(color,1.);
}
