#version 300 es
precision highp float;
in vec2 vUV;
uniform sampler2D uScene;
uniform sampler2D uDepth;
uniform sampler2D uBloom;
uniform mat4 uInvProjection;
uniform vec2 uResolution;
uniform float uExposure;
uniform float uBloomStrength;
uniform float uTime;
uniform int uAO;
uniform int uUnderwater;
out vec4 fragColor;
vec3 pos(vec2 uv){float d=texture(uDepth,uv).r;vec4 p=uInvProjection*vec4(uv*2.-1.,d*2.-1.,1.);return p.xyz/p.w;}
float occlusion(){
    if(uAO==0||texture(uDepth,vUV).r>.99998)return 1.;vec3 p=pos(vUV),n=normalize(cross(dFdx(p),dFdy(p)));if(n.z<0.)n=-n;
    float radius=clamp(1.6/max(-p.z,1.),.0015,.055),occ=0.;int samples=uAO==2?12:6;
    for(int i=0;i<12;i++){if(i>=samples)break;float angle=float(i)*2.39996323;vec2 off=vec2(cos(angle),sin(angle))*radius*(.28+.72*float(i+1)/float(samples));vec2 uv=clamp(vUV+off,vec2(.001),vec2(.999));vec3 q=pos(uv),delta=q-p;float dist=length(delta);occ+=smoothstep(.02,.25,dot(n,normalize(delta)))* (1.-smoothstep(.2,2.4,dist));}
    return clamp(1.-occ/float(samples)*.56,.57,1.);
}
vec3 tonemap(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){
    vec2 uv=vUV;if(uUnderwater==1)uv+=vec2(sin(vUV.y*32.+uTime),cos(vUV.x*28.+uTime*.9))*.0018;
    vec3 c=texture(uScene,uv).rgb;
    // Kleine kantengesteuerte Nachfilterung ohne temporales Ghosting.
    vec2 px=1./uResolution;vec3 a=texture(uScene,uv+vec2(px.x,0)).rgb,b=texture(uScene,uv-vec2(px.x,0)).rgb,d=texture(uScene,uv+vec2(0,px.y)).rgb,e=texture(uScene,uv-vec2(0,px.y)).rgb;
    vec3 l=vec3(.2126,.7152,.0722);float mn=min(dot(c,l),min(min(dot(a,l),dot(b,l)),min(dot(d,l),dot(e,l)))),mx=max(dot(c,l),max(max(dot(a,l),dot(b,l)),max(dot(d,l),dot(e,l))));
    float edge=smoothstep(.16,.50,mx-mn);c=mix(c,(c*4.+a+b+d+e)/8.,edge*.52);
    c*=occlusion();c+=texture(uBloom,vUV).rgb*uBloomStrength;
    if(uUnderwater==1)c=mix(c*vec3(.60,.90,.95),vec3(.015,.085,.10),.25);
    c=tonemap(c*uExposure);c=pow(c,vec3(1./2.2));
    float vig=1.-.15*pow(length((vUV-.5)*vec2(1.05,1.)),2.);c*=vig;
    fragColor=vec4(c,1.);
}
