#version 300 es
precision highp float;
in vec4 vColor;
uniform int uRainMode;
out vec4 fragColor;
void main(){vec2 p=gl_PointCoord-.5;float alpha=uRainMode==1?(1.-smoothstep(.025,.095,abs(p.x)))*(1.-abs(p.y)*1.8):1.-smoothstep(.30,.50,length(p));if(alpha<.02)discard;fragColor=vec4(vColor.rgb,vColor.a*alpha);}
