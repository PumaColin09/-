import {meshChunk} from './mesher.js';
self.onmessage=event=>{
    const {id,cx,cz,buffer,version}=event.data;
    try{const mesh=meshChunk(new Uint8Array(buffer),cx,cz);self.postMessage({id,cx,cz,version,...mesh},[mesh.solid.buffer,mesh.water.buffer,mesh.glass.buffer]);}
    catch(error){self.postMessage({id,error:String(error)});}
};
