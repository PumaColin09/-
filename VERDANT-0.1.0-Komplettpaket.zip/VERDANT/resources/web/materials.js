// Alle Materialien und Texturen werden im Programm erzeugt. Keine Minecraft-Assets.
export const BLOCKS=[
['Luft','Natur','#ffffff',0],['Wiesenboden','Natur','#749650',.5],['Erde','Natur','#796048',.45],['Granit','Gestein','#888d88',1.1],
['Flusssand','Natur','#c2b799',.4],['Wasser','Natur','#3e7d8b',0],['Eichenstamm','Holz','#78604a',.85],['Eichenlaub','Natur','#527442',.2],
['Fichtenstamm','Holz','#625244',.85],['Fichtennadeln','Natur','#345a45',.2],['Schnee','Natur','#e1e9e5',.3],['Basalt','Gestein','#414747',1.4],
['Eichenbretter','Bauen','#b2956e',.65],['Ziegel','Bauen','#a1725d',1],['Glas','Bauen','#a8d5d7',.4],['Lichtstein','Licht','#c8dcaa',1.2],
['Kupfererz','Erze','#a36f4d',1.4],['Bergkristall','Erze','#a4cbd2',1.8],['Moosstein','Gestein','#657659',1.1],['Marmor','Bauen','#d3d2c9',1.2],
['Lehm','Natur','#aa9281',.55],['Bruchstein','Bauen','#8a8c84',1.05],['Dunkles Holz','Holz','#4c4038',.8],['Kalkstein','Bauen','#c7bc9f',1],
['Wiesenblume','Natur','#d6bf88',.1],['Farn','Natur','#6f954a',.1],['Grundgestein','Gestein','#333735',999],['Laterne','Licht','#ecc887',.45],
['Golderz','Erze','#b9a05c',1.6],['Gletschereis','Natur','#b6d4d8',.6]
].map((a,id)=>({id,name:a[0],category:a[1],color:a[2],hardness:a[3]}));
export const PALETTE=BLOCKS.filter(b=>![0,5,26].includes(b.id));
export const solid=id=>id!==0&&id!==5&&id!==24&&id!==25;
export const opaque=id=>solid(id)&&id!==14&&id!==29;
export const tint=id=>{let s=(BLOCKS[id]?.color||'#ffffff').slice(1);return [parseInt(s.slice(0,2),16),parseInt(s.slice(2,4),16),parseInt(s.slice(4,6),16)]};
const hash=(x,y,s=0)=>{let h=Math.imul(x+37,374761393)^Math.imul(y+11,668265263)^Math.imul(s+1,2147483647);h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967295};
const smooth=t=>t*t*(3-2*t);
function noise(x,y,s=0){const X=Math.floor(x),Y=Math.floor(y),u=smooth(x-X),v=smooth(y-Y);return (hash(X,Y,s)*(1-u)+hash(X+1,Y,s)*u)*(1-v)+(hash(X,Y+1,s)*(1-u)+hash(X+1,Y+1,s)*u)*v}
export function makeMaterials(gl){
    const N=64,LAYERS=32,data=new Uint8Array(N*N*4*LAYERS),heights=new Float32Array(N*N*LAYERS),icons=[];
    for(let id=0;id<LAYERS;id++){
        const base=id===30?[161,136,97]:id===31?[104,139,59]:tint(Math.min(id,29));
        const img=new ImageData(N,N);
        for(let y=0;y<N;y++)for(let x=0;x<N;x++){
            const p=(y*N+x)*4,idx=(id*N*N+y*N+x)*4,u=x/N,v=y/N;
            const grain=hash(x,y,id),n=noise(x/6,y/6,id),large=noise(x/19,y/19,id);
            let a=255,c=base.slice(),f=.83+.22*n+.09*grain,h=n;
            if([2,4,10,20].includes(id)){f=.85+.2*n+.12*grain;h=n*.3+grain*.7;}
            if([3,11,18,21,23,26].includes(id)){
                const crack=Math.abs(noise(x/12,y/12,id+7)-.5);f=.7+.4*large+.14*grain;
                if(crack<.025)f*=.76;if(id===21){let row=Math.floor(y/18),xx=(x+(row%2)*13)%29;if(xx<2||y%18<2)f*=.64;}
                if(id===18&&large>.55)c=[84,108,62];h=large*.7+n*.3;
            }
            if(id===1){c=v<.18+noise(x/8,0,17)*.11?[94,125,60]:[108,82,57];f=.8+.26*n+.13*grain;}
            if(id===31){const line=Math.sin(x*.5+y*.27);f=.78+.25*n+.17*grain+.045*line;h=grain*.4+n*.6;}
            if([6,8,22].includes(id)){const line=noise(x/3,y/25,id);f=.55+.61*line+.13*grain;h=line;}
            if(id===12){const edge=y%16<1;const wood=noise(x/22,y/2,id);f=.77+.24*wood+.08*grain;if(edge||((x+(Math.floor(y/16)%2)*24)%64<1))f*=.61;h=edge?.15:wood;}
            if(id===13){const r=Math.floor(y/16),xx=(x+(r%2)*16)%32,grout=xx<2||y%16<2;if(grout){c=[161,151,135];f=.88;}else f=.79+.19*n+.16*hash(Math.floor((x+(r%2)*16)/32),r,13);h=grout?.05:n*.2+.7;}
            if(id===19){const veins=Math.sin((u+v*.7+noise(x/15,y/15,3)*.5)*19);f=.90+.08*n;if(veins>.91)f*=.75;h=n*.1;}
            if(id===7||id===9){
                const cells=noise(x/4,y/5,id),vein=noise(x/2,y/14,31);f=.61+.49*cells+.18*grain;
                a=(cells>.33||vein>.55)?255:0;h=cells;
            }
            if(id===30){const r=Math.hypot(u-.5,v-.5),rings=Math.sin(r*75+noise(x/8,y/8,30)*4);f=.82+.14*rings+.08*grain;h=rings*.1+.5;}
            if([16,17,28].includes(id)){c=[113,118,112];f=.73+.35*n+.1*grain;if(noise(x/5,y/5,18+id)>.61){c=tint(id);f=.88+.36*grain;}h=n;}
            if(id===14||id===29){f=.95+.05*noise(x/17,y/17,id);h=noise(x/7,y/7,44)*.1;}
            if(id===15){f=.8+.6*noise(x/9,y/9,id);h=n*.3;}
            if(id===27){const frame=x<6||x>57||y<5||y>58||x%21<3;if(frame){c=[57,62,54];f=.8;}else{c=[255,211,139];f=1.05+.3*n;}h=frame?.8:.4;}
            if(id===24||id===25){
                a=0;c=id===25?[94,140,60]:[86,123,55];f=.75+.32*n;
                const stem=Math.abs(u-.5)<.022&&v>.24;if(stem)a=255;
                if(id===25){for(let k=0;k<7;k++){let yy=.19+k*.1,wide=.33*(1-yy*.7);if(Math.abs(v-yy-Math.abs(u-.5)*.40)<.035&&Math.abs(u-.5)<wide)a=255;}}
                else{let dx=u-.5,dy=v-.23,rr=Math.hypot(dx,dy),ang=Math.atan2(dy,dx);if(rr<.105+.037*Math.sin(ang*5)){a=255;c=rr<.048?[230,185,75]:[228,214,184];}if(Math.abs(v-.65+(u-.5)*.8)<.05&&u>.28&&u<.52)a=255;}
                h=.5;
            }
            for(let k=0;k<3;k++)data[idx+k]=img.data[p+k]=Math.min(255,Math.max(0,Math.round(c[k]*f)));
            data[idx+3]=img.data[p+3]=a;heights[id*N*N+y*N+x]=h;
        }
        let canvas=document.createElement('canvas');canvas.width=canvas.height=N;canvas.getContext('2d').putImageData(img,0,0);icons.push(canvas);
    }
    const normal=new Uint8Array(data.length);
    for(let id=0;id<LAYERS;id++)for(let y=0;y<N;y++)for(let x=0;x<N;x++){
        const at=(xx,yy)=>heights[id*N*N+((yy+N)%N)*N+(xx+N)%N];let dx=(at(x+1,y)-at(x-1,y))*.65,dy=(at(x,y+1)-at(x,y-1))*.65,d=Math.hypot(dx,dy,1),i=(id*N*N+y*N+x)*4;
        normal[i]=(-dx/d*.5+.5)*255;normal[i+1]=(-dy/d*.5+.5)*255;normal[i+2]=(1/d*.5+.5)*255;
        normal[i+3]=[14,29,17,28].includes(id)?80:id===19?112:210;
    }
    function upload(bytes,srgb){const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D_ARRAY,t);gl.texImage3D(gl.TEXTURE_2D_ARRAY,0,srgb?gl.SRGB8_ALPHA8:gl.RGBA8,N,N,LAYERS,0,gl.RGBA,gl.UNSIGNED_BYTE,bytes);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_S,gl.REPEAT);gl.texParameteri(gl.TEXTURE_2D_ARRAY,gl.TEXTURE_WRAP_T,gl.REPEAT);gl.generateMipmap(gl.TEXTURE_2D_ARRAY);let ext=gl.getExtension('EXT_texture_filter_anisotropic');if(ext)gl.texParameterf(gl.TEXTURE_2D_ARRAY,ext.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(8,gl.getParameter(ext.MAX_TEXTURE_MAX_ANISOTROPY_EXT)));return t;}
    const iconURLs=BLOCKS.map((b,id)=>cubeIcon(icons,id));
    return {albedo:upload(data,true),normal:upload(normal,false),icons:iconURLs};
}
function cubeIcon(textures,id){
    const c=document.createElement('canvas');c.width=c.height=80;const g=c.getContext('2d');g.imageSmoothingEnabled=false;
    if(id===24||id===25){g.drawImage(textures[id],10,8,60,60);return c.toDataURL();}
    const faces=[{points:[[40,8],[70,24],[40,40],[10,24]],t:id===1?31:id===6||id===8?30:id,shade:0},
      {points:[[10,24],[40,40],[40,73],[10,56]],t:id,shade:.13}, {points:[[40,40],[70,24],[70,56],[40,73]],t:id,shade:.28}];
    for(const f of faces){g.save();g.beginPath();f.points.forEach((p,i)=>i?g.lineTo(...p):g.moveTo(...p));g.closePath();g.clip();const p=f.points;
        g.transform((p[1][0]-p[0][0])/64,(p[1][1]-p[0][1])/64,(p[3][0]-p[0][0])/64,(p[3][1]-p[0][1])/64,p[0][0],p[0][1]);g.drawImage(textures[f.t],0,0);g.fillStyle=`rgba(0,0,0,${f.shade})`;g.fillRect(0,0,64,64);g.restore();}
    return c.toDataURL();
}
