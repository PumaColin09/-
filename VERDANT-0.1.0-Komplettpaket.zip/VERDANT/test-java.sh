#!/usr/bin/env sh
set -eu
cd "$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p build/test-classes
javac --release 17 -encoding UTF-8 -d build/test-classes src/verdant/*.java tests/VerdantTest.java
java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp build/test-classes verdant.VerdantTest
