#!/usr/bin/env sh
set -eu
cd "$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)"
command -v java >/dev/null 2>&1 || { printf '%s\n' 'Java 17 oder neuer erforderlich: java wurde nicht gefunden.' >&2; exit 1; }
if [ ! -f VERDANT.jar ]; then
    printf '%s\n' 'VERDANT.jar fehlt. Zuerst ./build.sh ausführen.' >&2
    exit 1
fi
exec java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -jar VERDANT.jar "$@"
