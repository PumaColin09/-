#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
exec java -Xmx256m -jar RandomMazeAI.jar
