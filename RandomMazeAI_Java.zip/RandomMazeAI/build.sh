#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
mkdir -p out
javac --release 17 -encoding UTF-8 -Xlint:all -d out src/*.java tests/*.java
java -cp out CoreTest
java -cp out StorageTest
java -cp out EngineTest
# Bundle production classes only, without the test runners.
mkdir -p build-classes
javac --release 17 -encoding UTF-8 -d build-classes src/*.java
jar --create --file RandomMazeAI.jar --main-class MazeApp -C build-classes .
echo "Build und Tests erfolgreich. Starte mit: java -jar RandomMazeAI.jar"
