@echo off
cd /d "%~dp0"
java -Xmx256m -jar RandomMazeAI.jar
if errorlevel 1 (
  echo.
  echo Bitte pruefe, ob Java 17 oder neuer installiert ist.
  echo Anleitung: README.md
  pause
)
