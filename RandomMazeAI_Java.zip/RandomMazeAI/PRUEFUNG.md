# Geprüfter Stand – 13. Oktober 2026

Java 17, Kompilierung mit `--release 17` und `-Xlint:all`, keine Compilerwarnungen. `build.sh` kompiliert, führt die drei Tests aus und erzeugt die startfähige JAR erfolgreich.

| Prüfung | Ergebnis |
|---|---|
| CoreTest | 48.739 Prüfungen erfolgreich: Zusammenhang, Wandkonsistenz, Grenzen, gleiche Seeds, Q-Update, terminales Ziel, zehn gelernte 8×8-Karten |
| StorageTest | Exakte Wiederaufnahme inklusive Zufallszustand; Ersetzen, beschädigte, gekürzte, leere und zu große Dateien geprüft |
| EngineTest | Pause, Einzelschritt, Neustart pro Karte, automatische Kartenwechsel, Laden und konkurrierende Bedienung erfolgreich |
| JAR-Benchmark 12×12, Seed 2026 | Route mit 62 Schritten gelernt, stimmt mit unabhängigem Vergleichsweg überein |
| JAR-Benchmarks 30×30, Seeds 0–9 und 42 | Alle elf Karten innerhalb von 6.000 Episoden gelernt; Routen entsprechen dem Vergleichsweg |
| Oberfläche | Echter Swing-Komponentenbaum als PNG gerendert und auf Darstellung geprüft |
| Unabhängige Quellcodeprüfung | Keine wesentlichen Fehler gefunden |

Die Tests liefen auf dem Entwicklungsrechner unter Linux. Das ist **keine Messung auf eurem i5-6500** und kein nativer Windows-/macOS-Test. Der grafische Komponentenbaum wurde gerendert; ein interaktiver Fenstertest war wegen der nicht erreichbaren X11-Anzeige dieser Umgebung nicht möglich. Zeitangaben des CLI-Benchmarks lassen sich nicht als Leistungsversprechen für andere PCs verwenden.
