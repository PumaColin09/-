# Geprüfter Stand – Version 2, 13. Oktober 2026

Java 17, `--release 17`, `-Xlint:all`. Das Buildskript kompiliert und führt alle fünf Testprogramme aus.

| Test | Ergebnis |
|---|---|
| CoreTest | 52.121 Prüfungen: zusammenhängende Karten, Wände, reproduzierbare Zufallspositionen und begrenzte Sensoreingaben |
| DqnTest | Backprop lernt einen Zielwert; korrekte Adam-Momentabnahme bei nicht gewählten Outputs; Target-Kopie; Modell und Replay überleben Kartenwechsel; Tests verändern keine Gewichte |
| StorageTest | Netz, Adam, Target, Replay und Episode werden gespeichert und setzen das Lernen exakt fort; Prüfsumme, verkürzte, leere und übergroße Dateien werden abgelehnt |
| EngineTest | Pause, Einzelschritt, Endlosmodus, gemeinsame Zähler, eingefrorene Testläufe, Laden, Zugriffssynchronisierung und identische Folge der nächsten Zufallskarten nach Wiederaufnahme |
| TrainingTest | Echte Verbesserung auf 24 unbekannten Karten nach Training über mehr als 100 Trainingskarten; keine Test-Erfahrungen im Replay |
| Oberfläche | Tatsächliche Swing-Komponenten als PNG gerendert und auf Darstellung geprüft; Entscheidungspanel und Kurve bleiben sichtbar |
| Quellcodeprüfung | Adam-Update und zukünftiger Karten-Zufallszustand kontrolliert; beide gefundenen Probleme mit fehlgeschlagenen Regressionstests nachgewiesen und korrigiert |

## Reproduzierbare gemessene Lernkurve

Initialisierung 123, Trainingskartenfolge 891, 6×6-Trainingskarten, fünf Versuche pro Karte. Tests ohne Exploration auf separaten 4×4-, 6×6- und 8×8-Karten. Der Vergleich betrifft dieselbe unbekannte Testauswahl zu jedem Zeitpunkt.

| Lernschritte | Trainingskarten | Erfolgreiche Tests | Test-Erfolgsrate |
|---:|---:|---:|---:|
| 0 | 1 | 0 / 24 | 0 % |
| 10.000 | 13 | 13 / 24 | 54,2 % |
| 20.000 | 30 | 20 / 24 | 83,3 % |
| 30.000 | 48 | 17 / 24 | 70,8 % |
| 40.000 | 66 | 19 / 24 | 79,2 % |
| 50.000 | 85 | 19 / 24 | 79,2 % |
| 60.000 | 102 | 21 / 24 | 87,5 % |

Das sind tatsächlich gemessene Werte des gelieferten Algorithmus, keine Garantie für jede Zufallsfolge. Man sieht auch den Rückschritt bei 30.000 Schritten. Das Modell behält seine Erfahrungen, aber neuronales Training und verschiedene Karten ergeben keinen streng monotonen Fortschritt.

Die Prüfungen liefen unter Linux. Kein Hardwarebenchmark auf eurem i5-6500 und kein nativer Windows-/macOS-Test. Ein interaktiver Fenstertest ist in dieser Umgebung wegen der nicht erreichbaren X11-Anzeige nicht möglich; die Swing-Darstellung wurde gerendert. Reproduzieren mit `java -jar RandomMazeAI.jar --benchmark 60000 891`.
