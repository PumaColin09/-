@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac --release 17 -encoding UTF-8 -Xlint:all -d out src\*.java tests\*.java
if errorlevel 1 goto fail
java -cp out CoreTest
if errorlevel 1 goto fail
java -cp out StorageTest
if errorlevel 1 goto fail
java -cp out EngineTest
if errorlevel 1 goto fail
if not exist build-classes mkdir build-classes
javac --release 17 -encoding UTF-8 -d build-classes src\*.java
if errorlevel 1 goto fail
jar --create --file RandomMazeAI.jar --main-class MazeApp -C build-classes .
if errorlevel 1 goto fail
echo Build und Tests erfolgreich.
pause
exit /b 0
:fail
echo Build fehlgeschlagen. Zum Kompilieren wird ein JDK ab Java 17 benoetigt.
pause
exit /b 1
