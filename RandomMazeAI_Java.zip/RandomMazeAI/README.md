# Maze / Lab 2 – Deep Q Learning

Diese Version lernt **mit demselben neuronalen Modell über viele verschiedene Labyrinthe hinweg**. Kartenwechsel löscht weder die Gewichte noch die Erfahrungen. Start und Ziel liegen pro Karte an zufälligen, unterschiedlichen Positionen.

## Start

ZIP entpacken, **Java 17 oder neuer mit Desktop-Unterstützung** installieren, unter Windows `Start-Windows.bat` doppelklicken. macOS: `bash Start-Mac.command`, Linux: `bash Start-Linux.sh`. Die fertige JAR braucht kein JDK; zum Bearbeiten/Kompilieren ist ein JDK notwendig.

```sh
java -Xmx256m -jar RandomMazeAI.jar
```

Offline, keine GPU, keine zusätzlichen Java-Bibliotheken. Desktop-App für euren PC/Mac; nicht direkt auf dem iPhone ausführbar. Standardgröße: 8×8; vier Geschwindigkeiten. Für sichtbare Einzelschritte „Beobachten“ wählen.

## Jetzt ist sichtbar, was er lernt

**Oberhalb der Karte:** Letzte Richtung, Zufallsaktion oder Netzentscheidung, Ergebnis und erhaltene Belohnung. Für die nächste Aktion stehen vier gelernte Nutzwerte neben dem, was der Agent dort wahrnimmt: Wand, Ziel, unbesuchtes oder bekanntes Feld. Die Nutzwerte sind keine Wahrscheinlichkeiten. Die Balken zeigen ihren Betrag; das Vorzeichen steht in der Zahl. Grün markiert den größten Nutzwert.

**Auf der Karte:** Agent, zufälliger Start S, zufälliges Ziel Z und die Besuche der aktuellen Episode. Die Besuchsdichte zeigt Erkundung, nicht direkt die Intelligenz des Modells.

**Unter der Karte:** Eine echte Lernkurve aus getrennten Tests auf 24 unbekannten Karten (je acht 4×4, 6×6 und 8×8). Das Modell wird für jeden Test eingefroren und handelt ohne Exploration. Tests verändern keine Gewichte und landen nicht im Replay-Speicher. Die gestrichelte Linie ist seine gemessene Anfangsleistung. Ergebnisse können steigen oder sinken; es wird keine künstlich ansteigende Kurve gezeichnet.

**Rechts:** Globale Episoden und Trainingskarten, letzte Test-Erfolgsrate, Änderung gegenüber dem untrainierten Modell, aktuelle Erkundung und neuronale Updates. Alle diese globalen Fortschrittswerte bleiben beim Kartenwechsel erhalten. Weitere Details zu Replay, Lernfehler und Trainingserfolgen stehen weiter unten in der scrollbaren Bedienleiste.

Die Test-Erfolgsrate gehört zum letzten vollständig gemessenen Modellstand; die X-Achse der Kurve zeigt dessen Lernschritte. Während des Trainings kommen automatisch Tests hinzu, frühestens etwa alle 10.000 Lernschritte. „Fortschritt jetzt testen“ misst den aktuellen Stand zusätzlich. Ein angeforderter Test arbeitet auch bei pausiertem Training weiter, ohne das Modell zu verändern.

## Bedienung

| Funktion | Verhalten |
|---|---|
| Training starten / pausieren | Steuert Lernen und Vorführung; auch mit Leertaste. |
| Einzelschritt | Eine Aktion inklusive Erfahrung und gegebenenfalls regulärem Lernupdate. |
| Neues Labyrinth | Neue Karte mit gewählter Größe, andere Start-/Zielpositionen; **Modell, Replay und Fortschritt bleiben erhalten**. |
| Endlosmodus | Nach fünf Versuchen entsteht automatisch die nächste Karte, auch bei Fehlschlägen. Dadurch lernt das Netz über unterschiedliche Karten. |
| Route vorführen | Testet das aktuelle Modell auf der aktuellen Karte; eine gefundene Route wird gezeigt, anschließend pausiert die App. |
| Speichern / Laden | Speichert/lädt Netz, Optimizer, Replay, Statistik, Kurve und aktuelle Karte; pausiert das Training. |
| Größe | 4–30 Zellen je Seite, angewendet mit „Neues Labyrinth“. |

Bei gelegentlichen erfolgreichen Karten kann der Endlosmodus eine tatsächlich vom Modell gefundene Route kurz zeigen. Anfangs ist es normal, dass der Agent gegen Wände läuft oder ein Ziel verfehlt. Der langsame Modus zeigt den Prozess gut, benötigt für Tausende Erfahrungen aber entsprechend lange. „Schnell“ und „Turbo“ trainieren beschleunigt und bleiben durch ein CPU-Zeitbudget begrenzt.

## Technischer Aufbau

- **Double DQN**, in reinem Java implementiert.
- Netz: **48 Eingaben → 32 → 24 → 4 Ausgaben**, zwei ReLU-Schichten, 2.460 trainierbare Parameter.
- Online-Netz, separates Target-Netz, fester Experience-Replay-Ring mit 4.096 Erfahrungen.
- Adam und Huber-Verlust; Minibatch 8, ein Lernbatch je vier Aktionen nach 128 gesammelten Erfahrungen. Target-Netz wird alle 250 Batches kopiert.
- Diskontfaktor 0,94. Exploration sinkt von 90 % über 150.000 Aktionen auf mindestens 8 %; auch diese Zählung läuft über alle Karten hinweg.
- Beobachtung: lokale Wände, Zielrichtung, Besuche benachbarter Felder, letzte Aktion und Episodenerinnerung. Er sieht keinen fertigen Lösungsweg und bekommt keinen BFS-Abstand.
- Reward: Ziel **+5**, neues Feld **+0,15**, bekanntes Feld **−0,05**, Wand **−0,7**.
- Die Belohnung neuer Felder unterstützt allgemein nutzbares Erkunden. Das Netz lernt eine Erkundungsstrategie; es ist kein perfekter Planer und garantiert nicht jede unbekannte Karte zu lösen.
- Pro Episode maximal `Zellzahl × 6` Aktionen. Zeitlimit wird als Trunkierung behandelt; nur das erreichte Ziel ist beim DQN-Target terminal.
- Training verwendet Seeds im 32-Bit-Bereich. Die Testkarten liegen in einem getrennten Seed-Bereich und werden ausschließlich gemessen. Die feste Sammlung dient zur Fortschrittsanzeige, nicht als Garantie für alle Karten oder für 30×30-Karten.

Ein unabhängiger BFS berechnet ausschließlich den kürzesten Vergleichsweg für die Testkennzahl **Wegaufwand**. Die tatsächlichen Testschritte werden durch diese Weglänge geteilt; bei erfolglosen Versuchen zählt das komplette Schrittbudget. Kleiner ist besser. Wandtreffer pro 100 Schritte sind ebenfalls besser, wenn sie sinken. Der Besuchsgrad wird am Erfolg beendet; eine effizient gelöste Karte kann daher weniger besuchte Felder haben.

Originale DQN-Arbeit: Mnih et al., Nature (2015), https://www.nature.com/articles/nature14236
Double DQN: van Hasselt et al. (2015), https://arxiv.org/abs/1509.06461

## CPU / i5-6500

Ein einzelner Worker trainiert, die Swing-Oberfläche läuft getrennt. Pro Block sind ungefähr 3 ms Rechenzeit erlaubt, danach wartet der Worker 20 ms. Einzelne Aktionen/Updates können das Budget etwas überschreiten. Keine neuronalen Frameworks und keine GPU nötig. Replay braucht ungefähr 1,7 MiB plus Java-Verwaltungsdaten; die gesamte JVM/Oberfläche braucht zusätzlichen Speicher. Startskripte setzen maximal 256 MiB Java-Heap, nicht maximal 256 MiB Prozessspeicher.

Der Code ist für CPU-Betrieb auf eurem i5-6500 ausgelegt, wurde aber **nicht auf eurem konkreten PC gemessen**. Größere Karten benötigen längere Episoden; 6×6 oder 8×8 ist ein guter Start zum Beobachten der Lernkurve. Das Modell wird beim ersten Start zufällig initialisiert, nicht mit vorgetäuschter Leistung vortrainiert.

## Speichern und alte Lernstände

V2 speichert Netzgewichte, Adam-Zustand, Target-Netz, Replay-Ring, Zufallszustände des Agenten und der folgenden Karten, aktuelle Episode, globale Zähler und gemessene Kurve. Datenformat mit Versionsnummer, CRC und Eingabegrenzen; vollständiger Austausch über temporäre Datei, atomar sofern das Dateisystem es unterstützt.

**V1-Speicherstände enthalten nur eine Q-Tabelle für eine einzelne Karte.** Sie lassen sich nicht sinnvoll in neuronale Gewichte umwandeln und werden mit einer erklärenden Meldung abgelehnt. Starte für V2 ein neues Training. Oberflächeneinstellungen werden nicht gespeichert. Ein gerade laufender Test wird beim Laden verworfen; bereits abgeschlossene Messungen bleiben erhalten.

## Selbst prüfen / Quellcode ändern

`src/` enthält den vollständigen Java-Quellcode. Windows: `Build-Windows.bat`; macOS/Linux: `bash build.sh`. Die Builds führen alle fünf Testprogramme aus und erzeugen anschließend die JAR.

```sh
java -jar RandomMazeAI.jar --benchmark 30000 891
```

Argumente: Anzahl Lernschritte (1–1.000.000), Seed der Trainingskartenfolge. Dieser reproduzierbare Benchmark trainiert ein neues Modell über unterschiedliche 6×6-Karten und misst den Transfer auf die unbekannte Testsammlung. Er läuft ohne GUI-Drosselung. Die Ausgabe nennt Karten, Updates, Test-Erfolgsrate und Vergleich zum untrainierten Modell. Sie ist ein Testresultat, keine garantierte Verbesserung jeder weiteren Karte.

| Datei | Aufgabe |
|---|---|
| `Maze.java`, `Rng.java` | Labyrinth, Zufallspositionen, reproduzierbarer Zufall |
| `Network.java` | Neuronales Netz, Rückwärtsrechnung, Adam |
| `ReplayBuffer.java` | Begrenzter gemeinsamer Erfahrungsspeicher |
| `Episode.java`, `Learner.java` | Wahrnehmung, Belohnung und kartenübergreifendes Double DQN |
| `Evaluation.java`, `Progress.java` | Getrennte Testkarten und echte Lernkurve |
| `Engine.java` | Worker-Steuerung, Kartentausch, schrittweise Tests |
| `MazeApp.java`, `DecisionPanel.java`, `LearningPanel.java` | Desktop, sichtbare Entscheidungen, Kurve |
| `SessionStore.java` | Vollständige DQN-Speicherstände |
