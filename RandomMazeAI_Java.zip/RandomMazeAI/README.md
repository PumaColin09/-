# Maze / Lab – Random Maze AI

Eine offline nutzbare Java-App: Sie erzeugt fortlaufend zufällige Labyrinthe und lässt einen Q-Learning-Agenten den Ausgang finden lernen. Mit sichtbarem Training, Besuchsdichte, gelernter Route, vier Geschwindigkeiten und Speicherständen.

## Starten

Du brauchst **Java 17 oder neuer mit Desktop-Unterstützung**. Für die fertige JAR ist kein JDK notwendig; zum Bearbeiten/Kompilieren brauchst du ein JDK. Keine Python-Installation, keine Internetverbindung beim Betrieb, keine GPU, keine zusätzlichen Java-Bibliotheken.

1. ZIP entpacken.
2. Windows: `Start-Windows.bat` doppelklicken. macOS: `Start-Mac.command`; falls das Betriebssystem die Datei nicht öffnet, im Terminal im entpackten Ordner `bash Start-Mac.command` ausführen. Linux: `bash Start-Linux.sh`.
3. **Training starten** anklicken. Standard: 12 × 12 Zellen, schnell, Endlosmodus aktiv.

Alternativ auf allen Plattformen im entpackten Ordner:

```sh
java -Xmx256m -jar RandomMazeAI.jar
```

Die App ist eine Desktop-App und läuft nicht direkt auf dem iPhone. Lade das ZIP auf euren PC oder Mac und entpacke es dort.

## Bedienen

| Bedienung | Wirkung |
|---|---|
| Training starten / pausieren | Startet bzw. stoppt Lernen und Vorführung. Leertaste funktioniert ebenfalls. |
| Einzelschritt | Pausiert und führt genau eine lernende Aktion aus. |
| Beobachten | Etwa 50 Aktionen/s; Bewegung gut erkennbar. |
| Ruhig / Schnell / Turbo | Bis 120 / 1.500 / 10.000 Aktionen pro Trainingsblock. Die tatsächliche Rate hängt von der CPU ab. |
| Endlos neue Labyrinthe | Prüft alle 25 Episoden die gelernte Route. Wenn sie zum Ziel führt, wird sie etwa 3 Sekunden gezeigt; danach entsteht eine neue Karte. |
| Route vorführen | Führt die aktuelle gelernte Route vor und pausiert anschließend. |
| Größe / Neues Labyrinth | 4–30 Zellen je Seite. Neue Größe gilt nach Klick auf „Neues Labyrinth“. Die alte Q-Tabelle wird ersetzt. |
| Speichern / Laden | Speichert/öffnet eine `.mazeai`-Datei. Dabei pausiert das Training. Nach Laden mit „Training starten“ fortsetzen. |

Rechts ist die Bedienleiste scrollbar: Weiter unten stehen die Erklärung und die aktuellen Q-Werte. Helles Kreissymbol = Agent, S = Start, Z = Ziel. Grünere Zellen wurden häufiger besucht. Die grüne Linie ist die anhand der gelernten Q-Werte gefundene Route.

**Vor „Neues Labyrinth“ speichern, wenn du die bisherige Karte behalten willst.** Die Endlosfunktion hält nur die aktuelle Karte im Speicher. Die Zahl „Karten abgeschlossen“ zählt automatische Wechsel nach erfolgreich geprüfter Route; manuelle Vorführungen zählen nicht.

## Wie die KI lernt

- Zustand: die aktuelle Zelle. Aktionen: oben, rechts, unten, links.
- Ziel erreicht: **+20**. Gegen eine Wand: **−0,35**. Normaler Schritt: **−0,025**.
- Anfangs wählt der Agent in 95 % der Fälle eine zufällige Richtung; diese Exploration sinkt pro Episode und bleibt bei mindestens 8 %. Beim Prüfen/Vorführen gibt es keine Exploration.
- Ein Versuch beginnt immer beim Start. Er endet am Ziel oder nach `Zellzahl × 20` Aktionen. Ein Zeitlimit beendet nur den Versuch; beim Q-Update wird es nicht als terminales Ziel behandelt.
- Lernrate α = 0,25, Diskontfaktor γ = 0,995.

```text
Q(s,a) = Q(s,a) + α × [r + γ × max Q(s',a') − Q(s,a)]
```

Am Ziel entfällt der zukünftige Term. Die KI bekommt keinen fertigen Weg und keine Entfernung zum Ziel. Eine unabhängige Breitensuche dient im CLI-Benchmark ausschließlich zum Vergleich der Weglänge. Die Generierung erzeugt perfekte Labyrinthe: alle Zellen sind erreichbar und es gibt genau einen einfachen Weg zwischen zwei Zellen.

**Die KI lernt die aktuelle Karte.** Bei einer neuen Karte ändern sich die Wege, deshalb wird ihre Q-Tabelle neu angelegt. Das ist keine KI, die ihr Wissen auf neue Labyrinthe überträgt. Ein Speicherstand enthält Karte, Q-Werte, Zufallszustand, Position, Statistiken und Endloszähler; damit wird dieselbe Lernsitzung fortgesetzt. Darstellung, Geschwindigkeit und Endlos-Schalter sind Einstellungen der aktuellen App, keine Bestandteile der Speicherdatei.

„Endlos“ bedeutet fortlaufende Zufallsgenerierung ohne feste Kartenliste. Mathematisch sind die Möglichkeiten bei einer festen Größe endlich; Wiederholungen werden nicht ausgeschlossen.

Originalarbeit zum Q-Learning: Watkins & Dayan (1992), https://www.gatsby.ucl.ac.uk/~dayan/papers/wd92.html

## Für euren i5-6500

Die App ist bewusst klein: keine Netzgewichte, kein GPU-Training. Eine 30×30-Karte hat nur **3.600 Q-Werte**; die Q-Tabelle selbst benötigt 28.800 Byte. JVM und Oberfläche benötigen zusätzlich Speicher. Das mitgelieferte Startskript begrenzt den Java-Heap auf 256 MiB; das ist keine Obergrenze für den gesamten Prozess.

Ein einzelner Worker trainiert; die Oberfläche läuft getrennt auf dem Swing-Thread. Pro Block ist die Trainingszeit auf etwa 3 ms begrenzt, anschließend wartet der Worker 20 ms. Dadurch bleibt CPU-Zeit für andere Aufgaben frei. Die Prüfung des Zeitbudgets erfolgt alle 64 Schritte; auf langsamen Rechnern kann ein Block etwas länger dauern.

Die App wurde unter Java 17 auf Linux kompiliert und mit automatisierten Tests geprüft. **Es wurde kein Benchmark auf eurem i5-6500 durchgeführt.** Startet mit 12×12; große Karten brauchen je nach Seed mehr Versuche. Ein i5-6500 benötigt keine spezielle Erweiterung für dieses tabellarische Training.

## Quellcode ändern und testen

Alle Dateien liegen in `src/`; kein Maven/Gradle erforderlich.

Windows: `Build-Windows.bat`. macOS/Linux: `bash build.sh`. Danach startet die neue JAR wie oben.

Die Builds kompilieren mit `--release 17`, führen alle Tests aus und erstellen anschließend `RandomMazeAI.jar`. Die Dateien `CoreTest`, `StorageTest` und `EngineTest` benötigen kein Testframework.

Kommandozeilentest ohne Oberfläche:

```sh
java -jar RandomMazeAI.jar --benchmark
java -jar RandomMazeAI.jar --benchmark 20 6000 42
```

Argumente: Größe, maximale Episoden, Seed. Ausgabe: Episoden, Aktionen, Zeit, Lernerfolg, gelernte Weglänge und Vergleichsweg. Dieser Benchmark läuft ungedrosselt und misst **nicht** die GUI-Geschwindigkeit. Rückgabecode 0 = Route gelernt; 1 = Budget ohne Route beendet; 2 = ungültige Argumente.

## Dateien

| Datei | Verantwortung |
|---|---|
| `src/MazeApp.java` | Desktop-Oberfläche, Kartenzeichnung, CLI |
| `src/Engine.java` | Training, Pause, Endlosmodus und Zugriffssynchronisierung |
| `src/Maze.java` | Zufallsgenerierung, Wände und Kartenvalidierung |
| `src/Learner.java` | Q-Learning, Exploration, Erfolgsstatistik und gelernte Route |
| `src/SessionStore.java` | Versioniertes Speicherformat, Prüfsumme, Austausch über temporäre Datei |
| `src/Rng.java` | Reproduzierbarer Zufallsgenerator mit speicherbarem Zustand |

Speicherdateien werden nur nach erfolgreich geprüfter CRC und Struktur übernommen. Wenn das Dateisystem atomaren Dateiaustausch unterstützt, wird dieser genutzt; ansonsten erfolgt ein normaler Austausch nach vollständigem Schreiben der temporären Datei.
