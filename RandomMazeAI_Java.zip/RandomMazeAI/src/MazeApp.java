import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.file.*;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.concurrent.*;
import javax.imageio.ImageIO;

/** Offline Java desktop entry point. GUI and learner share no rendering dependency. */
public final class MazeApp {
    static final Color BG=new Color(11,17,28),CARD=new Color(19,29,44),
        TEXT=new Color(228,238,248),MUTED=new Color(139,159,181),
        ACCENT=new Color(64,222,191),GOLD=new Color(255,192,91),LINE=new Color(44,62,83);
    private final Engine engine;
    private final Board board=new Board();
    private final JPanel root=new JPanel(new BorderLayout(20,14));
    private final JLabel episodeValue=value(),rateValue=value(),pathValue=value(),
        mapsValue=value(),qText=new JLabel(),stateText=new JLabel(),status=new JLabel("Bereit. Starte das Training.");
    private final JButton play=button("Training starten",true);
    private final JSpinner size=new JSpinner(new SpinnerNumberModel(12,4,30,1));
    private final JComboBox<String> speed=new JComboBox<>(new String[]{"Beobachten · 50 Schritte/s","Ruhig · bis 6.000/s",
        "Schnell · bis 75.000/s","Turbo · bis 500.000/s"});
    private final JCheckBox endless=checkBox("Endlos neue Labyrinthe",true),heat=checkBox("Besuchsdichte anzeigen",true),
        route=checkBox("Gelernte Route anzeigen",true);
    private final javax.swing.Timer timer;
    private ScheduledExecutorService worker;
    private JFrame frame;
    private Path lastSave;
    private long savedSteps=-1,savedSeed,lastRateSteps,rateTime=System.nanoTime();
    private double stepsPerSecond;
    private String notice="";
    private long noticeUntil;

    MazeApp(Engine engine) {
        this.engine=engine;root.setBackground(BG);root.setBorder(new EmptyBorder(24,26,18,26));
        root.add(header(),BorderLayout.NORTH);
        board.setPreferredSize(new Dimension(650,650));root.add(board,BorderLayout.CENTER);
        JPanel side=sidebar();JScrollPane scroll=new JScrollPane(side);
        scroll.setBorder(null);scroll.setBackground(BG);scroll.getViewport().setBackground(BG);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(18);scroll.setPreferredSize(new Dimension(290,600));
        root.add(scroll,BorderLayout.EAST);
        status.setForeground(MUTED);status.setFont(font(12,Font.PLAIN));root.add(status,BorderLayout.SOUTH);
        play.addActionListener(e->engine.setRunning(!engine.isRunning()));
        speed.setSelectedIndex(2);speed.addActionListener(e->engine.setSpeed(speed.getSelectedIndex()));
        endless.addActionListener(e->engine.setEndless(endless.isSelected()));
        heat.addActionListener(e->board.heat=heat.isSelected());route.addActionListener(e->board.showRoute=route.isSelected());
        root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("SPACE"),"play");
        root.getActionMap().put("play",new AbstractAction() {
            public void actionPerformed(ActionEvent e) {engine.setRunning(!engine.isRunning());}
        });
        timer=new javax.swing.Timer(33,e->refresh());refresh();
    }
    private JPanel header() {
        JPanel panel=new JPanel(new BorderLayout());panel.setOpaque(false);
        JPanel title=new JPanel();title.setOpaque(false);title.setLayout(new BoxLayout(title,BoxLayout.Y_AXIS));
        JLabel top=new JLabel("MAZE / LAB");top.setFont(font(30,Font.BOLD));top.setForeground(TEXT);
        JLabel sub=new JLabel("Zufällige Welten. Ein Agent, der den Weg lernt.");sub.setFont(font(13,Font.PLAIN));sub.setForeground(MUTED);
        title.add(top);title.add(Box.createVerticalStrut(5));title.add(sub);panel.add(title,BorderLayout.WEST);
        JLabel badge=new JLabel("  LOCAL  /  CPU  /  JAVA  ");badge.setOpaque(true);badge.setBackground(CARD);
        badge.setForeground(ACCENT);badge.setFont(font(11,Font.BOLD));badge.setBorder(new EmptyBorder(8,10,8,10));
        JPanel right=new JPanel(new FlowLayout(FlowLayout.RIGHT,0,7));right.setOpaque(false);right.add(badge);
        panel.add(right,BorderLayout.EAST);return panel;
    }
    private JPanel sidebar() {
        JPanel side=new JPanel();side.setBackground(BG);side.setLayout(new BoxLayout(side,BoxLayout.Y_AXIS));
        stateText.setText("●  Pausiert · bereit zum Lernen");
        stateText.setFont(font(12,Font.BOLD));stateText.setForeground(ACCENT);add(side,stateText,12);
        add(side,label("TRAINING",11,MUTED),7);
        add(side,metric("Episoden · abgeschlossene Versuche",episodeValue),7);
        add(side,metric("Erfolgsrate · letzte 100 Versuche",rateValue),7);
        add(side,metric("Gelernte Route · Schritte bis zum Ziel",pathValue),7);
        add(side,metric("Karten im Endlosmodus abgeschlossen",mapsValue),15);
        add(side,play,7);
        JPanel secondary=new JPanel(new GridLayout(1,2,8,0));secondary.setOpaque(false);
        JButton step=button("Einzelschritt",false),demo=button("Route vorführen",false);
        step.addActionListener(e->engine.singleStep());demo.addActionListener(e->{
            if(!engine.showDemo()) message("Noch keine vollständige Route gelernt.");
        });secondary.add(step);secondary.add(demo);add(side,secondary,10);
        JPanel files=new JPanel(new GridLayout(1,2,8,0));files.setOpaque(false);
        JButton save=button("Speichern",false),load=button("Laden",false);
        save.addActionListener(e->save());load.addActionListener(e->load());files.add(save);files.add(load);add(side,files,17);
        add(side,label("GESCHWINDIGKEIT",11,MUTED),6);styleCombo(speed);add(side,speed,3);
        add(side,label("Obergrenzen; abhängig von CPU und Zeitbudget.",10,MUTED),12);
        add(side,endless,4);add(side,heat,4);add(side,route,16);
        add(side,label("GRÖSSE DER NÄCHSTEN KARTE",11,MUTED),7);
        JPanel mapControls=new JPanel(new BorderLayout(9,0));mapControls.setOpaque(false);
        size.setPreferredSize(new Dimension(68,34));size.setFont(font(14,Font.BOLD));
        JButton next=button("Neues Labyrinth",false);
        next.addActionListener(e->{engine.newMaze((Integer)size.getValue());message("Neue Karte. Q-Tabelle startet bei null.");});
        mapControls.add(size,BorderLayout.WEST);mapControls.add(next,BorderLayout.CENTER);add(side,mapControls,6);
        add(side,label("4–30 Zellen je Seite. Neue Karte = neues Lernen.",10,MUTED),16);
        add(side,label("SO LERNT DER AGENT",11,MUTED),7);
        JLabel learning=label("<html>Ziel: <b>+20</b> &nbsp; Wand: <b>−0,35</b><br>Schritt: <b>−0,025</b><br><br>Er probiert Richtungen aus und bewertet<br>sie mit Q-Werten. Exploration sinkt mit<br>jeder Episode von 95 % bis auf 8 %.<br><br>Wissen gilt für die aktuelle Karte.</html>",12,MUTED);
        add(side,learning,12);qText.setText("<html>Q an Agentposition<br>↑ 0 &nbsp; → 0 &nbsp; ↓ 0 &nbsp; ← 0</html>");
        qText.setFont(font(11,Font.PLAIN));qText.setForeground(MUTED);add(side,qText,8);
        return side;
    }
    static void add(JPanel parent,JComponent child,int gap) {
        child.setAlignmentX(Component.LEFT_ALIGNMENT);
        child.setMaximumSize(new Dimension(Integer.MAX_VALUE,child.getPreferredSize().height));
        parent.add(child);parent.add(Box.createVerticalStrut(gap));
    }
    static JLabel label(String text,int size,Color color) {
        JLabel l=new JLabel(text);l.setForeground(color);l.setFont(font(size,Font.PLAIN));return l;
    }
    static JLabel value() {JLabel l=label("—",21,TEXT);l.setFont(font(21,Font.BOLD));return l;}
    static Font font(int size,int style) {return new Font(Font.SANS_SERIF,style,size);}
    static JPanel metric(String title,JLabel value) {
        JPanel p=new JPanel(new BorderLayout(0,4));p.setBackground(CARD);p.setBorder(new EmptyBorder(8,13,8,13));
        p.add(label(title,10,MUTED),BorderLayout.NORTH);p.add(value,BorderLayout.CENTER);return p;
    }
    static JButton button(String title,boolean primary) {
        JButton b=new JButton(title);b.setBackground(primary ? ACCENT : CARD);b.setForeground(primary ? BG : TEXT);
        b.setFont(font(primary ? 14 : 11,Font.BOLD));b.setFocusPainted(false);b.setBorder(new EmptyBorder(11,8,11,8));
        b.setOpaque(true);b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));return b;
    }
    static JCheckBox checkBox(String text,boolean selected) {
        JCheckBox box=new JCheckBox(text,selected);box.setBackground(BG);box.setForeground(TEXT);
        box.setFont(font(12,Font.PLAIN));box.setFocusPainted(false);return box;
    }
    static void styleCombo(JComboBox<?> combo) {
        combo.setFont(font(11,Font.PLAIN));combo.setBackground(CARD);combo.setForeground(TEXT);
        combo.setPreferredSize(new Dimension(280,32));
    }
    private void refresh() {
        Engine.Snapshot s=engine.snapshot();board.snapshot=s;board.repaint();
        NumberFormat nf=NumberFormat.getIntegerInstance(Locale.GERMANY);
        episodeValue.setText(nf.format(s.episodes()));
        rateValue.setText(String.format(Locale.GERMANY,"%.0f %%",s.recentRate()*100));
        pathValue.setText(s.route().length>0 ? nf.format(s.route().length-1)+" Schritte" : "Noch offen");
        mapsValue.setText(nf.format(s.solvedMazes()));
        play.setText(s.running() ? "Training pausieren" : "Training starten");
        stateText.setText(s.demo() ? (s.running() ? "●  Gelernte Route wird vorgeführt" : "●  Vorführung pausiert") :
                s.running() ? "●  Agent erkundet und lernt" : "●  Pausiert · bereit zum Lernen");
        double[] q=s.currentQ();qText.setText(String.format(Locale.GERMANY,
                "<html>Q an Agentposition<br>↑ %.2f &nbsp; → %.2f &nbsp; ↓ %.2f &nbsp; ← %.2f</html>",q[0],q[1],q[2],q[3]));
        long now=System.nanoTime();
        if(now-rateTime>1_000_000_000L) {
            stepsPerSecond=Math.max(0,s.steps()-lastRateSteps)*1e9/(now-rateTime);
            lastRateSteps=s.steps();rateTime=now;
        }
        if(now<noticeUntil) status.setText(notice);
        else status.setText(String.format(Locale.GERMANY,"%d × %d  ·  %s Schritte  ·  %.0f Schritte/s  ·  Exploration %.1f %%  ·  Seed %d",
            s.maze().size,s.maze().size,nf.format(s.steps()),stepsPerSecond,s.epsilon()*100,s.maze().seed));
    }
    private void message(String text) {notice=text;noticeUntil=System.nanoTime()+5_000_000_000L;status.setText(text);}
    private JFileChooser chooser() {
        JFileChooser c=new JFileChooser();c.setFileFilter(new FileNameExtensionFilter("Maze AI Lernstand (*.mazeai)","mazeai"));
        if(lastSave!=null) c.setSelectedFile(lastSave.toFile());else c.setSelectedFile(new java.io.File("lernstand.mazeai"));return c;
    }
    private boolean save() {
        engine.setRunning(false);refresh();JFileChooser chooser=chooser();
        if(chooser.showSaveDialog(root)!=JFileChooser.APPROVE_OPTION) return false;
        Path file=chooser.getSelectedFile().toPath();
        if(!file.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".mazeai")) file=Path.of(file+".mazeai");
        if(Files.exists(file) && JOptionPane.showConfirmDialog(root,"Vorhandenen Lernstand ersetzen?","Speichern",
                JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION) return false;
        try {
            engine.save(file);lastSave=file;Engine.Snapshot s=engine.snapshot();savedSteps=s.steps();savedSeed=s.maze().seed;
            message("Lernstand gespeichert. Training ist pausiert.");return true;
        } catch(IOException ex) {error(ex);return false;}
    }
    private void load() {
        engine.setRunning(false);refresh();
        Engine.Snapshot before=engine.snapshot();
        if(before.steps()>0 && (before.steps()!=savedSteps || before.maze().seed!=savedSeed)) {
            Object[] choices={"Speichern","Verwerfen","Abbrechen"};
            int answer=JOptionPane.showOptionDialog(root,"Aktuellen ungespeicherten Lernstand behalten?","Lernstand laden",
                JOptionPane.DEFAULT_OPTION,JOptionPane.QUESTION_MESSAGE,null,choices,choices[0]);
            if(answer==0) {if(!save()) return;} else if(answer!=1) return;
        }
        JFileChooser c=chooser();if(c.showOpenDialog(root)!=JFileChooser.APPROVE_OPTION) return;
        try {
            engine.load(c.getSelectedFile().toPath());lastSave=c.getSelectedFile().toPath();Engine.Snapshot s=engine.snapshot();
            savedSteps=s.steps();savedSeed=s.maze().seed;size.setValue(s.maze().size);
            message("Lernstand geladen. Mit Training starten fortsetzen.");refresh();
        } catch(IOException ex) {error(ex);}
    }
    private void error(Exception ex) {JOptionPane.showMessageDialog(root,ex.getMessage(),"Aktion fehlgeschlagen",JOptionPane.ERROR_MESSAGE);}
    private void open() {
        frame=new JFrame("Maze / Lab — Random Maze AI");frame.setContentPane(root);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);frame.setMinimumSize(new Dimension(840,650));
        frame.setSize(1100,850);frame.setLocationRelativeTo(null);
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent event) {
                engine.setRunning(false);refresh();Engine.Snapshot s=engine.snapshot();
                if(s.steps()>0 && (s.steps()!=savedSteps || s.maze().seed!=savedSeed)) {
                    Object[] options={"Speichern","Ohne Speichern schließen","Abbrechen"};
                    int choice=JOptionPane.showOptionDialog(frame,"Lernstand vor dem Schließen speichern?","Maze / Lab",
                        JOptionPane.DEFAULT_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
                    if(choice==0) {if(!save()) return;} else if(choice!=1) return;
                }
                timer.stop();worker.shutdownNow();frame.dispose();
            }
        });
        worker=Executors.newSingleThreadScheduledExecutor(r->{Thread t=new Thread(r,"maze-cpu-trainer");t.setDaemon(true);return t;});
        worker.scheduleWithFixedDelay(()->{
            try {engine.tick();} catch(RuntimeException ex) {
                engine.setRunning(false);SwingUtilities.invokeLater(()->error(ex));
            }
        },0,20,TimeUnit.MILLISECONDS);
        timer.start();frame.setVisible(true);
    }
    static void theme() {
        UIManager.put("Panel.background",BG);UIManager.put("Label.foreground",TEXT);
        UIManager.put("OptionPane.background",CARD);UIManager.put("OptionPane.messageForeground",TEXT);
        UIManager.put("CheckBox.select",ACCENT);UIManager.put("ScrollBar.thumb",LINE);
        UIManager.put("ScrollBar.track",BG);UIManager.put("Button.select",LINE);
    }
    public static void main(String[] args) throws Exception {
        if(args.length>0 && args[0].equals("--benchmark")) {benchmark(args);return;}
        if(args.length==2 && args[0].equals("--render")) {
            SwingUtilities.invokeAndWait(()->{
                try {
                    theme();Engine e=new Engine(12,2026);e.setEndless(false);e.setSpeed(3);e.setRunning(true);
                    for(int i=0;i<200 && e.snapshot().route().length==0;i++) e.tick();e.setRunning(false);
                    MazeApp app=new MazeApp(e);app.root.setSize(1100,850);layoutTree(app.root);
                    BufferedImage image=new BufferedImage(1100,850,BufferedImage.TYPE_INT_RGB);
                    Graphics2D g=image.createGraphics();app.root.printAll(g);g.dispose();ImageIO.write(image,"png",Path.of(args[1]).toFile());
                } catch(IOException ex) {throw new RuntimeException(ex);}
            });return;
        }
        if(args.length>0) {
            System.err.println("Nutzung: java -jar RandomMazeAI.jar [--benchmark [Größe [MaxEpisoden [Seed]]]]");System.exit(2);
        }
        if(GraphicsEnvironment.isHeadless()) {
            System.err.println("Für die Oberfläche wird ein Desktop benötigt. Ohne Desktop: java -jar RandomMazeAI.jar --benchmark");System.exit(2);
        }
        SwingUtilities.invokeLater(()->{theme();new MazeApp(new Engine(12,System.nanoTime())).open();});
    }
    private static void layoutTree(Container c) {c.doLayout();for(Component child:c.getComponents()) if(child instanceof Container nested) layoutTree(nested);}
    private static void benchmark(String[] args) {
        try {
            if(args.length>4) throw new IllegalArgumentException("Zu viele Argumente");
            int size=args.length>1 ? Integer.parseInt(args[1]) : 12;
            int limit=args.length>2 ? Integer.parseInt(args[2]) : 6000;
            long seed=args.length>3 ? Long.parseLong(args[3]) : 2026;
            if(limit<1 || limit>1000000) throw new IllegalArgumentException("MaxEpisoden: 1–1000000");
            Learner l=new Learner(Maze.generate(size,seed),seed^0x71AC439L);
            long start=System.nanoTime();int[] path=new int[0];long checked=-1;
            while(l.episodes<limit) {
                l.step();if(l.episodes!=checked && l.episodes%25==0) {
                    checked=l.episodes;path=l.greedyPath();if(path.length>0) break;
                }
            }
            path=l.greedyPath();double seconds=(System.nanoTime()-start)/1e9;
            System.out.printf(Locale.ROOT,"size=%d seed=%d episodes=%d steps=%d seconds=%.3f learned=%s route=%d optimal=%d%n",
                size,seed,l.episodes,l.totalSteps,seconds,path.length>0,path.length-1,l.maze.optimalSteps());
            if(path.length==0) System.exit(1);
        } catch(IllegalArgumentException ex) {System.err.println(ex.getMessage());System.exit(2);}
    }

    static final class Board extends JPanel {
        private static final long serialVersionUID=1L;
        Engine.Snapshot snapshot;
        boolean heat=true,showRoute=true;
        Board() {setBackground(BG);}
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);if(snapshot==null) return;
            Graphics2D g=(Graphics2D)graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(CARD);g.fillRoundRect(0,0,getWidth(),getHeight(),24,24);
            Maze m=snapshot.maze();int n=m.size;
            int span=Math.max(1,Math.min(getWidth()-44,getHeight()-90));double cell=(double)span/n;
            double ox=(getWidth()-span)/2.0,oy=25+(getHeight()-90-span)/2.0;
            g.setColor(MUTED);g.setFont(font(11,Font.BOLD));g.drawString("LABYRINTH "+n+" × "+n,22,20);
            int maxVisits=1;for(int v:snapshot.visits()) maxVisits=Math.max(maxVisits,v);
            double norm=Math.log1p(maxVisits);
            for(int p=0;p<m.count();p++) {
                int x=(int)Math.round(ox+(p%n)*cell),y=(int)Math.round(oy+(p/n)*cell);
                int x2=(int)Math.round(ox+(p%n+1)*cell),y2=(int)Math.round(oy+(p/n+1)*cell);
                if(heat && snapshot.visits()[p]>0) {
                    int alpha=(int)(85*Math.log1p(snapshot.visits()[p])/norm);
                    g.setColor(new Color(64,222,191,alpha));g.fillRect(x+1,y+1,Math.max(1,x2-x-1),Math.max(1,y2-y-1));
                }
                if(snapshot.trail()[p] && !snapshot.demo()) {
                    g.setColor(new Color(64,222,191,80));int d=Math.max(2,(int)(cell*.14));
                    g.fillOval((int)(x+cell/2-d/2.0),(int)(y+cell/2-d/2.0),d,d);
                }
            }
            if(showRoute && snapshot.route().length>0) {
                g.setColor(new Color(64,222,191,180));g.setStroke(new BasicStroke(Math.max(2,(float)(cell*.16)),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
                java.awt.geom.Path2D path=new java.awt.geom.Path2D.Double();boolean first=true;
                for(int p:snapshot.route()) {double x=ox+(p%n+.5)*cell,y=oy+(p/n+.5)*cell;
                    if(first) {path.moveTo(x,y);first=false;} else path.lineTo(x,y);
                }g.draw(path);
            }
            g.setStroke(new BasicStroke(Math.max(1.5f,(float)(cell*.055)),BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));g.setColor(new Color(113,136,158));
            for(int p=0;p<m.count();p++) {
                double x=ox+(p%n)*cell,y=oy+(p/n)*cell;
                if((m.open[p]&1)==0) g.draw(new java.awt.geom.Line2D.Double(x,y,x+cell,y));
                if((m.open[p]&8)==0) g.draw(new java.awt.geom.Line2D.Double(x,y,x,y+cell));
                if(p/n==n-1) g.draw(new java.awt.geom.Line2D.Double(x,y+cell,x+cell,y+cell));
                if(p%n==n-1) g.draw(new java.awt.geom.Line2D.Double(x+cell,y,x+cell,y+cell));
            }
            marker(g,0,n,ox,oy,cell,new Color(77,145,241),"S");
            marker(g,m.count()-1,n,ox,oy,cell,GOLD,"Z");
            int agent=snapshot.demo() ? snapshot.demoPosition() : snapshot.position();
            double ax=ox+(agent%n+.5)*cell,ay=oy+(agent/n+.5)*cell,d=Math.max(5,cell*.42);
            g.setColor(new Color(64,222,191,55));g.fill(new java.awt.geom.Ellipse2D.Double(ax-d,ay-d,d*2,d*2));
            g.setColor(TEXT);g.fill(new java.awt.geom.Ellipse2D.Double(ax-d/2,ay-d/2,d,d));
            g.setColor(ACCENT);g.setStroke(new BasicStroke(2));g.draw(new java.awt.geom.Ellipse2D.Double(ax-d/2,ay-d/2,d,d));
            g.setFont(font(11,Font.PLAIN));int baseline=getHeight()-22;
            legend(g,22,baseline,TEXT,"Agent");legend(g,110,baseline,new Color(77,145,241),"Start");
            legend(g,190,baseline,GOLD,"Ziel");legend(g,260,baseline,ACCENT,"Besuche / gelernte Route");g.dispose();
        }
        static void marker(Graphics2D g,int p,int n,double ox,double oy,double cell,Color color,String text) {
            double x=ox+(p%n+.5)*cell,y=oy+(p/n+.5)*cell,d=cell*.6;
            g.setColor(new Color(color.getRed(),color.getGreen(),color.getBlue(),100));
            g.fill(new java.awt.geom.RoundRectangle2D.Double(x-d/2,y-d/2,d,d,5,5));
            if(cell>=20) {g.setColor(color);g.setFont(font((int)(cell*.33),Font.BOLD));
                FontMetrics fm=g.getFontMetrics();g.drawString(text,(float)(x-fm.stringWidth(text)/2.0),(float)(y+fm.getAscent()/2.7));}
        }
        static void legend(Graphics2D g,int x,int y,Color color,String text) {
            g.setColor(color);g.fillOval(x,y-8,7,7);g.setColor(MUTED);g.drawString(text,x+13,y);
        }
    }
}
