import java.util.Arrays;
/** Local perception and episode memory. No route finder or goal-distance oracle. */
final class Episode {
    final Maze maze;final int[] visits,lastVisit;int position,steps,lastAction=-1,wallHits,discovered;
    float reward,totalReward;boolean goal,finished;
    Episode(Maze maze) {
        this.maze=maze;visits=new int[maze.count()];lastVisit=new int[maze.count()];Arrays.fill(lastVisit,-1);
        position=maze.start;visits[position]=1;lastVisit[position]=0;discovered=1;
    }
    int budget() {return maze.count()*6;}
    void observation(float[] out) {
        Arrays.fill(out,0);int n=maze.size;
        for(int a=0;a<4;a++) {
            int next=maze.move(position,a);boolean open=next!=position;
            out[a]=open ? 1 : 0;out[4+a]=open && visits[next]==0 ? 1 : 0;
            out[8+a]=open ? Math.min(1,visits[next]/4f) : 1;
            out[12+a]=open && lastVisit[next]>=0 ? 1f/(1+steps-lastVisit[next]) : 0;
            out[16+a]=open && next==maze.goal ? 1 : 0;out[20+a]=lastAction==a ? 1 : 0;
            int neighbor=maze.neighbor(position,a);
            if(neighbor>=0) for(int b=0;b<4;b++) out[30+a*4+b]=maze.move(neighbor,b)!=neighbor ? 1 : 0;
        }
        out[24]=(maze.goal%n-position%n)/(float)(n-1);out[25]=(maze.goal/n-position/n)/(float)(n-1);
        out[26]=(position%n)/(float)(n-1);out[27]=(position/n)/(float)(n-1);
        out[28]=Math.min(1,visits[position]/10f);out[29]=discovered/(float)maze.count();
        out[46]=steps/(float)budget();out[47]=maze.size/30f;
    }
    void move(int action) {
        if(finished) throw new IllegalStateException("Episode bereits abgeschlossen");
        int next=maze.move(position,action);boolean wall=next==position;goal=next==maze.goal;
        reward=goal ? 5 : wall ? -.7f : visits[next]==0 ? .15f : -.05f;
        if(wall) wallHits++;if(visits[next]==0) discovered++;
        position=next;steps++;lastAction=action;visits[next]++;lastVisit[next]=steps;totalReward+=reward;
        finished=goal || steps>=budget();
    }
}
