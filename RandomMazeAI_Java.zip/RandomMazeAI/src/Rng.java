/** Small deterministic SplitMix64 generator; its state is included in save files. */
final class Rng {
    long state;
    Rng(long seed) {state=seed;}
    long nextLong() {
        long z=(state+=0x9E3779B97F4A7C15L);
        z=(z^(z>>>30))*0xBF58476D1CE4E5B9L;
        z=(z^(z>>>27))*0x94D049BB133111EBL;
        return z^(z>>>31);
    }
    int nextInt(int bound) {return (int)((nextLong()>>>1)%bound);}
    double nextDouble() {return (nextLong()>>>11)*0x1.0p-53;}
}
