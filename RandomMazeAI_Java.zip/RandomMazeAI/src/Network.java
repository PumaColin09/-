/** CPU Q network: 48 inputs, two hidden layers, four outputs; Adam and Huber loss. */
final class Network {
    static final int INPUT=48,H1=32,H2=24,PARAMETERS=2460;
    static final int B1=1536,W2=1568,B2=2336,W3=2360,B3=2456;
    final float[] parameters=new float[PARAMETERS],momentum=new float[PARAMETERS],variance=new float[PARAMETERS];
    private final float[] h1=new float[H1],h2=new float[H2],prediction=new float[4],d1=new float[H1],d2=new float[H2];
    long adamStep;
    Network(long seed) {
        Rng r=new Rng(seed);init(r,0,B1,INPUT);init(r,W2,B2,H1);init(r,W3,B3,H2);
        for(int j=0;j<H1;j++) parameters[B1+j]=.02f;
        for(int j=0;j<H2;j++) parameters[B2+j]=.02f;
    }
    private void init(Rng rng,int begin,int end,int fan) {
        float scale=(float)Math.sqrt(6.0/fan);
        for(int i=begin;i<end;i++) parameters[i]=(float)(rng.nextDouble()*2-1)*scale;
    }
    void copyFrom(Network other) {System.arraycopy(other.parameters,0,parameters,0,PARAMETERS);}
    void predict(float[] input,float[] output) {
        for(int j=0;j<H1;j++) {float v=parameters[B1+j];int o=j*INPUT;
            for(int i=0;i<INPUT;i++) v+=parameters[o+i]*input[i];h1[j]=Math.max(0,v);}
        for(int j=0;j<H2;j++) {float v=parameters[B2+j];int o=W2+j*H1;
            for(int i=0;i<H1;i++) v+=parameters[o+i]*h1[i];h2[j]=Math.max(0,v);}
        for(int a=0;a<4;a++) {float v=parameters[B3+a];int o=W3+a*H2;
            for(int i=0;i<H2;i++) v+=parameters[o+i]*h2[i];output[a]=v;}
    }
    double train(float[] state,int action,float target) {
        predict(state,prediction);float error=prediction[action]-target,derivative=Math.max(-1,Math.min(1,error));
        for(int j=0;j<H2;j++) d2[j]=h2[j]>0 ? derivative*parameters[W3+action*H2+j] : 0;
        for(int i=0;i<H1;i++) {float v=0;
            for(int j=0;j<H2;j++) v+=d2[j]*parameters[W2+j*H1+i];d1[i]=h1[i]>0 ? v : 0;}
        adamStep++;float c1=(float)(1/(1-Math.pow(.9,adamStep))),c2=(float)(1/(1-Math.pow(.999,adamStep)));
        for(int a=0;a<4;a++) {
            float outputGradient=a==action ? derivative : 0;
            for(int i=0;i<H2;i++) adam(W3+a*H2+i,outputGradient*h2[i],c1,c2);
            adam(B3+a,outputGradient,c1,c2);
        }
        for(int j=0;j<H2;j++) {
            for(int i=0;i<H1;i++) adam(W2+j*H1+i,d2[j]*h1[i],c1,c2);adam(B2+j,d2[j],c1,c2);}
        for(int j=0;j<H1;j++) {
            for(int i=0;i<INPUT;i++) adam(j*INPUT+i,d1[j]*state[i],c1,c2);adam(B1+j,d1[j],c1,c2);}
        float abs=Math.abs(error);return abs<1 ? .5*error*error : abs-.5;
    }
    private void adam(int i,float gradient,float c1,float c2) {
        gradient=Math.max(-3,Math.min(3,gradient));momentum[i]=.9f*momentum[i]+.1f*gradient;
        variance[i]=.999f*variance[i]+.001f*gradient*gradient;
        parameters[i]-=.0005f*(momentum[i]*c1)/((float)Math.sqrt(variance[i]*c2)+1e-7f);
    }
    static int argmax(float[] q) {int a=0;for(int i=1;i<4;i++) if(q[i]>q[a]) a=i;return a;}
    long hash() {long h=1;for(float p:parameters) h=31*h+Float.floatToIntBits(p);return h;}
}
