import java.util.Arrays;

/** Tabular Q-learning. States are cell indices; actions are the four directions. */
final class Learner {
    final Maze maze;
    final Rng rng;
    final double[] q;
    final int[] visits;
    final boolean[] trail, recent=new boolean[100];
    final double alpha=0.25, gamma=0.995;
    double epsilon=0.95;
    int position, episodeSteps, bestSteps=Integer.MAX_VALUE, lastSteps, recentIndex, recentCount;
    long episodes, successes, totalSteps;
    Learner(Maze maze,long seed) {
        this.maze=maze;this.rng=new Rng(seed);
        q=new double[maze.count()*4];visits=new int[maze.count()];trail=new boolean[maze.count()];
        trail[0]=true;
    }
    double maxQ(int state) {
        int o=state*4;double best=q[o];
        for(int a=1;a<4;a++) best=Math.max(best,q[o+a]);
        return best;
    }
    int greedyAction(int state) {
        int action=0,o=state*4;
        for(int a=1;a<4;a++) if(q[o+a]>q[o+action]) action=a;
        return action;
    }
    int trainingAction() {
        if(rng.nextDouble()<epsilon) return rng.nextInt(4);
        double best=maxQ(position);int chosen=0,ties=0;
        for(int a=0;a<4;a++) if(q[position*4+a]==best) {
            if(rng.nextInt(++ties)==0) chosen=a;
        }
        return chosen;
    }
    void update(int state,int action,double reward,int next,boolean terminal) {
        int index=state*4+action;
        double target=reward+(terminal ? 0 : gamma*maxQ(next));
        q[index]+=alpha*(target-q[index]);
    }
    void step() {
        int state=position,action=trainingAction(),next=maze.move(state,action);
        boolean goal=next==maze.count()-1;
        double reward=goal ? 20 : next==state ? -0.35 : -0.025;
        // A time limit truncates the episode, not the environment's Bellman target.
        update(state,action,reward,next,goal);
        position=next;totalSteps++;episodeSteps++;trail[next]=true;
        if(visits[next]<Integer.MAX_VALUE) visits[next]++;
        if(goal || episodeSteps>=maze.count()*20) {
            episodes++;if(goal) {successes++;bestSteps=Math.min(bestSteps,episodeSteps);}
            lastSteps=episodeSteps;recent[recentIndex]=goal;recentIndex=(recentIndex+1)%100;
            recentCount=Math.min(100,recentCount+1);
            epsilon=Math.max(0.08,epsilon*0.9995);
            position=0;episodeSteps=0;Arrays.fill(trail,false);trail[0]=true;
        }
    }
    double recentRate() {
        if(recentCount==0) return 0;
        int wins=0;for(boolean success:recent) if(success) wins++;
        return (double)wins/recentCount;
    }
    /** Follow ONLY learned Q-values, with no exploration, oracle or path search. */
    int[] greedyPath() {
        int[] path=new int[maze.count()];boolean[] seen=new boolean[maze.count()];
        int p=0,length=0;
        while(!seen[p]) {
            seen[p]=true;path[length++]=p;
            if(p==maze.count()-1) return Arrays.copyOf(path,length);
            p=maze.move(p,greedyAction(p));
        }
        return new int[0];
    }
}
