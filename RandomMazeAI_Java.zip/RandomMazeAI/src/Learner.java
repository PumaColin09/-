/** Persistent Double-DQN learner across all maps, with replay and a target net. */
final class Learner {
    Maze maze;Episode episode;final Rng rng;final Network online,target;final ReplayBuffer replay=new ReplayBuffer();
    final boolean[] recent=new boolean[100];int recentIndex,recentCount,bestSteps=Integer.MAX_VALUE,lastSteps,mapEpisodes;
    long episodes,successes,totalSteps,updates,maps=1;double epsilon=.9,loss;
    int lastAction=-1;float lastReward;boolean lastExploration,lastGoal;
    String lastDecision="Noch keine Aktion";
    private final float[] state=new float[Network.INPUT],next=new float[Network.INPUT],q=new float[4],qNext=new float[4],targetQ=new float[4];
    Learner(Maze maze,long seed) {
        this.maze=maze;episode=new Episode(maze);rng=new Rng(seed);
        online=new Network(seed);target=new Network(seed);target.copyFrom(online);
    }
    void changeMaze(Maze nextMaze) {
        maze=nextMaze;episode=new Episode(maze);mapEpisodes=0;maps++;bestSteps=Integer.MAX_VALUE;
        lastDecision="Neue Karte – Modell und Erfahrungen bleiben erhalten";
    }
    void step() {
        episode.observation(state);online.predict(state,q);
        boolean exploring=rng.nextDouble()<epsilon;int action=exploring ? rng.nextInt(4) : Network.argmax(q);
        int before=episode.position;boolean unvisited=episode.visits[maze.move(before,action)]==0;
        episode.move(action);episode.observation(next);
        lastAction=action;lastReward=episode.reward;lastExploration=exploring;lastGoal=episode.goal;
        lastDecision=episode.goal ? "Ziel erreicht" : episode.position==before ? "Wand getroffen" :
            unvisited ? "Neues Feld entdeckt" : "Bekanntes Feld erneut besucht";
        replay.add(state,action,episode.reward,next,episode.goal);
        totalSteps++;epsilon=Math.max(.08,.9-.82*Math.min(1,totalSteps/150000.0));
        if(replay.count>=128 && totalSteps%4==0) trainBatch();
        if(episode.finished) {
            episodes++;mapEpisodes++;if(episode.goal) {successes++;bestSteps=Math.min(bestSteps,episode.steps);}
            lastSteps=episode.steps;recent[recentIndex]=episode.goal;recentIndex=(recentIndex+1)%100;recentCount=Math.min(100,recentCount+1);
            episode=new Episode(maze);
        }
    }
    private void trainBatch() {
        double batchLoss=0;
        for(int b=0;b<8;b++) {
            int i=rng.nextInt(replay.count);float targetValue=replay.reward[i];
            if(!replay.terminal[i]) {
                online.predict(replay.next[i],qNext);target.predict(replay.next[i],targetQ);
                targetValue+=.94f*targetQ[Network.argmax(qNext)];
            }
            batchLoss+=online.train(replay.state[i],replay.action[i],Math.max(-20,Math.min(20,targetValue)));
        }
        updates++;loss=updates==1 ? batchLoss/8 : .98*loss+.02*batchLoss/8;
        if(updates%250==0) target.copyFrom(online);
    }
    double recentRate() {int wins=0;for(boolean b:recent) if(b) wins++;return recentCount==0 ? 0 : wins/(double)recentCount;}
    long modelHash() {return online.hash();}
    float[] currentQ() {float[] out=new float[4];episode.observation(state);online.predict(state,out);return out;}
    int[] greedyPath() {
        Episode probe=new Episode(maze);int[] path=new int[probe.budget()+1];path[0]=maze.start;
        float[] obs=new float[Network.INPUT],values=new float[4];int length=1;
        while(!probe.finished) {
            probe.observation(obs);online.predict(obs,values);probe.move(Network.argmax(values));path[length++]=probe.position;
        }
        return probe.goal ? java.util.Arrays.copyOf(path,length) : new int[0];
    }
}
