import java.util.Arrays;

/** A perfect maze: each cell is reachable and there is exactly one simple route. */
final class Maze {
    static final int MIN_SIZE=4, MAX_SIZE=30;
    // Bit order: north, east, south, west. A set bit means an OPEN passage.
    final int size;
    final long seed;
    final int start,goal;
    final int[] open;
    Maze(int size,long seed,int[] open) {
        this(size,seed,open,endpoints(size,seed)[0],endpoints(size,seed)[1]);
    }
    Maze(int size,long seed,int[] open,int start,int goal) {
        if(size<MIN_SIZE || size>MAX_SIZE || open.length!=size*size)
            throw new IllegalArgumentException("Größe muss zwischen 4 und 30 liegen.");
        this.size=size;this.seed=seed;this.open=open.clone();this.start=start;this.goal=goal;
        if(start<0 || goal<0 || start>=count() || goal>=count() || start==goal)
            throw new IllegalArgumentException("Start und Ziel müssen verschieden und in der Karte liegen");
        validate();
    }
    private static int[] endpoints(int size,long seed) {
        if(size<MIN_SIZE || size>MAX_SIZE) throw new IllegalArgumentException("Größe 4–30");
        Rng rng=new Rng(seed^0x51A8B47128A2L);int start=rng.nextInt(size*size),goal;
        do {goal=rng.nextInt(size*size);} while(goal==start);
        return new int[]{start,goal};
    }
    int count() {return size*size;}
    int neighbor(int p,int a) {
        int x=p%size,y=p/size;
        return switch(a) {
            case 0 -> y>0 ? p-size : -1;
            case 1 -> x<size-1 ? p+1 : -1;
            case 2 -> y<size-1 ? p+size : -1;
            case 3 -> x>0 ? p-1 : -1;
            default -> throw new IllegalArgumentException("Unbekannte Richtung");
        };
    }
    int move(int p,int a) {
        if(p<0 || p>=count()) throw new IllegalArgumentException("Ungültige Position");
        int n=neighbor(p,a);
        return n>=0 && (open[p]&(1<<a))!=0 ? n : p;
    }
    static Maze generate(int size,long seed) {
        if(size<MIN_SIZE || size>MAX_SIZE) throw new IllegalArgumentException("Größe 4–30");
        int count=size*size;
        int[] open=new int[count],stack=new int[count],choices=new int[4];
        boolean[] visited=new boolean[count];
        Rng rng=new Rng(seed);int top=0;stack[0]=0;visited[0]=true;
        while(top>=0) {
            int p=stack[top],x=p%size,y=p/size,k=0;
            if(y>0 && !visited[p-size]) choices[k++]=0;
            if(x<size-1 && !visited[p+1]) choices[k++]=1;
            if(y<size-1 && !visited[p+size]) choices[k++]=2;
            if(x>0 && !visited[p-1]) choices[k++]=3;
            if(k==0) {top--;continue;}
            int a=choices[rng.nextInt(k)];
            int n=p+switch(a) {case 0->-size;case 1->1;case 2->size;default->-1;};
            open[p]|=1<<a;open[n]|=1<<((a+2)%4);
            visited[n]=true;stack[++top]=n;
        }
        return new Maze(size,seed,open);
    }
    void validate() {
        int directedEdges=0;
        for(int p=0;p<count();p++) {
            if((open[p]&~15)!=0) throw new IllegalArgumentException("Ungültige Wanddaten");
            for(int a=0;a<4;a++) if((open[p]&(1<<a))!=0) {
                int n=neighbor(p,a);
                if(n<0 || (open[n]&(1<<((a+2)%4)))==0)
                    throw new IllegalArgumentException("Beschädigtes Labyrinth");
                directedEdges++;
            }
        }
        boolean[] seen=new boolean[count()];int[] queue=new int[count()];
        int head=0,tail=1;seen[0]=true;
        while(head<tail) {
            int p=queue[head++];
            for(int a=0;a<4;a++) {int n=move(p,a);if(!seen[n]) {seen[n]=true;queue[tail++]=n;}}
        }
        if(tail!=count() || directedEdges!=2*(count()-1))
            throw new IllegalArgumentException("Labyrinth ist nicht zusammenhängend oder enthält Kreise");
    }
    /** BFS is used ONLY for a comparison metric, never by the learning agent. */
    int optimalSteps() {
        int[] distance=new int[count()],queue=new int[count()];Arrays.fill(distance,-1);
        int head=0,tail=1;queue[0]=start;distance[start]=0;
        while(head<tail) {
            int p=queue[head++];if(p==goal) return distance[p];
            for(int a=0;a<4;a++) {int n=move(p,a);if(distance[n]<0) {
                distance[n]=distance[p]+1;queue[tail++]=n;
            }}
        }
        throw new IllegalStateException("Nicht verbunden");
    }
}
