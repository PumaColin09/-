import javax.swing.*;
import java.awt.*;
import java.util.Locale;
/** Displays measured held-out scores, including real regressions rather than a rising fake curve. */
final class LearningPanel extends JPanel {
    private static final long serialVersionUID=1L;
    Progress.Point[] points=new Progress.Point[0];boolean testing;
    LearningPanel() {setBackground(MazeApp.BG);setPreferredSize(new Dimension(600,195));}
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);Graphics2D g=(Graphics2D)graphics.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(MazeApp.CARD);g.fillRoundRect(0,0,getWidth(),getHeight(),22,22);
        g.setColor(MazeApp.TEXT);g.setFont(MazeApp.font(13,Font.BOLD));g.drawString("WIRD ER AUF NEUEN KARTEN BESSER?",18,24);
        g.setColor(MazeApp.MUTED);g.setFont(MazeApp.font(10,Font.PLAIN));
        g.drawString("24 feste Testkarten · 4×4 / 6×6 / 8×8 · ohne Exploration und Gewichtsänderung",18,42);
        int left=44,top=61,right=getWidth()-22,bottom=getHeight()-44;
        for(int level=0;level<=100;level+=50) {
            int y=bottom-(bottom-top)*level/100;g.setColor(MazeApp.LINE);g.drawLine(left,y,right,y);
            g.setColor(MazeApp.MUTED);g.drawString(level+"%",7,y+4);
        }
        if(points.length>0) {
            long maxStep=Math.max(10000,points[points.length-1].steps());
            Progress.Point first=points[0],last=points[points.length-1];
            g.setColor(new Color(139,159,181,150));g.setStroke(new BasicStroke(1.3f,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10,new float[]{4,5},0));
            int by=bottom-(int)(first.success()*(bottom-top));g.drawLine(left,by,right,by);
            java.awt.geom.Path2D path=new java.awt.geom.Path2D.Double();
            for(int i=0;i<points.length;i++) {
                int x=left+(int)((right-left)*points[i].steps()/(double)maxStep);
                int y=bottom-(int)(points[i].success()*(bottom-top));
                if(i==0) path.moveTo(x,y);else path.lineTo(x,y);
            }
            g.setColor(MazeApp.ACCENT);g.setStroke(new BasicStroke(2.5f));g.draw(path);
            for(Progress.Point p:points) {int x=left+(int)((right-left)*p.steps()/(double)maxStep),y=bottom-(int)(p.success()*(bottom-top));g.fillOval(x-3,y-3,6,6);}
            g.setColor(MazeApp.MUTED);g.drawString("0",left,bottom+15);g.drawString(String.format(Locale.GERMANY,"%,d Lernschritte",maxStep),Math.max(left,right-125),bottom+15);
            g.setFont(MazeApp.font(10,Font.PLAIN));g.setColor(MazeApp.TEXT);
            g.drawString(String.format(Locale.GERMANY,"Wegaufwand %.1f× → %.1f× · Wandtreffer %.1f → %.1f / 100 Schritte",
                first.cost(),last.cost(),first.walls(),last.walls()),18,getHeight()-10);
        }
        if(testing) {g.setColor(MazeApp.GOLD);g.drawString("Test läuft …",Math.max(18,getWidth()-90),24);}
        else if(points.length<2) {g.setColor(MazeApp.GOLD);g.drawString("Nächste Messung nach 10.000 Lernschritten",Math.max(left+5,(left+right)/2-105),top+17);}
        g.dispose();
    }
}
