import java.util.ArrayList;
/** Honest fixed-test measurements, with the untrained measurement kept as baseline. */
final class Progress {
    record Point(long steps,double success,double cost,double coverage,double walls,double loss) {}
    final ArrayList<Point> points=new ArrayList<>();
    void add(long step,Evaluation.Result test,double loss) {
        if(points.size()>=160) points.remove(1);
        points.add(new Point(step,test.successRate(),test.meanCost(),test.coverage(),test.wallsPer100(),loss));
    }
    Point[] snapshot() {return points.toArray(Point[]::new);}
}
