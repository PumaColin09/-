/** Fixed-size experience ring shared between maps. */
final class ReplayBuffer {
    static final int CAPACITY=4096;
    final float[][] state=new float[CAPACITY][Network.INPUT],next=new float[CAPACITY][Network.INPUT];
    final float[] reward=new float[CAPACITY];final int[] action=new int[CAPACITY];
    final boolean[] terminal=new boolean[CAPACITY];int count,cursor;
    void add(float[] s,int a,float r,float[] n,boolean done) {
        System.arraycopy(s,0,state[cursor],0,Network.INPUT);System.arraycopy(n,0,next[cursor],0,Network.INPUT);
        action[cursor]=a;reward[cursor]=r;terminal[cursor]=done;cursor=(cursor+1)%CAPACITY;count=Math.min(CAPACITY,count+1);
    }
}
