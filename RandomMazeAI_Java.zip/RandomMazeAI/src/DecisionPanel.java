import javax.swing.*;
import java.awt.*;
import java.util.Locale;
/** Perception and Q outputs, visible above the map even when sidebar is scrolled. */
final class DecisionPanel extends JPanel {
    private static final long serialVersionUID=1L;
    Engine.Snapshot snapshot;
    DecisionPanel() {setBackground(MazeApp.BG);setPreferredSize(new Dimension(600,112));}
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);if(snapshot==null) return;
        Graphics2D g=(Graphics2D)graphics.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(MazeApp.CARD);g.fillRoundRect(0,0,getWidth(),getHeight(),22,22);
        g.setFont(MazeApp.font(12,Font.BOLD));g.setColor(MazeApp.TEXT);
        String direction=snapshot.action()<0 ? "" : new String[]{"↑","→","↓","←"}[snapshot.action()];
        String text=snapshot.action()<0 ? "Bereit: Das Netz wird mit jeder Erfahrung weitertrainiert" :
            String.format(Locale.GERMANY,"Zuletzt %s · %s · %s · Reward %+.2f",direction,snapshot.decision(),
                snapshot.exploring() ? "zufällig" : "Netzentscheidung",snapshot.reward());
        g.drawString(text,16,22);g.setFont(MazeApp.font(10,Font.PLAIN));g.setColor(MazeApp.MUTED);
        g.drawString("Aktuelle Wahrnehmung und gelernter Nutzwert für die nächste Aktion",16,40);
        double[] q=snapshot.currentQ();int best=0;for(int a=1;a<4;a++) if(q[a]>q[best]) best=a;
        double max=1;for(double value:q) max=Math.max(max,Math.abs(value));
        int width=(getWidth()-40)/4;
        for(int a=0;a<4;a++) {
            int x=16+a*(width+2);g.setColor(a==best ? new Color(27,73,70) : MazeApp.BG);g.fillRoundRect(x,49,width-5,53,9,9);
            g.setColor(a==best ? MazeApp.ACCENT : MazeApp.TEXT);g.setFont(MazeApp.font(13,Font.BOLD));
            g.drawString(String.format(Locale.GERMANY,"%s  %+.2f",new String[]{"↑","→","↓","←"}[a],q[a]),x+9,69);
            int next=snapshot.maze().move(snapshot.position(),a);
            String feature=next==snapshot.position() ? "Wand" : next==snapshot.maze().goal ? "Ziel" : snapshot.visits()[next]==0 ? "unbesucht" : "besucht";
            g.setFont(MazeApp.font(10,Font.PLAIN));g.setColor(MazeApp.MUTED);g.drawString(feature,x+9,85);
            g.setColor(a==best ? MazeApp.ACCENT : new Color(67,115,151));
            g.fillRect(x+9,93,Math.max(1,(int)((width-25)*Math.abs(q[a])/max)),3);
        }
        g.dispose();
    }
}
