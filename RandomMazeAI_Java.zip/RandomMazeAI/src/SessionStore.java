import java.io.*;
import java.nio.file.*;
import java.util.zip.CRC32;
/** V2: full persistent DQN model, optimizer, replay and episode state. */
final class SessionStore {
    private static final int MAGIC=0x4D415A45,VERSION=2,MAX_BYTES=4_000_000;
    record Saved(Learner learner,long solvedMazes,Progress progress,long mapRngState) {}
    static void save(Path path,Learner l,long completed,Progress progress) throws IOException {
        save(path,l,completed,progress,0);
    }
    static void save(Path path,Learner l,long completed,Progress progress,long mapRngState) throws IOException {
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        try(DataOutputStream o=new DataOutputStream(buffer)) {
            o.writeInt(MAGIC);o.writeInt(VERSION);o.writeInt(l.maze.size);o.writeLong(l.maze.seed);
            o.writeInt(l.maze.start);o.writeInt(l.maze.goal);for(int bits:l.maze.open) o.writeByte(bits);
            o.writeLong(completed);o.writeLong(mapRngState);o.writeLong(l.rng.state);o.writeLong(l.maps);o.writeLong(l.totalSteps);
            o.writeLong(l.episodes);o.writeLong(l.successes);o.writeLong(l.updates);o.writeDouble(l.epsilon);o.writeDouble(l.loss);
            o.writeInt(l.mapEpisodes);o.writeInt(l.bestSteps);o.writeInt(l.lastSteps);o.writeInt(l.recentIndex);o.writeInt(l.recentCount);
            for(boolean b:l.recent) o.writeBoolean(b);
            o.writeInt(l.lastAction);o.writeFloat(l.lastReward);o.writeBoolean(l.lastExploration);o.writeBoolean(l.lastGoal);o.writeUTF(l.lastDecision);
            writeNetwork(o,l.online);writeNetwork(o,l.target);
            Episode e=l.episode;o.writeInt(e.position);o.writeInt(e.steps);o.writeInt(e.lastAction);o.writeInt(e.wallHits);o.writeInt(e.discovered);
            o.writeFloat(e.reward);o.writeFloat(e.totalReward);
            for(int v:e.visits) o.writeInt(v);for(int v:e.lastVisit) o.writeInt(v);
            ReplayBuffer r=l.replay;o.writeInt(r.count);o.writeInt(r.cursor);
            for(int i=0;i<r.count;i++) {
                for(float f:r.state[i]) o.writeFloat(f);for(float f:r.next[i]) o.writeFloat(f);
                o.writeFloat(r.reward[i]);o.writeInt(r.action[i]);o.writeBoolean(r.terminal[i]);
            }
            o.writeInt(progress.points.size());
            for(Progress.Point p:progress.points) {
                o.writeLong(p.steps());o.writeDouble(p.success());o.writeDouble(p.cost());
                o.writeDouble(p.coverage());o.writeDouble(p.walls());o.writeDouble(p.loss());
            }
        }
        byte[] data=buffer.toByteArray();CRC32 crc=new CRC32();crc.update(data);
        Path absolute=path.toAbsolutePath(),parent=absolute.getParent();
        if(parent==null || !Files.isDirectory(parent)) throw new IOException("Zielordner fehlt");
        Path tmp=Files.createTempFile(parent,"maze-save-",".tmp");
        try {
            try(DataOutputStream o=new DataOutputStream(Files.newOutputStream(tmp))) {o.write(data);o.writeLong(crc.getValue());}
            try {Files.move(tmp,absolute,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException ex) {Files.move(tmp,absolute,StandardCopyOption.REPLACE_EXISTING);}
        } finally {Files.deleteIfExists(tmp);}
    }
    static Saved load(Path path) throws IOException {
        if(Files.size(path)>MAX_BYTES) throw new IOException("Speicherdatei zu groß");
        byte[] data;try(InputStream i=Files.newInputStream(path)) {data=i.readNBytes(MAX_BYTES+1);}
        require(data.length>100 && data.length<=MAX_BYTES,"Ungültige Dateigröße");
        CRC32 crc=new CRC32();crc.update(data,0,data.length-8);
        try(DataInputStream i=new DataInputStream(new ByteArrayInputStream(data,data.length-8,8))) {
            require(i.readLong()==crc.getValue(),"Beschädigter Speicherstand: Prüfsumme falsch");
        }
        try(DataInputStream i=new DataInputStream(new ByteArrayInputStream(data,0,data.length-8))) {
            require(i.readInt()==MAGIC,"Keine Maze-AI-Datei");int version=i.readInt();
            if(version==1) throw new IOException("V1 enthält eine Q-Tabelle pro Karte. Für Deep Q Learning bitte ein neues Training starten.");
            require(version==VERSION,"Nicht unterstützte Speicherversion");
            int size=i.readInt();require(size>=4 && size<=30,"Ungültige Größe");long seed=i.readLong();
            int start=i.readInt(),goal=i.readInt(),count=size*size;int[] open=new int[count];
            for(int p=0;p<count;p++) open[p]=i.readUnsignedByte();
            Learner l=new Learner(new Maze(size,seed,open,start,goal),0);
            long completed=i.readLong();require(completed>=0,"Ungültiger Kartenzähler");
            long mapRngState=i.readLong();
            l.rng.state=i.readLong();l.maps=i.readLong();l.totalSteps=i.readLong();l.episodes=i.readLong();l.successes=i.readLong();l.updates=i.readLong();
            require(l.maps>=1 && l.totalSteps>=0 && l.episodes>=0 && l.successes>=0 && l.successes<=l.episodes
                && l.updates>=0 && l.updates<=l.totalSteps/4,"Ungültige Statistik");
            l.epsilon=number(i,.08,.9);l.loss=number(i,0,100);
            l.mapEpisodes=i.readInt();l.bestSteps=i.readInt();l.lastSteps=i.readInt();l.recentIndex=i.readInt();l.recentCount=i.readInt();
            require(l.mapEpisodes>=0 && l.mapEpisodes<=l.episodes && l.lastSteps>=0 && l.lastSteps<=5400,"Ungültige Episodenzahl");
            require(l.bestSteps==Integer.MAX_VALUE || l.bestSteps>0 && l.bestSteps<=count*6,"Ungültige Bestzeit");
            require(l.recentIndex==l.episodes%100 && l.recentCount==Math.min(100,l.episodes),"Ungültiger Verlauf");
            for(int n=0;n<100;n++) l.recent[n]=bool(i);
            l.lastAction=i.readInt();require(l.lastAction>=-1 && l.lastAction<4,"Ungültige Aktion");
            l.lastReward=decimal(i,-1,5);l.lastExploration=bool(i);l.lastGoal=bool(i);l.lastDecision=i.readUTF();require(l.lastDecision.length()<200,"Ungültiger Text");
            readNetwork(i,l.online);readNetwork(i,l.target);
            Episode e=l.episode;e.position=i.readInt();e.steps=i.readInt();e.lastAction=i.readInt();e.wallHits=i.readInt();e.discovered=i.readInt();
            require(e.position>=0 && e.position<count && e.position!=goal && e.steps>=0 && e.steps<count*6
                && e.lastAction>=-1 && e.lastAction<4 && e.wallHits>=0 && e.wallHits<=e.steps
                && e.discovered>=1 && e.discovered<=count,"Ungültige aktuelle Episode");
            e.reward=decimal(i,-1,5);e.totalReward=decimal(i,-10000,10000);
            int discovered=0;long sum=0;
            for(int n=0;n<count;n++) {e.visits[n]=i.readInt();require(e.visits[n]>=0 && e.visits[n]<=e.steps+1,"Ungültige Besuche");
                sum+=e.visits[n];if(e.visits[n]>0) discovered++;}
            for(int n=0;n<count;n++) {e.lastVisit[n]=i.readInt();require(e.lastVisit[n]>=-1 && e.lastVisit[n]<=e.steps,"Ungültige Erinnerung");}
            require(e.visits[e.position]>0 && e.visits[start]>0 && sum==e.steps+1 && discovered==e.discovered,"Inkonsistente Episode");
            ReplayBuffer r=l.replay;r.count=i.readInt();r.cursor=i.readInt();
            require(r.count>=0 && r.count<=ReplayBuffer.CAPACITY && r.cursor>=0 && r.cursor<ReplayBuffer.CAPACITY
                && (r.count==ReplayBuffer.CAPACITY || r.cursor==r.count),"Ungültiger Replay-Speicher");
            for(int n=0;n<r.count;n++) {
                for(int k=0;k<Network.INPUT;k++) r.state[n][k]=decimal(i,-1,1);
                for(int k=0;k<Network.INPUT;k++) r.next[n][k]=decimal(i,-1,1);
                r.reward[n]=decimal(i,-1,5);r.action[n]=i.readInt();require(r.action[n]>=0 && r.action[n]<4,"Ungültige Replay-Aktion");r.terminal[n]=bool(i);
            }
            Progress progress=new Progress();int length=i.readInt();require(length>=0 && length<=160,"Ungültige Kurvenlänge");long previous=-1;
            for(int n=0;n<length;n++) {
                long step=i.readLong();require(step>=previous && step<=l.totalSteps,"Ungültiger Testzeitpunkt");previous=step;
                progress.points.add(new Progress.Point(step,number(i,0,1),number(i,0,5400),number(i,0,1),number(i,0,100),number(i,0,100)));
            }
            require(i.available()==0,"Unerwartete zusätzliche Daten");return new Saved(l,completed,progress,mapRngState);
        } catch(IllegalArgumentException | EOFException ex) {throw new IOException("Ungültiger oder unvollständiger Speicherstand",ex);}
    }
    private static void writeNetwork(DataOutputStream o,Network n) throws IOException {
        o.writeLong(n.adamStep);for(float f:n.parameters) o.writeFloat(f);for(float f:n.momentum) o.writeFloat(f);for(float f:n.variance) o.writeFloat(f);
    }
    private static void readNetwork(DataInputStream i,Network n) throws IOException {
        n.adamStep=i.readLong();require(n.adamStep>=0,"Ungültiger Optimizer-Zähler");
        for(int k=0;k<Network.PARAMETERS;k++) n.parameters[k]=decimal(i,-100,100);
        for(int k=0;k<Network.PARAMETERS;k++) n.momentum[k]=decimal(i,-100,100);
        for(int k=0;k<Network.PARAMETERS;k++) n.variance[k]=decimal(i,0,100);
    }
    private static boolean bool(DataInputStream i) throws IOException {int v=i.readUnsignedByte();require(v==0 || v==1,"Ungültiger Wahrheitswert");return v==1;}
    private static float decimal(DataInputStream i,double low,double high) throws IOException {float v=i.readFloat();require(Float.isFinite(v) && v>=low && v<=high,"Ungültige Zahl");return v;}
    private static double number(DataInputStream i,double low,double high) throws IOException {double v=i.readDouble();require(Double.isFinite(v) && v>=low && v<=high,"Ungültige Zahl");return v;}
    private static void require(boolean b,String text) throws IOException {if(!b) throw new IOException(text);}
}
