import java.io.*;
import java.nio.file.*;
import java.util.zip.CRC32;

/** Versioned data format, not Java object deserialization. */
final class SessionStore {
    private static final int MAGIC=0x4D415A45, VERSION=1, MAX_BYTES=100000;
    record Saved(Learner learner,long solvedMazes) {}
    static void save(Path path,Learner l,long solvedMazes) throws IOException {
        ByteArrayOutputStream buffer=new ByteArrayOutputStream();
        try(DataOutputStream out=new DataOutputStream(buffer)) {
            out.writeInt(MAGIC);out.writeInt(VERSION);out.writeInt(l.maze.size);out.writeLong(l.maze.seed);
            out.writeLong(solvedMazes);out.writeLong(l.rng.state);
            out.writeDouble(l.epsilon);out.writeInt(l.position);out.writeInt(l.episodeSteps);
            out.writeInt(l.bestSteps);out.writeInt(l.lastSteps);
            out.writeLong(l.episodes);out.writeLong(l.successes);out.writeLong(l.totalSteps);
            out.writeInt(l.recentIndex);out.writeInt(l.recentCount);
            for(int bits:l.maze.open) out.writeByte(bits);
            for(double value:l.q) out.writeDouble(value);
            for(int visits:l.visits) out.writeInt(visits);
            for(boolean visited:l.trail) out.writeBoolean(visited);
            for(boolean success:l.recent) out.writeBoolean(success);
        }
        byte[] payload=buffer.toByteArray();CRC32 crc=new CRC32();crc.update(payload);
        Path absolute=path.toAbsolutePath();Path parent=absolute.getParent();
        if(parent==null || !Files.isDirectory(parent)) throw new IOException("Zielordner fehlt");
        Path temporary=Files.createTempFile(parent,"maze-save-",".tmp");
        try {
            try(DataOutputStream out=new DataOutputStream(Files.newOutputStream(temporary))) {
                out.write(payload);out.writeLong(crc.getValue());
            }
            try {Files.move(temporary,absolute,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}
            catch(AtomicMoveNotSupportedException ex) {
                Files.move(temporary,absolute,StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {Files.deleteIfExists(temporary);}
    }
    static Saved load(Path path) throws IOException {
        if(Files.size(path)>MAX_BYTES) throw new IOException("Speicherdatei ist zu groß");
        byte[] bytes;
        // Limit the actual read too, even if the file grows after the size check.
        try(InputStream in=Files.newInputStream(path)) {bytes=in.readNBytes(MAX_BYTES+1);}
        if(bytes.length<100 || bytes.length>MAX_BYTES) throw new IOException("Ungültige Dateigröße");
        CRC32 crc=new CRC32();crc.update(bytes,0,bytes.length-8);
        try(DataInputStream check=new DataInputStream(new ByteArrayInputStream(bytes,bytes.length-8,8))) {
            if(check.readLong()!=crc.getValue()) throw new IOException("Datei beschädigt: Prüfsumme stimmt nicht");
        }
        try(DataInputStream in=new DataInputStream(new ByteArrayInputStream(bytes,0,bytes.length-8))) {
            require(in.readInt()==MAGIC,"Keine Maze-AI-Datei");
            require(in.readInt()==VERSION,"Speicherversion wird nicht unterstützt");
            int size=in.readInt();require(size>=Maze.MIN_SIZE && size<=Maze.MAX_SIZE,"Ungültige Größe");
            long seed=in.readLong(),solved=in.readLong(),rng=in.readLong();
            require(solved>=0,"Ungültiger Kartenzähler");
            double epsilon=in.readDouble();int pos=in.readInt(),steps=in.readInt();
            int best=in.readInt(),last=in.readInt();
            long episodes=in.readLong(),successes=in.readLong(),total=in.readLong();
            int index=in.readInt(),recentCount=in.readInt(),count=size*size;
            require(Double.isFinite(epsilon) && epsilon>=0.08 && epsilon<=0.95,"Ungültige Exploration");
            require(pos>=0 && pos<count-1 && steps>=0 && steps<count*20,"Ungültige Position");
            require((best>0 && best<=count*20) || best==Integer.MAX_VALUE,"Ungültige Bestzeit");
            require(last>=0 && last<=count*20,"Ungültige Episodenlänge");
            require(episodes>=0 && successes>=0 && successes<=episodes && total>=steps && total>=episodes,
                    "Ungültige Statistik");
            require(index>=0 && index<100 && recentCount>=0 && recentCount<=100
                    && recentCount==Math.min(100,episodes) && index==episodes%100,"Ungültiger Verlauf");
            int[] walls=new int[count];for(int p=0;p<count;p++) walls[p]=in.readUnsignedByte();
            Learner l=new Learner(new Maze(size,seed,walls),0);
            l.rng.state=rng;l.epsilon=epsilon;l.position=pos;l.episodeSteps=steps;
            l.bestSteps=best;l.lastSteps=last;l.episodes=episodes;l.successes=successes;l.totalSteps=total;
            l.recentIndex=index;l.recentCount=recentCount;
            for(int i=0;i<l.q.length;i++) {
                double value=in.readDouble();require(Double.isFinite(value) && Math.abs(value)<=100,"Ungültiger Q-Wert");
                l.q[i]=value;
            }
            for(int i=0;i<count;i++) {l.visits[i]=in.readInt();require(l.visits[i]>=0,"Ungültige Besuche");}
            for(int i=0;i<count;i++) l.trail[i]=readBoolean(in);
            for(int i=0;i<100;i++) l.recent[i]=readBoolean(in);
            int wins=0;for(boolean success:l.recent) if(success) wins++;
            require(wins<=recentCount && wins<=successes,"Ungültige Erfolgsrate");
            require(l.trail[pos] && l.trail[0],"Ungültige Spur");
            require(in.available()==0,"Unerwartete zusätzliche Daten");
            return new Saved(l,solved);
        } catch(IllegalArgumentException | EOFException ex) {
            throw new IOException("Unvollständiger oder ungültiger Speicherstand",ex);
        }
    }
    private static boolean readBoolean(DataInputStream in) throws IOException {
        int value=in.readUnsignedByte();require(value==0 || value==1,"Ungültiger Wahrheitswert");
        return value==1;
    }
    private static void require(boolean value,String message) throws IOException {if(!value) throw new IOException(message);}
}
