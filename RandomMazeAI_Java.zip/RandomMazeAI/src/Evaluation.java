/** Fixed held-out seeds. Never train, explore or insert test transitions into replay. */
final class Evaluation {
    static final int CASES=24;static final long TEST_SEED=0x6F121234A921L;
    record Result(double successRate,double meanCost,double coverage,double wallsPer100) {}
    static Maze testMaze(int i) {return Maze.generate(new int[]{4,6,8}[i%3],TEST_SEED+i);}
    static Result evaluate(Network network) {Job job=new Job(network);while(!job.done()) job.advance(10000);return job.result();}
    static final class Job {
        final Network frozen;private Episode episode;int index,wins;long steps,walls;
        double cost,coverage;private final float[] state=new float[Network.INPUT],q=new float[4];
        Job(Network model) {frozen=new Network(0);frozen.copyFrom(model);episode=new Episode(testMaze(0));}
        boolean done() {return index==CASES;}
        void advance(int budget) {
            for(int i=0;i<budget && !done();i++) {
                episode.observation(state);frozen.predict(state,q);episode.move(Network.argmax(q));
                if(episode.finished) {
                    if(episode.goal) wins++;steps+=episode.steps;walls+=episode.wallHits;
                    cost+=episode.steps/(double)episode.maze.optimalSteps();coverage+=episode.discovered/(double)episode.maze.count();
                    index++;if(!done()) episode=new Episode(testMaze(index));
                }
            }
        }
        Result result() {
            if(!done()) throw new IllegalStateException("Test läuft noch");
            return new Result(wins/(double)CASES,cost/CASES,coverage/CASES,steps==0 ? 0 : walls*100.0/steps);
        }
    }
}
