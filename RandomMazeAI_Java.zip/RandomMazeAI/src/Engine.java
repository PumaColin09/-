import java.io.IOException;
import java.nio.file.Path;

/** Serializes model mutations between the training worker and Swing UI. */
final class Engine {
    private Learner learner;
    private final Rng seeds=new Rng(System.nanoTime());
    private boolean running, endless=true, demo, manualDemo;
    private int speed=2, demoTicks;
    private long solvedMazes, checkedEpisodes=-1;
    private int[] route=new int[0];
    record Snapshot(Maze maze,int position,int[] visits,boolean[] trail,int[] route,
                    long episodes,long successes,long steps,double epsilon,double recentRate,
                    int bestSteps,int lastSteps,int episodeSteps,long solvedMazes,
                    boolean running,boolean demo,int demoPosition,double[] currentQ) {}
    Engine(int size,long seed) {learner=new Learner(Maze.generate(size,seed),seed^0x71AC439L);}
    synchronized void setRunning(boolean value) {running=value;}
    synchronized boolean isRunning() {return running;}
    synchronized void setSpeed(int value) {if(value<0 || value>3) throw new IllegalArgumentException();speed=value;}
    synchronized void setEndless(boolean value) {endless=value;}
    synchronized void newMaze(int size) {newMaze(size,seeds.nextLong());}
    synchronized void newMaze(int size,long seed) {
        learner=new Learner(Maze.generate(size,seed),seed^0x71AC439L);
        route=new int[0];checkedEpisodes=-1;demo=false;manualDemo=false;demoTicks=0;
    }
    synchronized void singleStep() {
        running=false;demo=false;manualDemo=false;learner.step();refreshRoute();
    }
    synchronized boolean showDemo() {
        refreshRoute();if(route.length==0) return false;
        demo=true;manualDemo=true;demoTicks=0;running=true;return true;
    }
    synchronized void tick() {
        if(!running) return;
        if(demo) {
            if(++demoTicks>=150) {
                demo=false;
                if(manualDemo || !endless) {manualDemo=false;running=false;}
                else {solvedMazes++;newMaze(learner.maze.size);}
            }
            return;
        }
        int budget=switch(speed) {case 0->1;case 1->120;case 2->1500;default->10000;};
        long deadline=System.nanoTime()+3_000_000;
        for(int i=0;i<budget;i++) {
            learner.step();
            if(learner.episodes!=checkedEpisodes && learner.episodes%25==0) {
                refreshRoute();checkedEpisodes=learner.episodes;
                if(endless && route.length>0) {demo=true;manualDemo=false;demoTicks=0;break;}
            }
            if((i&63)==63 && System.nanoTime()>=deadline) break;
        }
    }
    private void refreshRoute() {route=learner.greedyPath();}
    synchronized Snapshot snapshot() {
        int demoPosition=route.length==0 ? 0 : route[Math.min(route.length-1,(int)((long)demoTicks*route.length/120))];
        return new Snapshot(learner.maze,learner.position,learner.visits.clone(),learner.trail.clone(),route.clone(),
                learner.episodes,learner.successes,learner.totalSteps,learner.epsilon,learner.recentRate(),
                learner.bestSteps,learner.lastSteps,learner.episodeSteps,solvedMazes,running,demo,demoPosition,
                java.util.Arrays.copyOfRange(learner.q,learner.position*4,learner.position*4+4));
    }
    synchronized void save(Path path) throws IOException {SessionStore.save(path,learner,solvedMazes);}
    void load(Path path) throws IOException {
        SessionStore.Saved saved=SessionStore.load(path);
        synchronized(this) {
            learner=saved.learner();solvedMazes=saved.solvedMazes();
            running=false;demo=false;manualDemo=false;demoTicks=0;refreshRoute();checkedEpisodes=-1;
        }
    }
}
