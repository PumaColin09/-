import java.io.IOException;
import java.nio.file.Path;
/** Model mutations and model snapshots are serialized between worker and Swing. */
final class Engine {
    private Learner learner;private Progress progress=new Progress();
    private final Rng seeds=new Rng(System.nanoTime());
    private boolean running,endless=true,demo,manualDemo;private int speed=2,demoTicks;
    private long completedMaps,nextTest=10000,testStep;private double testLoss;
    private Evaluation.Job evaluation;private int[] route=new int[0];
    record Snapshot(Maze maze,int position,int[] visits,boolean[] trail,int[] route,
        long episodes,long successes,long steps,double epsilon,double recentRate,int bestSteps,int lastSteps,int episodeSteps,
        long solvedMazes,boolean running,boolean demo,int demoPosition,double[] currentQ,
        long updates,int replayCount,double loss,String decision,int action,float reward,boolean exploring,
        double coverage,Progress.Point[] progress,boolean testing,long maps,int mapEpisodes) {}
    Engine(int size,long seed) {
        learner=new Learner(Maze.generate(size,seed & 0xFFFF_FFFFL),123);
        // A fixed initialization makes initial vs trained runs reproducible; maps remain random.
        progress.add(0,Evaluation.evaluate(learner.online),0);
    }
    synchronized void setRunning(boolean value) {running=value;}
    synchronized boolean isRunning() {return running;}
    synchronized void setSpeed(int value) {if(value<0 || value>3) throw new IllegalArgumentException();speed=value;}
    synchronized void setEndless(boolean value) {endless=value;}
    synchronized void newMaze(int size) {newMaze(size,seeds.nextLong());}
    synchronized void newMaze(int size,long seed) {
        learner.changeMaze(Maze.generate(size,seed & 0xFFFF_FFFFL));route=new int[0];
        demo=false;manualDemo=false;demoTicks=0;
    }
    synchronized void singleStep() {running=false;demo=false;manualDemo=false;learner.step();route=new int[0];}
    synchronized boolean showDemo() {
        route=learner.greedyPath();if(route.length==0) return false;
        demo=true;manualDemo=true;demoTicks=0;running=true;return true;
    }
    synchronized void requestTest() {if(evaluation==null) beginTest();}
    private void beginTest() {evaluation=new Evaluation.Job(learner.online);testStep=learner.totalSteps;testLoss=learner.loss;}
    synchronized void tick() {
        // A manually requested fixed-model test can also finish while training is paused.
        long deadline=System.nanoTime()+3_000_000;
        if(evaluation!=null) {
            for(int i=0;i<8 && !evaluation.done() && System.nanoTime()<deadline;i++) evaluation.advance(8);
            if(evaluation.done()) {progress.add(testStep,evaluation.result(),testLoss);evaluation=null;nextTest=learner.totalSteps+10000;}
        }
        if(!running) return;
        if(demo) {
            if(++demoTicks>=100) {demo=false;if(manualDemo || !endless) {manualDemo=false;running=false;}
                else {completedMaps++;newMaze(learner.maze.size);}}
            return;
        }
        int budget=switch(speed) {case 0->1;case 1->8;case 2->48;default->192;};
        for(int i=0;i<budget && System.nanoTime()<deadline;i++) {
            learner.step();
            if(learner.totalSteps>=nextTest && evaluation==null) beginTest();
            if(endless && learner.mapEpisodes>=5) {
                // Use an actual learned route only when the current model can finish it.
                if(learner.lastGoal && learner.maps%10==0) {
                    route=learner.greedyPath();if(route.length>0) {demo=true;manualDemo=false;demoTicks=0;break;}
                }
                completedMaps++;newMaze(learner.maze.size);
            }
        }
    }
    synchronized Snapshot snapshot() {
        Episode e=learner.episode;boolean[] trail=new boolean[e.visits.length];for(int i=0;i<trail.length;i++) trail[i]=e.visits[i]>0;
        float[] values=learner.currentQ();double[] q=new double[4];for(int a=0;a<4;a++) q[a]=values[a];
        int demoPos=route.length==0 ? learner.maze.start : route[Math.min(route.length-1,(int)((long)demoTicks*route.length/80))];
        return new Snapshot(learner.maze,e.position,e.visits.clone(),trail,route.clone(),learner.episodes,learner.successes,
            learner.totalSteps,learner.epsilon,learner.recentRate(),learner.bestSteps,learner.lastSteps,e.steps,completedMaps,
            running,demo,demoPos,q,learner.updates,learner.replay.count,learner.loss,learner.lastDecision,learner.lastAction,
            learner.lastReward,learner.lastExploration,e.discovered/(double)learner.maze.count(),progress.snapshot(),evaluation!=null,
            learner.maps,learner.mapEpisodes);
    }
    synchronized void save(Path path) throws IOException {SessionStore.save(path,learner,completedMaps,progress,seeds.state);}
    void load(Path path) throws IOException {
        SessionStore.Saved saved=SessionStore.load(path);
        synchronized(this) {
            learner=saved.learner();completedMaps=saved.solvedMazes();progress=saved.progress();
            seeds.state=saved.mapRngState();
            running=false;demo=false;manualDemo=false;demoTicks=0;route=new int[0];evaluation=null;nextTest=learner.totalSteps+10000;
        }
    }
}
