#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
java -Xmx256m -jar RandomMazeAI.jar
code=$?
if [ "$code" -ne 0 ]; then
  echo "Bitte Java 17 oder neuer mit Desktop-Unterstuetzung installieren. Siehe README.md."
fi
exit "$code"
