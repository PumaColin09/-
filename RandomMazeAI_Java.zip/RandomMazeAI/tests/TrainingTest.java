public class TrainingTest {
    public static void main(String[] args) {
        Learner l=new Learner(Maze.generate(6,11),123);Rng maps=new Rng(891);
        Evaluation.Result initial=Evaluation.evaluate(l.online),end=initial;
        System.out.println("initial="+initial);
        for(int i=1;i<=60000;i++) {
            l.step();if(l.mapEpisodes>=5) l.changeMaze(Maze.generate(6,maps.nextLong() & 0xFFFF_FFFFL));
            if(i%10000==0) {end=Evaluation.evaluate(l.online);System.out.println("steps="+i+" maps="+l.maps+" test="+end);}
        }
        DqnTest.check(end.successRate()>=initial.successRate()+.15,"Held-out success must improve over untrained network");
        DqnTest.check(end.wallsPer100()<initial.wallsPer100(),"Must hit fewer walls on unknown maps");
        DqnTest.check(l.maps>20 && l.updates>0,"Training must span many distinct mazes");
        System.out.println("PASS: actual transfer improvement on held-out maps");
    }
}
