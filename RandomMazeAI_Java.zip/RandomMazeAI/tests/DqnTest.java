import java.util.Arrays;
public class DqnTest {
    static void check(boolean ok,String text) {if(!ok) throw new AssertionError(text);}
    public static void main(String[] args) {
        Network n=new Network(123);
        float[] state=new float[Network.INPUT],out=new float[4];state[0]=1;state[5]=.5f;
        n.predict(state,out);float before=out[2];
        for(int i=0;i<400;i++) n.train(state,2,2f);
        n.predict(state,out);check(Math.abs(out[2]-2)<Math.abs(before-2)*.15,"Backprop must learn a target");
        int momentumIndex=Network.B3+2;
        float oldMomentum=n.momentum[momentumIndex];
        n.train(state,1,1f);
        check(Math.abs(n.momentum[momentumIndex]-oldMomentum*.9f)<1e-12,
            "Adam must decay moments even for output weights with zero current gradient");
        n.predict(state,out);
        Network copy=new Network(456);copy.copyFrom(n);float[] other=new float[4];copy.predict(state,other);
        check(Arrays.equals(out,other),"Target network copied exactly");
        Learner learner=new Learner(Maze.generate(6,77),123);
        for(int i=0;i<1000;i++) learner.step();
        long steps=learner.totalSteps,updates=learner.updates;float[] weights=learner.online.parameters.clone();
        int replay=learner.replay.count;
        learner.changeMaze(Maze.generate(8,99));
        check(learner.totalSteps==steps && learner.updates==updates,"Global progress survives map change");
        check(Arrays.equals(weights,learner.online.parameters),"Neural weights survive map change");
        check(learner.replay.count==replay,"Experience replay survives map change");
        check(learner.episode.position==learner.maze.start,"Episode begins at random start");
        check(learner.maze.start!=learner.maze.goal,"Start and goal differ");
        long checksum=learner.modelHash();
        Evaluation.Result evaluation=Evaluation.evaluate(learner.online);
        check(learner.modelHash()==checksum,"Evaluation must not train or mutate network");
        check(evaluation.successRate()>=0 && evaluation.successRate()<=1,"Valid test rate");
        boolean changed=false;Maze first=Maze.generate(6,0);
        for(int i=1;i<20;i++) {Maze m=Maze.generate(6,i);if(m.start!=first.start && m.goal!=first.goal) changed=true;}
        check(changed,"Start AND goal must vary across seeds");
        System.out.println("PASS: neural gradient, target copy, cross-maze model/replay, random endpoints, evaluation isolation");
    }
}
