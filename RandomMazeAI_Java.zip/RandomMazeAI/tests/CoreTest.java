import java.util.*;
public class CoreTest {
    static int checks;
    static void check(boolean condition,String message) {checks++;if(!condition) throw new AssertionError(message);}
    public static void main(String[] args) {
        for(int size:new int[]{4,8,15,30}) for(long seed=0;seed<20;seed++) {
            Maze m=Maze.generate(size,seed),same=Maze.generate(size,seed);
            check(Arrays.equals(m.open,same.open) && m.start==same.start && m.goal==same.goal,"Seed reproducibility");
            boolean[] seen=new boolean[m.count()];int[] queue=new int[m.count()];int head=0,tail=1,edges=0;seen[0]=true;
            while(head<tail) {int p=queue[head++];for(int a=0;a<4;a++) {int n=m.move(p,a);if(n!=p) {
                edges++;check(m.move(n,(a+2)%4)==p,"Reciprocal passage");if(!seen[n]) {seen[n]=true;queue[tail++]=n;}
            }}}
            check(tail==m.count() && edges==2*(m.count()-1),"Perfect connected maze");
            check(m.start!=m.goal && m.optimalSteps()>0,"Random distinct reachable endpoints");
            Episode e=new Episode(m);float[] features=new float[48];e.observation(features);
            for(float f:features) check(Float.isFinite(f) && f>=-1 && f<=1,"Bounded neural observation");
        }
        try {Maze.generate(31,1);throw new AssertionError("Oversize accepted");} catch(IllegalArgumentException expected) {checks++;}
        System.out.println("PASS: "+checks+" maze/sensor checks");
    }
}
