import java.util.*;

/** No test framework: these checks run with the same Java installation as the app. */
public class CoreTest {
    static int checks;
    static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        generation(); updates(); learning();
        System.out.println("PASS: " + checks + " core checks");
    }
    static void generation() {
        for (int size : new int[]{4, 8, 15, 30}) for (long seed=0;seed<20;seed++) {
            Maze m=Maze.generate(size,seed);
            Maze same=Maze.generate(size,seed);
            check(Arrays.equals(m.open,same.open),"Same seed must reproduce maze");
            boolean[] seen=new boolean[m.count()];
            int[] queue=new int[m.count()]; int head=0,tail=1,edges=0;seen[0]=true;
            while(head<tail) {
                int p=queue[head++];
                for(int a=0;a<4;a++) {
                    int n=m.move(p,a);
                    if(n!=p) {
                        edges++;
                        check(m.move(n,(a+2)%4)==p,"Passage must be reciprocal");
                        if(!seen[n]) {seen[n]=true;queue[tail++]=n;}
                    }
                }
            }
            check(tail==m.count(),"Every cell must be reachable");
            check(edges/2==m.count()-1,"Perfect maze must have exactly N-1 edges");
            check(m.move(0,0)==0 && m.move(0,3)==0,"Outside is blocked");
        }
        try {Maze.generate(31,1);throw new AssertionError("oversize accepted");}
        catch(IllegalArgumentException expected) {checks++;}
    }
    static void updates() {
        Learner l=new Learner(Maze.generate(4,1),2);
        l.q[4]=2.0;
        l.update(0,1,1.0,1,false);
        check(Math.abs(l.q[1] - l.alpha*(1+l.gamma*2))<1e-12,"Bellman update");
        l.q[(l.maze.count()-1)*4]=999;
        l.update(0,2,20.0,l.maze.count()-1,true);
        check(Math.abs(l.q[2]-l.alpha*20)<1e-12,"Terminal state must not bootstrap");
    }
    static void learning() {
        for(long seed=0;seed<10;seed++) {
            Learner l=new Learner(Maze.generate(8,seed),seed+100);
            check(l.greedyPath().length==0,"Untrained policy must not claim a solution");
            while(l.episodes<6000 && l.greedyPath().length==0) {
                long target=l.episodes+25;
                while(l.episodes<target) l.step();
            }
            int[] path=l.greedyPath();
            check(path.length>0,"Must learn maze seed "+seed+" within 6000 episodes");
            check(path[0]==0 && path[path.length-1]==l.maze.count()-1,"Learned path endpoints");
            for(int i=1;i<path.length;i++) {
                boolean adjacent=false;
                for(int a=0;a<4;a++) if(l.maze.move(path[i-1],a)==path[i]) adjacent=true;
                check(adjacent,"Learned route must traverse real passages");
            }
            System.out.println("seed="+seed+" episodes="+l.episodes+" route="+(path.length-1));
        }
    }
}
