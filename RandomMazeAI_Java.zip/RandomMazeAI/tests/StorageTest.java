import java.nio.file.*;
import java.util.*;

public class StorageTest {
    static void check(boolean condition,String message) {if(!condition) throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        Path directory=Files.createTempDirectory("maze-tests-");
        try {
            Learner original=new Learner(Maze.generate(12,77),99);
            for(int i=0;i<50000;i++) original.step();
            Path file=directory.resolve("session.mazeai");
            SessionStore.save(file,original,7);
            SessionStore.Saved restored=SessionStore.load(file);
            Learner loaded=restored.learner();
            check(restored.solvedMazes()==7,"Endless counter saved");
            equal(original,loaded);
            for(int i=0;i<1000;i++) {original.step();loaded.step();}
            equal(original,loaded);
            // Replacing an existing save must work and leave no partial files.
            SessionStore.save(file,original,8);
            check(SessionStore.load(file).solvedMazes()==8,"Replace save");
            byte[] good=Files.readAllBytes(file);
            byte[] corrupt=good.clone();corrupt[corrupt.length/2]^=1;
            Path bad=directory.resolve("bad.mazeai");Files.write(bad,corrupt);reject(bad);
            Files.write(bad,Arrays.copyOf(good,good.length-5));reject(bad);
            Files.write(bad,new byte[0]);reject(bad);
            Files.write(bad,new byte[100001]);reject(bad);
            try(var files=Files.list(directory)) {
                check(files.count()==2,"No leftover temporary save file");
            }
            System.out.println("PASS: exact save/resume, replacement, corruption, truncation, size limits");
        } finally {
            try(var files=Files.list(directory)) {for(Path f:files.toList()) Files.deleteIfExists(f);}
            Files.deleteIfExists(directory);
        }
    }
    static void reject(Path file) throws Exception {
        try {SessionStore.load(file);throw new AssertionError("Corrupt save accepted");}
        catch(java.io.IOException expected) {}
    }
    static void equal(Learner a,Learner b) {
        check(Arrays.equals(a.maze.open,b.maze.open),"Maze preserved");
        check(Arrays.equals(a.q,b.q),"Q table preserved");
        check(Arrays.equals(a.visits,b.visits),"Heatmap preserved");
        check(Arrays.equals(a.trail,b.trail),"Trail preserved");
        check(Arrays.equals(a.recent,b.recent),"Recent outcomes preserved");
        check(a.rng.state==b.rng.state,"RNG exact continuation");
        check(a.epsilon==b.epsilon && a.position==b.position && a.episodeSteps==b.episodeSteps,
              "Current episode preserved");
        check(a.totalSteps==b.totalSteps && a.episodes==b.episodes && a.successes==b.successes,
              "Counters preserved");
        check(a.bestSteps==b.bestSteps && a.lastSteps==b.lastSteps && a.recentIndex==b.recentIndex
              && a.recentCount==b.recentCount,"Episode metrics preserved");
    }
}
