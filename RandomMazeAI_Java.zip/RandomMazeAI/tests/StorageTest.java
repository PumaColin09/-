import java.nio.file.*;
import java.util.*;
public class StorageTest {
    static void check(boolean c,String s) {if(!c) throw new AssertionError(s);}
    public static void main(String[] args) throws Exception {
        Path dir=Files.createTempDirectory("dqn-save-");
        try {
            Learner a=new Learner(Maze.generate(6,77),123);for(int i=0;i<5000;i++) a.step();
            Progress history=new Progress();history.add(0,new Evaluation.Result(0,10,.1,90),0);
            Path file=dir.resolve("save.mazeai");SessionStore.save(file,a,7,history);
            SessionStore.Saved saved=SessionStore.load(file);Learner b=saved.learner();
            check(saved.solvedMazes()==7 && saved.progress().points.size()==1,"Progress saved");equal(a,b);
            for(int i=0;i<100;i++) {a.step();b.step();}equal(a,b);
            SessionStore.save(file,a,8,history);check(SessionStore.load(file).solvedMazes()==8,"Replace file");
            byte[] good=Files.readAllBytes(file),bad=good.clone();bad[bad.length/2]^=1;
            Path corrupt=dir.resolve("bad.mazeai");Files.write(corrupt,bad);reject(corrupt);
            Files.write(corrupt,Arrays.copyOf(good,good.length-5));reject(corrupt);
            Files.write(corrupt,new byte[0]);reject(corrupt);Files.write(corrupt,new byte[4_000_001]);reject(corrupt);
            System.out.println("PASS: DQN + Adam + replay exact save/resume; CRC, truncation and size limits");
        } finally {try(var files=Files.list(dir)) {for(Path p:files.toList()) Files.delete(p);}Files.delete(dir);}
    }
    static void reject(Path file) throws Exception {try {SessionStore.load(file);throw new AssertionError("Corrupt file accepted");}catch(java.io.IOException expected) {}}
    static void equal(Learner a,Learner b) {
        check(Arrays.equals(a.maze.open,b.maze.open) && a.maze.start==b.maze.start && a.maze.goal==b.maze.goal,"Map");
        check(Arrays.equals(a.online.parameters,b.online.parameters) && Arrays.equals(a.target.parameters,b.target.parameters),"Weights");
        check(Arrays.equals(a.online.momentum,b.online.momentum) && Arrays.equals(a.online.variance,b.online.variance)
            && a.online.adamStep==b.online.adamStep,"Optimizer");
        check(a.rng.state==b.rng.state && a.totalSteps==b.totalSteps && a.episodes==b.episodes && a.updates==b.updates,"Counters/RNG");
        check(a.episode.position==b.episode.position && a.episode.steps==b.episode.steps && Arrays.equals(a.episode.visits,b.episode.visits),"Episode");
        check(a.replay.count==b.replay.count && a.replay.cursor==b.replay.cursor,"Replay cursor");
        for(int i=0;i<a.replay.count;i++) check(Arrays.equals(a.replay.state[i],b.replay.state[i])
            && Arrays.equals(a.replay.next[i],b.replay.next[i]) && a.replay.reward[i]==b.replay.reward[i]
            && a.replay.action[i]==b.replay.action[i] && a.replay.terminal[i]==b.replay.terminal[i],"Replay transition");
    }
}
