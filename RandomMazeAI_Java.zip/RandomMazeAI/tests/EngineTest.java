import java.nio.file.*;
public class EngineTest {
    static void check(boolean c,String s) {if(!c) throw new AssertionError(s);}
    public static void main(String[] args) throws Exception {
        Engine e=new Engine(4,123);e.tick();check(e.snapshot().steps()==0,"Starts paused");
        e.singleStep();check(e.snapshot().steps()==1,"Single step");e.setRunning(true);e.tick();check(e.snapshot().steps()>1,"Start");
        e.setRunning(false);long steps=e.snapshot().steps();e.tick();check(e.snapshot().steps()==steps,"Pause");
        e.newMaze(4,111);check(e.snapshot().steps()==steps && e.snapshot().maze().seed==111,"Map changes preserve progress");
        e.setSpeed(3);e.setEndless(true);e.setRunning(true);
        for(int i=0;i<2000 && e.snapshot().solvedMazes()<2;i++) e.tick();
        check(e.snapshot().solvedMazes()>=2 && e.snapshot().steps()>steps,"Endless transfers learning");
        e.setRunning(false);e.requestTest();for(int i=0;i<2000 && e.snapshot().testing();i++) e.tick();
        check(!e.snapshot().testing() && e.snapshot().progress().length>=2,"Incremental evaluation while paused");
        Path file=Files.createTempFile("engine-",".mazeai");try {
            e.save(file);long s=e.snapshot().steps();e.newMaze(4);long nextSeed=e.snapshot().maze().seed;e.load(file);
            check(e.snapshot().steps()==s && !e.snapshot().running(),"Load complete model paused");
            e.newMaze(4);check(e.snapshot().maze().seed==nextSeed,"Save must preserve future maze RNG sequence");
        } finally {Files.delete(file);}
        Thread t=new Thread(()->{for(int i=0;i<100;i++) e.tick();});t.start();
        for(int i=0;i<25;i++) {e.newMaze(4+i%5,i);e.setRunning(true);e.snapshot().maze().validate();}t.join();
        e.setRunning(false);System.out.println("PASS: pause/step, cross-map progress, endless, frozen eval, load and concurrent controls");
    }
}
