import java.nio.file.*;

public class EngineTest {
    static void check(boolean condition,String text) {if(!condition) throw new AssertionError(text);}
    public static void main(String[] args) throws Exception {
        Engine e=new Engine(8,123);
        e.tick();check(e.snapshot().steps()==0,"Initially paused");
        e.singleStep();check(e.snapshot().steps()==1,"One step while paused");
        e.setRunning(true);e.tick();check(e.snapshot().steps()>1,"Start trains");
        e.setRunning(false);long steps=e.snapshot().steps();e.tick();
        check(e.snapshot().steps()==steps,"Pause freezes training");
        e.newMaze(4,111);check(e.snapshot().steps()==0 && e.snapshot().maze().seed==111,"New map resets learning");
        e.setSpeed(3);e.setEndless(true);e.setRunning(true);
        for(int i=0;i<2500 && e.snapshot().solvedMazes()<2;i++) e.tick();
        check(e.snapshot().solvedMazes()>=2,"Endless mode must solve and replace maps");
        e.setRunning(false);
        Path file=Files.createTempFile("engine-",".mazeai");
        try {
            e.save(file);long saved=e.snapshot().steps(),solved=e.snapshot().solvedMazes();
            e.newMaze(8,44);e.load(file);
            check(e.snapshot().steps()==saved && e.snapshot().solvedMazes()==solved,"Load replaces session");
            check(!e.snapshot().running(),"Load stays paused");
        } finally {Files.deleteIfExists(file);}
        // Controller synchronization: worker and UI operations may race, never corrupt a map.
        Thread worker=new Thread(()->{for(int i=0;i<2000;i++) e.tick();});worker.start();
        for(int i=0;i<100;i++) {e.newMaze(4+(i%5),i);e.setRunning(true);e.snapshot().maze().validate();}
        worker.join();e.setRunning(false);e.snapshot().maze().validate();
        System.out.println("PASS: pause, step, map reset, endless, load, concurrent controls");
    }
}
