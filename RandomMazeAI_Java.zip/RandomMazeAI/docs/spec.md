# Random Maze AI – Umfang

Eine offline nutzbare Java-17-Desktop-App erzeugt immer wieder zufällige, zusammenhängende Labyrinthe. Ein tabellarischer Q-Learning-Agent lernt im jeweils aktuellen Labyrinth von Start zu Ziel. Die Q-Tabelle gehört zu diesem Labyrinth; beim Wechsel wird sie zurückgesetzt. Dies ist kein Modell, das Wissen auf unbekannte Labyrinthe überträgt.

Java Swing, keine externen Bibliotheken, ein begrenzter CPU-Trainingsworker, keine GPU. Quadratische Labyrinthe von 4 bis 30 Zellen pro Seite. Iterative Tiefensuche erzeugt einen zusammenhängenden Baum ohne Rekursionsrisiko. Wiederholungen sind möglich; „endlos“ bedeutet fortlaufende Generierung ohne feste Liste und ohne Speichern aller bisherigen Karten.

Die Oberfläche zeigt Agent, Besuchsdichte, gelernte Route, Episoden, Exploration und Erfolgsrate der letzten 100 Episoden. Start/Pause, Einzelschritt, neue Karte, Größe, vier Geschwindigkeiten, Endlosmodus, Route vorführen, Speichern und Laden. Bei erfolgreich geprüfter Greedy-Route im Endlosmodus: Route kurz vorführen, dann nächste Karte.

Speicherdateien enthalten das aktuelle Labyrinth, Q-Werte, RNG-Zustand, Position und Statistiken. Versioniertes, begrenztes Binärformat, CRC und atomarer Austausch verhindern das Laden beschädigter Daten und halb geschriebene Speicherstände. Ein Kommandozeilenbenchmark und abhängigkeitfreie Tests prüfen Generierung, Lernerfolg, Wiederaufnahme und Eingabegrenzen. Die i5-6500-Kompatibilität folgt aus Java/CPU-Auslegung; keine behaupteten Hardwaremessungen.
