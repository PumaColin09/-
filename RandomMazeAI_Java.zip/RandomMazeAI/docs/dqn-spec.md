# Maze / Lab 2 – dauerhaftes Lernen

Ein gemeinsames kleines Deep-Q-Netz (48 → 32 → 24 → 4) ersetzt die kartenabhängige Q-Tabelle. Online-Netz, Target-Netz, Adam-Zustand, Replay-Speicher und globale Statistik bleiben beim Kartenwechsel erhalten. Start und Ziel werden pro Seed zufällig und verschieden gewählt.

Die Beobachtung besteht aus lokalen Wänden, Nachbarbesuchen, Zielrichtung, letzter Aktion und begrenzter Episodenerinnerung. Keine fertige Route und kein BFS-Abstand werden als Eingabe oder Reward geliefert. Eine kleine Belohnung für neue Felder hilft, allgemeine Erkundung zu lernen. Das Modell hat keine Garantie für jeden unbekannten Irrgarten; seine Übertragung wird gemessen.

Das Dashboard zeigt Live-Aktionswerte, letzte Entscheidung, Reward, Besuchsgrad, Episodenergebnis, globale Lernschritte und neuronale Updates. Eine Lernkurve zeigt eine getrennte, feste Sammlung unbekannter 4×4-, 6×6- und 8×8-Testkarten ohne Exploration oder Training: Erfolgsrate, Wegaufwand mit Budget für Fehlschläge, Besuchsgrad und Wandtreffer. Die Anfangsleistung wird als Vergleich eingefroren. Training und Testkarten verwenden getrennte Seed-Bereiche; Testkarten werden nicht in Replay aufgenommen.

Karten wechseln im Endlosmodus nach fünf Versuchen, auch bei Fehlschlag, damit immer neue Erfahrungen hinzukommen. Gewichte bleiben erhalten. Testläufe werden in kleinen Schritten abgearbeitet, um Swing nicht lange zu blockieren. Start/Pause und Einzelschritt bleiben verfügbar; langsamer Modus zeigt jede Handlung. Speichern umfasst das gesamte Modell, Replay und aktuelle Karte. Alte V1-Q-Tabellen können nicht in ein neuronales Modell konvertiert werden und werden mit verständlicher Meldung abgelehnt.
